using System;

namespace WpfApp3.Core.Messaging
{
    public enum MessageDeliveryStatus
    {
        SENDING,
        SENT,
        DELIVERED,
        READ,
        FAILED
    }

    public enum MessageType
    {
        TEXT,
        ATTACHMENT,
        SYSTEM
    }

    public class AdvancedChatMessage
    {
        public string MessageId { get; set; } = Guid.NewGuid().ToString();
        public string SenderDeviceId { get; set; } = "";
        public string SenderUsername { get; set; } = "";
        public string? ReceiverDeviceId { get; set; } // Null or empty if Group or Broadcast
        public string? GroupId { get; set; }
        public string Text { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public MessageDeliveryStatus Status { get; set; } = MessageDeliveryStatus.SENT;
        public MessageType Type { get; set; } = MessageType.TEXT;
        public string? ReplyToMessageId { get; set; }

        // Optional Attachment metadata
        public string? AttachmentFileName { get; set; }
        public long? AttachmentFileSize { get; set; }
        public string? AttachmentSha256 { get; set; }

        public bool IsGroupMessage => !string.IsNullOrWhiteSpace(GroupId);
        public bool IsDirectMessage => !string.IsNullOrWhiteSpace(ReceiverDeviceId) && string.IsNullOrWhiteSpace(GroupId);
        public bool IsBroadcast => string.IsNullOrWhiteSpace(ReceiverDeviceId) && string.IsNullOrWhiteSpace(GroupId);
    }

    public class ChatDeliveryAck
    {
        public string MessageId { get; set; } = "";
        public string AckByDeviceId { get; set; } = "";
        public MessageDeliveryStatus Status { get; set; } = MessageDeliveryStatus.DELIVERED;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }

    /// <summary>
    /// Wire envelope for direct (1-to-1) and group chat messages sent over the
    /// authenticated TLS transfer channel. "Type" is the routing marker the
    /// TransferServer peeks at ("ADV_MESSAGE"), distinct from AdvancedChatMessage's
    /// own MessageType.Type field, which is why the message is nested here rather
    /// than serialized flat.
    /// </summary>
    public class AdvancedMessagePacket
    {
        public string Type { get; set; } = "ADV_MESSAGE";
        public AdvancedChatMessage Message { get; set; } = new();
    }
}
