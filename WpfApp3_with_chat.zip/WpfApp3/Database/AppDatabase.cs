using System;
using System.IO;
using Microsoft.Data.Sqlite;

namespace WpfApp3.Database
{
    public static class AppDatabase
    {
        private static readonly string DatabaseDirectory =
            Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "LANShare");

        private static readonly string DatabasePath =
            Path.Combine(DatabaseDirectory, "navlan.db");

        private static string? _customDatabasePath;

        public static string ConnectionString =>
            $"Data Source={_customDatabasePath ?? DatabasePath};";

        public static void SetCustomDatabasePath(string path)
        {
            lock (_initLock)
            {
                _customDatabasePath = path;
                _initialized = false;
            }
        }

        public static void ResetCustomDatabasePath()
        {
            lock (_initLock)
            {
                _customDatabasePath = null;
                _initialized = false;
            }
        }

        private static readonly object _initLock = new();
        private static bool _initialized;

        public static void Initialize()
        {
            lock (_initLock)
            {
                if (_initialized) return;

                string targetDir = Path.GetDirectoryName(_customDatabasePath ?? DatabasePath) ?? DatabaseDirectory;
                Directory.CreateDirectory(targetDir);

                using SqliteConnection connection = new(ConnectionString);
                connection.Open();

                // Enable WAL for better concurrency
                using (SqliteCommand wal = connection.CreateCommand())
                {
                    wal.CommandText = "PRAGMA journal_mode=WAL;";
                    wal.ExecuteNonQuery();
                }

                // Enable foreign keys
                using (SqliteCommand fk = connection.CreateCommand())
                {
                    fk.CommandText = "PRAGMA foreign_keys=ON;";
                    fk.ExecuteNonQuery();
                }

                CreateSchema(connection);
                DatabaseMigrator.Migrate(connection);

                _initialized = true;
            }
        }

        private static void CreateSchema(SqliteConnection connection)
        {
            using SqliteCommand cmd = connection.CreateCommand();
            cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    Role TEXT NOT NULL DEFAULT 'User',
    PasswordHash TEXT NOT NULL,
    PasswordSalt TEXT NOT NULL,
    ForcePasswordReset INTEGER NOT NULL DEFAULT 0,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL,
    LastLoginAt TEXT
);

CREATE TABLE IF NOT EXISTS Devices (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    DeviceId TEXT NOT NULL UNIQUE COLLATE NOCASE,
    UserId INTEGER NOT NULL,
    DisplayName TEXT NOT NULL,
    CertificateFingerprint TEXT,
    PublicKey TEXT,
    DeviceState TEXT NOT NULL DEFAULT 'PENDING_APPROVAL',
    IsAuthorized INTEGER NOT NULL DEFAULT 0,
    IsRevoked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    LastSeenAt TEXT,
    FOREIGN KEY (UserId) REFERENCES Users(Id)
);

CREATE TABLE IF NOT EXISTS ChatMessages (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    MessageId TEXT NOT NULL UNIQUE,
    SenderDeviceId TEXT NOT NULL,
    SenderUsername TEXT NOT NULL,
    Message TEXT NOT NULL,
    Timestamp TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS AuditLogs (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Timestamp TEXT NOT NULL,
    ActorUsername TEXT,
    ActorDeviceId TEXT,
    Action TEXT NOT NULL,
    Target TEXT,
    Result TEXT
);

CREATE INDEX IF NOT EXISTS idx_devices_userid ON Devices(UserId);
CREATE INDEX IF NOT EXISTS idx_chat_timestamp  ON ChatMessages(Timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON AuditLogs(Timestamp);
";
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Permanently erases all local accounts, devices, chat history and
        /// paired-device trust data so the app can start fresh.
        /// Used by the login window's "Forgot Password?" flow: accounts are
        /// stored locally and there is no email/phone recovery, so a
        /// forgotten password can only be cleared by wiping this device's
        /// data. The device identity (device.pfx / device-id.json) is
        /// intentionally preserved — it is the TLS identity, not a login
        /// credential.
        /// </summary>
        public static void ResetLocalLoginData()
        {
            lock (_initLock)
            {
                // Release pooled handles so the files can actually be
                // deleted (deleting a locked database would otherwise fail).
                SqliteConnection.ClearAllPools();

                // The main database must go — let any failure (e.g. another
                // instance still running) surface to the caller.
                if (File.Exists(DatabasePath))
                {
                    File.Delete(DatabasePath);
                }

                // WAL/journal sidecars are best-effort: without the main
                // database they are ignored and recreated as needed.
                foreach (string suffix in new[] { "-wal", "-shm", "-journal" })
                {
                    try
                    {
                        string sidecar = DatabasePath + suffix;
                        if (File.Exists(sidecar))
                        {
                            File.Delete(sidecar);
                        }
                    }
                    catch
                    {
                    }
                }

                // Legacy trust stores in the same folder (paired-device list
                // and the older trusted-devices list).
                foreach (string legacyFile in new[]
                         {
                             "paired-devices.json",
                             "trusted-devices.json"
                         })
                {
                    try
                    {
                        string legacyPath =
                            Path.Combine(DatabaseDirectory, legacyFile);
                        if (File.Exists(legacyPath))
                        {
                            File.Delete(legacyPath);
                        }
                    }
                    catch
                    {
                    }
                }

                _initialized = false;
            }
        }

        public static SqliteConnection OpenConnection()
        {
            if (!_initialized)
            {
                Initialize();
            }

            SqliteConnection connection = new(ConnectionString);
            connection.Open();

            using SqliteCommand fk = connection.CreateCommand();
            fk.CommandText = "PRAGMA foreign_keys=ON;";
            fk.ExecuteNonQuery();

            return connection;
        }
    }
}
