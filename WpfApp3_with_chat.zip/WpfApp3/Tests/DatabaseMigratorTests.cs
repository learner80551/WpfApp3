using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using Xunit;
using WpfApp3.Database;

namespace WpfApp3.Tests
{
    public class DatabaseMigratorTests
    {
        [Fact]
        public void Migrate_AppliesSchemaV1_OnFreshDatabase()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            // Simulate legacy base schema
            using (var initCmd = connection.CreateCommand())
            {
                initCmd.CommandText = @"
CREATE TABLE Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL UNIQUE,
    Role TEXT NOT NULL DEFAULT 'User',
    PasswordHash TEXT NOT NULL,
    PasswordSalt TEXT NOT NULL,
    ForcePasswordReset INTEGER NOT NULL DEFAULT 0,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL,
    LastLoginAt TEXT
);

CREATE TABLE Devices (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    DeviceId TEXT NOT NULL UNIQUE,
    UserId INTEGER NOT NULL,
    DisplayName TEXT NOT NULL,
    CertificateFingerprint TEXT,
    IsAuthorized INTEGER NOT NULL DEFAULT 1,
    IsRevoked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    LastSeenAt TEXT,
    FOREIGN KEY (UserId) REFERENCES Users(Id)
);";
                initCmd.ExecuteNonQuery();
            }

            // Run migration
            DatabaseMigrator.Migrate(connection);

            // Verify SchemaVersion table exists and records Version 1
            using (var checkVerCmd = connection.CreateCommand())
            {
                checkVerCmd.CommandText = "SELECT MAX(Version) FROM SchemaVersion;";
                int ver = Convert.ToInt32(checkVerCmd.ExecuteScalar());
                Assert.Equal(DatabaseMigrator.CurrentVersion, ver);
            }

            // Verify extended columns in Devices
            var cols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var colCmd = connection.CreateCommand())
            {
                colCmd.CommandText = "PRAGMA table_info(Devices);";
                using var r = colCmd.ExecuteReader();
                while (r.Read()) cols.Add(r.GetString(1));
            }

            Assert.Contains("Hostname", cols);
            Assert.Contains("IpAddress", cols);
            Assert.Contains("OperatingSystem", cols);
            Assert.Contains("ClientVersion", cols);
            Assert.Contains("Status", cols);
            Assert.Contains("TrustStatus", cols);

            // Verify new tables exist
            var tables = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var tblCmd = connection.CreateCommand())
            {
                tblCmd.CommandText = "SELECT name FROM sqlite_master WHERE type='table';";
                using var r = tblCmd.ExecuteReader();
                while (r.Read()) tables.Add(r.GetString(0));
            }

            Assert.Contains("Groups", tables);
            Assert.Contains("GroupMembers", tables);
            Assert.Contains("SecurityAlerts", tables);
            Assert.Contains("AuditSyncQueue", tables);
            Assert.Contains("SystemPolicies", tables);
        }

        [Fact]
        public void Migrate_IsIdempotent()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            using (var initCmd = connection.CreateCommand())
            {
                initCmd.CommandText = @"
CREATE TABLE Users (Id INTEGER PRIMARY KEY, Username TEXT);
CREATE TABLE Devices (Id INTEGER PRIMARY KEY, DeviceId TEXT, UserId INTEGER, DisplayName TEXT, IsAuthorized INT, IsRevoked INT, CreatedAt TEXT);";
                initCmd.ExecuteNonQuery();
            }

            // Migrate twice
            DatabaseMigrator.Migrate(connection);
            DatabaseMigrator.Migrate(connection);

            using var checkVerCmd = connection.CreateCommand();
            checkVerCmd.CommandText = "SELECT COUNT(*) FROM SchemaVersion WHERE Version = 1;";
            long count = Convert.ToInt64(checkVerCmd.ExecuteScalar());
            Assert.Equal(1, count);
        }
    }
}
