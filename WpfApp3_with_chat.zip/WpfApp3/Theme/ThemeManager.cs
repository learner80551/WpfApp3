using System;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace WpfApp3.Theme
{
    public enum AppTheme
    {
        Light,
        Dark
    }

    /// <summary>
    /// Centralized application-level theme manager for LANShare.
    /// Manages theme ResourceDictionaries, runtime dynamic resource switching,
    /// persistence, and change notification across all windows.
    /// </summary>
    public static class ThemeManager
    {
        private static readonly string SettingsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "LANShare", "settings.json");

        private static bool _isDark = LoadThemePreference();
        public static bool IsDark => _isDark;
        public static AppTheme CurrentTheme => _isDark ? AppTheme.Dark : AppTheme.Light;

        public static event Action<bool>? ThemeChanged;

        // ──────────────────────────────────────────────────
        // PERSISTENCE
        // ──────────────────────────────────────────────────

        public static bool LoadThemePreference()
        {
            try
            {
                if (!File.Exists(SettingsPath)) return true; // Default to dark
                string json = File.ReadAllText(SettingsPath);
                var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("IsDark", out var el))
                    return el.GetBoolean();
            }
            catch { }
            return true;
        }

        public static void SaveThemePreference(bool isDark)
        {
            try
            {
                string? dir = Path.GetDirectoryName(SettingsPath);
                if (!string.IsNullOrWhiteSpace(dir)) Directory.CreateDirectory(dir);

                string json = JsonSerializer.Serialize(
                    new { IsDark = isDark },
                    new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsPath, json);
            }
            catch { }
        }

        // ──────────────────────────────────────────────────
        // API METHODS
        // ──────────────────────────────────────────────────

        public static void ApplyLightTheme() => ApplyTheme(false);

        public static void ApplyDarkTheme() => ApplyTheme(true);

        public static void ToggleTheme() => ApplyTheme(!_isDark);

        /// <summary>
        /// Swaps the active Theme ResourceDictionary at the Application level
        /// and mirrors brushes into Application.Current.Resources for immediate DynamicResource resolution.
        /// </summary>
        public static void ApplyTheme(bool isDark)
        {
            _isDark = isDark;
            SaveThemePreference(isDark);

            if (Application.Current == null) return;

            Application.Current.Dispatcher.Invoke(() =>
            {
                try
                {
                    string themeSource = isDark ? "Theme/DarkTheme.xaml" : "Theme/LightTheme.xaml";
                    var uri = new Uri($"pack://application:,,,/{themeSource}", UriKind.Absolute);
                    var newDict = new ResourceDictionary { Source = uri };

                    var appResources = Application.Current.Resources;

                    // 1. Remove any old theme dictionaries from MergedDictionaries
                    for (int i = appResources.MergedDictionaries.Count - 1; i >= 0; i--)
                    {
                        var dict = appResources.MergedDictionaries[i];
                        if (dict.Source != null &&
                            (dict.Source.OriginalString.Contains("DarkTheme.xaml", StringComparison.OrdinalIgnoreCase) ||
                             dict.Source.OriginalString.Contains("LightTheme.xaml", StringComparison.OrdinalIgnoreCase)))
                        {
                            appResources.MergedDictionaries.RemoveAt(i);
                        }
                    }

                    // 2. Add the new theme dictionary
                    appResources.MergedDictionaries.Add(newDict);

                    // 3. Mirror all keys directly onto appResources so DynamicResource bindings
                    // and indexers update instantaneously across all open windows
                    foreach (var key in newDict.Keys)
                    {
                        appResources[key] = newDict[key];
                    }

                    // Also mirror into all open windows
                    foreach (Window window in Application.Current.Windows)
                    {
                        foreach (var key in newDict.Keys)
                        {
                            window.Resources[key] = newDict[key];
                        }
                    }

                    ThemeChanged?.Invoke(isDark);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[ThemeManager] Error applying theme: {ex.Message}");
                }
            });
        }
    }
}
