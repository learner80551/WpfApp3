using System;
using System.IO;

namespace WpfApp3.Core.Configuration
{
    /// <summary>
    /// Centralized application configuration and constants.
    /// Eliminates scattered magic numbers throughout the codebase.
    /// </summary>
    public static class AppConfig
    {
        public const string ApplicationName = "LANShare";
        public const string ApplicationVersion = "2.0.0";
        public const string ProtocolVersion = "2.0";

        // Networking Ports
        public const int ControlPort = 42000;
        public const int SecureTransferPort = 42001;
        public const int DiscoveryPort = 42101;

        // Timers and Intervals
        public const int DiscoveryIntervalMs = 3000;
        public const int PeerTimeoutSeconds = 10;
        public const int PeerRemoveSeconds = 30;

        // Socket & Transfer Limits
        public const int NetworkBufferSize = 64 * 1024; // 64 KB
        public const int MaxJsonRequestSize = 64 * 1024; // 64 KB
        public const long MaxFileSize = 100L * 1024L * 1024L * 1024L; // 100 GB

        // Timeouts
        public static readonly TimeSpan NetworkOperationTimeout = TimeSpan.FromSeconds(60);
        public static readonly TimeSpan HashOperationTimeout = TimeSpan.FromMinutes(10);
        public static readonly TimeSpan ClientAuthenticationTimeout = TimeSpan.FromSeconds(30);
        public static readonly TimeSpan RequestReadTimeout = TimeSpan.FromSeconds(30);
        public static readonly TimeSpan RejectionWriteTimeout = TimeSpan.FromSeconds(10);
        public static readonly TimeSpan PairingApprovalTimeout = TimeSpan.FromSeconds(120);

        // File Paths
        public static string AppDataFolder =>
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                ApplicationName);

        public static string DatabasePath =>
            Path.Combine(AppDataFolder, "navlan.db");

        public static string PairedDevicesPath =>
            Path.Combine(AppDataFolder, "paired-devices.json");

        public static string DeviceIdPath =>
            Path.Combine(AppDataFolder, "device-id.json");

        public static string DeviceCertificatePath =>
            Path.Combine(AppDataFolder, "device.pfx");
    }
}
