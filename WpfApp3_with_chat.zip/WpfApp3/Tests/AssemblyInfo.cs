using Xunit;

// Disable test parallelization because multiple test classes modify the static AppDatabase singleton path.
[assembly: CollectionBehavior(DisableTestParallelization = true)]
