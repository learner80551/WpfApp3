using System;
using System.Collections.Generic;
using WpfApp3.Authentication;
using WpfApp3.Core.Security;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Admin
{
    public enum AdminActionResult
    {
        Success,
        Unauthorized,
        UserNotFound,
        DeviceNotFound,
        UsernameTaken,
        DeviceIdTaken,
        ValidationError,
        DatabaseError
    }

    public class AdminResult
    {
        public AdminActionResult Code    { get; init; }
        public string            Message { get; init; } = "";
        public bool IsSuccess => Code == AdminActionResult.Success;
    }

    public static class AdminService
    {
        private static bool IsAdmin(AppSession? session) =>
            AuthorizationService.IsPermanentAdmin(session);

        // ──────────────────────────────────────────────────
        // USER MANAGEMENT (Admin or Supervisor with UserManagement)
        // ──────────────────────────────────────────────────

        public static AdminResult CreateUser(
            AppSession? session,
            string username,
            string deviceId,
            string initialPassword,
            string displayName = "")
        {
            if (!IsAdmin(session) && !AuthorizationService.CanApproveUsers(session))
                return Fail(AdminActionResult.Unauthorized, "Admin or UserManagement supervisor permission required.");

            if (string.IsNullOrWhiteSpace(username))
                return Fail(AdminActionResult.ValidationError, "Username is required.");

            if (string.IsNullOrWhiteSpace(deviceId))
                return Fail(AdminActionResult.ValidationError, "Device ID is required.");

            if (string.IsNullOrWhiteSpace(initialPassword) || initialPassword.Length < 8)
                return Fail(AdminActionResult.ValidationError, "Password must be at least 8 characters.");

            if (UserRepository.FindByUsername(username) != null)
                return Fail(AdminActionResult.UsernameTaken, $"Username '{username}' already exists.");

            if (UserRepository.FindDevice(deviceId) != null)
                return Fail(AdminActionResult.DeviceIdTaken, $"Device ID '{deviceId}' is already registered.");

            var (hash, salt) = Authentication.PasswordHasher.HashPassword(initialPassword);
            long userId = UserRepository.CreateUser(username, "User", hash, salt);

            string dn = string.IsNullOrWhiteSpace(displayName) ? username : displayName;
            UserRepository.CreateDevice(deviceId, userId, dn, null);

            AuditRepository.Log("UserCreated",
                session!.Username, session.DeviceId,
                username, "Success");

            return Ok($"User '{username}' created with device '{deviceId}'.");
        }

        public static AdminResult ApproveUser(AppSession? session, long targetUserId)
        {
            if (!IsAdmin(session))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can approve registrations.");

            var matches = UserRepository.GetPendingRegistrations()
                .FindAll(d => d.UserId == targetUserId);
            if (matches.Count != 1 || string.IsNullOrWhiteSpace(matches[0].PublicKey))
                return Fail(AdminActionResult.ValidationError, "An exact pending user/device/public-key registration is required.");

            return ApproveRegistration(session, targetUserId, matches[0].DeviceId, matches[0].PublicKey!);
        }

        public static AdminResult RejectUser(AppSession? session, long targetUserId)
        {
            if (!IsAdmin(session))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can reject registrations.");

            var matches = UserRepository.GetPendingRegistrations()
                .FindAll(d => d.UserId == targetUserId);
            if (matches.Count != 1 || string.IsNullOrWhiteSpace(matches[0].PublicKey))
                return Fail(AdminActionResult.ValidationError, "An exact pending user/device/public-key registration is required.");

            return RejectRegistration(session, targetUserId, matches[0].DeviceId, matches[0].PublicKey!);
        }

        public static AdminResult ApproveRegistration(
            AppSession? session, long userId, string deviceId, string publicKey)
        {
            return DecideRegistration(session, userId, deviceId, publicKey, true);
        }

        public static AdminResult RejectRegistration(
            AppSession? session, long userId, string deviceId, string publicKey)
        {
            return DecideRegistration(session, userId, deviceId, publicKey, false);
        }

        private static AdminResult DecideRegistration(
            AppSession? session, long userId, string deviceId, string publicKey, bool approve)
        {
            if (!IsAdmin(session))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can decide registrations.");
            if (userId <= 0 || string.IsNullOrWhiteSpace(deviceId) || string.IsNullOrWhiteSpace(publicKey))
                return Fail(AdminActionResult.ValidationError, "UserId, DeviceId, and PublicKey are required.");

            UserRecord? user = UserRepository.FindById(userId);
            DeviceRecord? device = UserRepository.FindDevice(deviceId);
            if (user == null)
                return Fail(AdminActionResult.UserNotFound, "User not found.");
            if (device == null)
                return Fail(AdminActionResult.DeviceNotFound, "Device not found.");
            if (device.UserId != userId || !string.Equals(device.PublicKey, publicKey, StringComparison.Ordinal))
                return Fail(AdminActionResult.ValidationError, "The device does not match the requested user and public key.");
            if (!string.Equals(user.AccountState, AccountStates.Pending, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(device.DeviceState, DeviceStates.PendingApproval, StringComparison.OrdinalIgnoreCase))
                return Fail(AdminActionResult.ValidationError, "The registration is no longer pending.");

            var payload = new CryptographicAuthority.RegistrationEventPayload
            {
                TargetUserId = userId,
                TargetDeviceId = deviceId,
                TargetPublicKey = publicKey
            };
            var authEvent = CryptographicAuthority.CreateSignedEvent(
                approve ? "USER_APPROVED" : "USER_REJECTED",
                userId,
                deviceId,
                session!.UserId,
                "Admin",
                payload);

            if (!UserRepository.ApplyRegistrationDecision(userId, deviceId, publicKey, approve))
                return Fail(AdminActionResult.ValidationError, "The registration changed before it could be decided.");

            try
            {
                UserRepository.RecordAuthorizationEvent(authEvent);
            }
            catch
            {
                return Fail(AdminActionResult.DatabaseError, "The authorization event could not be persisted.");
            }

            AuditRepository.Log(
                approve ? "USER_APPROVED" : "USER_REJECTED",
                session.Username,
                session.DeviceId,
                $"User:{userId},Device:{deviceId}",
                "Success");
            return Ok(approve
                ? $"User '{user.Username}' and device '{deviceId}' approved."
                : $"Registration for user '{user.Username}' rejected.");
        }

        public static AdminResult DisableUser(AppSession? session, long targetUserId)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanSuspendUsers(session))
                return Fail(AdminActionResult.Unauthorized, "Admin or UserManagement supervisor permission required.");

            UserRecord? target = UserRepository.FindById(targetUserId);
            if (target == null)
                return Fail(AdminActionResult.UserNotFound, "User not found.");

            if (IsPermanentAdminTarget(target.Id))
                return Fail(AdminActionResult.Unauthorized, "The permanent Administrator cannot be disabled.");

            // Prevent admin/supervisor from disabling themselves
            if (target.Id == session!.UserId)
                return Fail(AdminActionResult.ValidationError, "You cannot disable your own account.");

            bool ok = UserRepository.SetActive(targetUserId, false);
            UserRepository.SetAccountState(targetUserId, AccountStates.Suspended);

            AuditRepository.Log("UserDisabled",
                session.Username, session.DeviceId,
                target.Username, ok ? "Success" : "Failed");

            return ok ? Ok($"User '{target.Username}' disabled.")
                      : Fail(AdminActionResult.DatabaseError, "Failed to disable user.");
        }

        public static AdminResult GrantSupervisor(
            AppSession? adminSession, long targetUserId, string deviceId, IEnumerable<string> permissions,
            string? publicKey = null)
        {
            if (!IsAdmin(adminSession))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can grant Supervisor authority.");

            UserRecord? target = UserRepository.FindById(targetUserId);
            DeviceRecord? device = UserRepository.FindDevice(deviceId);
            var requested = new HashSet<string>(permissions ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            foreach (string permission in requested)
            {
                if (!Permissions.AllSupervisorPermissions.Contains(permission, StringComparer.OrdinalIgnoreCase))
                    return Fail(AdminActionResult.ValidationError, $"Unknown Supervisor permission '{permission}'.");
            }

            if (target == null) return Fail(AdminActionResult.UserNotFound, "User not found.");
            if (device == null) return Fail(AdminActionResult.DeviceNotFound, "Device not found.");
            if (device.UserId != targetUserId ||
                (!string.IsNullOrWhiteSpace(publicKey) && !string.Equals(device.PublicKey, publicKey, StringComparison.Ordinal)) ||
                !UserRepository.IsDeviceAuthorized(deviceId) ||
                !target.IsActive || !string.Equals(target.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(target.Role, "Admin", StringComparison.OrdinalIgnoreCase))
                return Fail(AdminActionResult.ValidationError, "Target must be an active user with an authorized device.");

            if (!UserRepository.SetUserRole(targetUserId, "Supervisor"))
                return Fail(AdminActionResult.DatabaseError, "Failed to grant Supervisor role.");
            UserRepository.SetSupervisorPermissions(targetUserId, requested, adminSession!.UserId);
            var evt = CryptographicAuthority.CreateSignedEvent(
                "SUPERVISOR_GRANTED", targetUserId, deviceId, adminSession.UserId, "Admin",
                new CryptographicAuthority.SupervisorEventPayload
                {
                    TargetUserId = targetUserId,
                    TargetDeviceId = deviceId,
                    Permissions = requested.ToArray()
                });
            UserRepository.RecordAuthorizationEvent(evt);
            AuditRepository.Log("SupervisorGranted", adminSession.Username, adminSession.DeviceId,
                $"User:{targetUserId},Device:{deviceId}", string.Join(",", requested));
            return Ok($"Supervisor authority granted to '{target.Username}'.");
        }

        public static AdminResult RevokeSupervisor(AppSession? adminSession, long targetUserId, string deviceId)
        {
            if (!IsAdmin(adminSession))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can revoke Supervisor authority.");
            UserRecord? target = UserRepository.FindById(targetUserId);
            DeviceRecord? device = UserRepository.FindDevice(deviceId);
            if (target == null) return Fail(AdminActionResult.UserNotFound, "User not found.");
            if (device == null || device.UserId != targetUserId)
                return Fail(AdminActionResult.ValidationError, "The target device does not belong to the user.");
            if (!string.Equals(target.Role, "Supervisor", StringComparison.OrdinalIgnoreCase))
                return Fail(AdminActionResult.ValidationError, "Only an existing Supervisor can be revoked.");
            if (!UserRepository.SetUserRole(targetUserId, "User"))
                return Fail(AdminActionResult.DatabaseError, "Failed to revoke Supervisor role.");
            UserRepository.SetSupervisorPermissions(targetUserId, Array.Empty<string>(), adminSession!.UserId);
            var evt = CryptographicAuthority.CreateSignedEvent(
                "SUPERVISOR_REVOKED", targetUserId, deviceId, adminSession.UserId, "Admin",
                new CryptographicAuthority.SupervisorEventPayload
                {
                    TargetUserId = targetUserId,
                    TargetDeviceId = deviceId,
                    Permissions = Array.Empty<string>()
                });
            UserRepository.RecordAuthorizationEvent(evt);
            AuditRepository.Log("SupervisorRevoked", adminSession.Username, adminSession.DeviceId,
                $"User:{targetUserId},Device:{deviceId}", "Success");
            return Ok($"Supervisor authority revoked for '{target.Username}'.");
        }

        public static AdminResult UpdateSupervisorPermissions(
            AppSession? adminSession, long targetUserId, string deviceId, IEnumerable<string> permissions)
        {
            if (!IsAdmin(adminSession))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can change Supervisor permissions.");

            UserRecord? target = UserRepository.FindById(targetUserId);
            DeviceRecord? device = UserRepository.FindDevice(deviceId);
            var requested = new HashSet<string>(permissions ?? Array.Empty<string>(), StringComparer.OrdinalIgnoreCase);
            if (target == null) return Fail(AdminActionResult.UserNotFound, "User not found.");
            if (device == null || device.UserId != targetUserId || !string.Equals(target.Role, "Supervisor", StringComparison.OrdinalIgnoreCase))
                return Fail(AdminActionResult.ValidationError, "The target is not an active Supervisor device.");
            if (!target.IsActive || !string.Equals(target.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                !UserRepository.IsDeviceAuthorized(deviceId))
                return Fail(AdminActionResult.ValidationError, "The target Supervisor is not active and authorized.");
            if (requested.Any(p => !Permissions.AllSupervisorPermissions.Contains(p, StringComparer.OrdinalIgnoreCase)))
                return Fail(AdminActionResult.ValidationError, "Unknown Supervisor permission.");

            UserRepository.SetSupervisorPermissions(targetUserId, requested, adminSession!.UserId);
            var evt = CryptographicAuthority.CreateSignedEvent(
                "SUPERVISOR_GRANTED", targetUserId, deviceId, adminSession.UserId, "Admin",
                new CryptographicAuthority.SupervisorEventPayload
                {
                    TargetUserId = targetUserId,
                    TargetDeviceId = deviceId,
                    Permissions = requested.ToArray()
                });
            UserRepository.RecordAuthorizationEvent(evt);
            AuditRepository.Log("SupervisorPermissionsChanged", adminSession.Username, adminSession.DeviceId,
                $"User:{targetUserId},Device:{deviceId}", string.Join(",", requested));
            return Ok($"Supervisor permissions updated for '{target.Username}'.");
        }

        public static AdminResult EnableUser(AppSession? session, long targetUserId)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanApproveUsers(session))
                return Fail(AdminActionResult.Unauthorized, "Admin or UserManagement supervisor permission required.");

            UserRecord? target = UserRepository.FindById(targetUserId);
            if (target == null)
                return Fail(AdminActionResult.UserNotFound, "User not found.");

            if (IsPermanentAdminTarget(target.Id))
                return Fail(AdminActionResult.Unauthorized, "The permanent Administrator cannot be enabled.");

            bool ok = UserRepository.SetActive(targetUserId, true);
            UserRepository.SetAccountState(targetUserId, AccountStates.Active);

            AuditRepository.Log("UserEnabled",
                session!.Username, session.DeviceId,
                target.Username, ok ? "Success" : "Failed");

            return ok ? Ok($"User '{target.Username}' enabled.")
                      : Fail(AdminActionResult.DatabaseError, "Failed to enable user.");
        }

        // ──────────────────────────────────────────────────
        // DEVICE MANAGEMENT (Admin or Supervisor with DeviceManagement)
        // ──────────────────────────────────────────────────

        public static AdminResult RevokeDevice(AppSession? session, string deviceId)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanRevokeDevices(session))
                return Fail(AdminActionResult.Unauthorized, "Admin or DeviceManagement supervisor permission required.");

            DeviceRecord? device = UserRepository.FindDevice(deviceId);
            if (device == null)
                return Fail(AdminActionResult.DeviceNotFound, "Device not found.");

            if (IsPermanentAdminTarget(device.UserId))
                return Fail(AdminActionResult.Unauthorized, "The permanent Administrator device cannot be revoked.");

            // Prevent admin/supervisor from revoking their own device
            if (deviceId == session!.DeviceId)
                return Fail(AdminActionResult.ValidationError, "You cannot revoke your own device.");

            bool ok = UserRepository.SetDeviceRevoked(deviceId, true);

            var authEvt = CryptographicAuthority.CreateSignedEvent(
                "DEVICE_REVOKED", device.UserId, deviceId, session.UserId, session.Role,
                new { DeviceId = deviceId });
            UserRepository.RecordAuthorizationEvent(authEvt);

            AuditRepository.Log("DeviceRevoked",
                session.Username, session.DeviceId,
                deviceId, ok ? "Success" : "Failed");

            return ok ? Ok($"Device '{deviceId}' revoked.")
                      : Fail(AdminActionResult.DatabaseError, "Failed to revoke device.");
        }

        public static AdminResult RestoreDevice(AppSession? session, string deviceId)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanApproveDevices(session))
                return Fail(AdminActionResult.Unauthorized, "Admin or DeviceManagement supervisor permission required.");

            var device = UserRepository.FindDevice(deviceId);
            if (device == null)
                return Fail(AdminActionResult.DeviceNotFound, "Device not found.");
            if (IsPermanentAdminTarget(device.UserId))
                return Fail(AdminActionResult.Unauthorized, "The permanent Administrator device cannot be restored.");

            bool ok = UserRepository.SetDeviceRevoked(deviceId, false);

            var authEvt = CryptographicAuthority.CreateSignedEvent(
                "DEVICE_AUTHORIZED", null, deviceId, session!.UserId, session.Role,
                new { DeviceId = deviceId });
            UserRepository.RecordAuthorizationEvent(authEvt);

            AuditRepository.Log("DeviceRestored",
                session.Username, session.DeviceId,
                deviceId, ok ? "Success" : "Failed");

            return ok ? Ok($"Device '{deviceId}' authorization restored.")
                      : Fail(AdminActionResult.DatabaseError, "Failed to restore device.");
        }

        public static (AdminResult Result, string TempPassword) ResetUserAccess(
            AppSession? session, long targetUserId)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanApproveUsers(session))
                return (Fail(AdminActionResult.Unauthorized, "Admin or UserManagement supervisor permission required."), "");

            if (IsPermanentAdminTarget(targetUserId))
                return (Fail(AdminActionResult.Unauthorized, "The permanent Administrator access cannot be reset."), "");

            var (ok, error, tempPwd) = AuthenticationService.AdminResetAccess(
                session!.UserId, targetUserId);

            return ok
                ? (Ok("Access reset. Provide the temporary password to the user."), tempPwd)
                : (Fail(AdminActionResult.DatabaseError, error), "");
        }

        // ──────────────────────────────────────────────────
        // ACTING ADMIN LEASE MANAGEMENT (Only Permanent Admin)
        // ──────────────────────────────────────────────────

        public static AdminResult GrantActingAdminLease(
            AppSession? adminSession,
            long supervisorUserId,
            int leaseHours,
            string? deviceId = null,
            string? publicKey = null)
        {
            if (!IsAdmin(adminSession))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can issue Acting Admin leases.");

            UserRecord? supervisor = UserRepository.FindById(supervisorUserId);
            if (supervisor == null || !string.Equals(supervisor.Role, "Supervisor", StringComparison.OrdinalIgnoreCase))
                return Fail(AdminActionResult.ValidationError, "Acting Admin lease can only be granted to an active Supervisor.");

            DeviceRecord? supervisorDevice = string.IsNullOrWhiteSpace(deviceId)
                ? UserRepository.FindDeviceByUserId(supervisorUserId)
                : UserRepository.FindDevice(deviceId);
            if (supervisorDevice == null || !supervisor.IsActive ||
                supervisorDevice.UserId != supervisorUserId ||
                (!string.IsNullOrWhiteSpace(publicKey) && !string.Equals(supervisorDevice.PublicKey, publicKey, StringComparison.Ordinal)) ||
                !string.Equals(supervisor.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                !UserRepository.IsDeviceAuthorized(supervisorDevice.DeviceId))
                return Fail(AdminActionResult.ValidationError, "Acting Admin requires an active Supervisor with an authorized device.");

            var currentAuth = UserRepository.GetAuthorityState();
            int newEpoch = (currentAuth?.CurrentEpoch ?? 1) + 1;
            DateTime expiry = DateTime.UtcNow.AddHours(Math.Clamp(leaseHours, 1, 24));
            string leaseId = Guid.NewGuid().ToString();

            UserRepository.SetAuthorityState(newEpoch, adminSession!.UserId, adminSession.DeviceId,
                supervisorUserId, expiry, leaseId);

            var authEvt = CryptographicAuthority.CreateSignedEvent(
                "ACTING_ADMIN_GRANTED", supervisorUserId, supervisorDevice.DeviceId, adminSession.UserId, "Admin",
                new CryptographicAuthority.ActingAdminLeasePayload
                {
                    TargetUserId = supervisorUserId,
                    TargetDeviceId = supervisorDevice.DeviceId,
                    Epoch = newEpoch,
                    ExpiresAtUtc = expiry,
                    LeaseId = leaseId
                });
            UserRepository.SetAuthorityState(newEpoch, adminSession.UserId, adminSession.DeviceId,
                supervisorUserId, expiry, authEvt.Signature);
            UserRepository.RecordAuthorizationEvent(authEvt);

            AuditRepository.Log("ActingAdminGranted", adminSession.Username, adminSession.DeviceId,
                supervisor.Username, $"Epoch:{newEpoch}, Expiry:{expiry:O}");

            return Ok($"Acting Admin lease successfully granted to '{supervisor.Username}' until {expiry:g} UTC (Epoch {newEpoch}).");
        }

        public static AdminResult RevokeActingAdminLease(AppSession? adminSession)
        {
            if (!IsAdmin(adminSession))
                return Fail(AdminActionResult.Unauthorized, "Only the permanent Administrator can revoke Acting Admin leases.");

            var currentAuth = UserRepository.GetAuthorityState();
            if (currentAuth == null || currentAuth.ActingAdminUserId == null)
                return Ok("No active Acting Admin lease exists.");

            int newEpoch = currentAuth.CurrentEpoch + 1;
            DeviceRecord? actingDevice = UserRepository.FindDeviceByUserId(currentAuth.ActingAdminUserId.Value);
            UserRepository.SetAuthorityState(newEpoch, adminSession!.UserId, adminSession.DeviceId,
                null, null, null);

            var authEvt = CryptographicAuthority.CreateSignedEvent(
                "ACTING_ADMIN_REVOKED", currentAuth.ActingAdminUserId,
                actingDevice?.DeviceId, adminSession.UserId, "Admin",
                new CryptographicAuthority.ActingAdminLeasePayload
                {
                    TargetUserId = currentAuth.ActingAdminUserId.Value,
                    TargetDeviceId = actingDevice?.DeviceId ?? "",
                    Epoch = newEpoch,
                    ExpiresAtUtc = DateTime.UtcNow,
                    LeaseId = currentAuth.EpochSignature ?? Guid.NewGuid().ToString()
                });
            UserRepository.RecordAuthorizationEvent(authEvt);

            AuditRepository.Log("ActingAdminRevoked", adminSession.Username, adminSession.DeviceId,
                "ActingAdmin", $"RevertedToPermanentAdmin, Epoch:{newEpoch}");

            return Ok($"Acting Admin lease revoked. Root authority active on Epoch {newEpoch}.");
        }

        // ──────────────────────────────────────────────────
        // QUERIES
        // ──────────────────────────────────────────────────

        public static List<UserRecord> GetAllUsers(AppSession? session)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanViewUsers(session))
                return new();
            return UserRepository.GetAllUsers();
        }

        public static List<DeviceRecord> GetAllDevices(AppSession? session)
        {
            if (!IsAdmin(session) && !AuthorizationService.CanViewDevices(session))
                return new();
            return UserRepository.GetAllDevices();
        }

        // ──────────────────────────────────────────────────
        // HELPERS
        // ──────────────────────────────────────────────────

        private static bool IsPermanentAdminTarget(long userId)
        {
            var authority = UserRepository.GetAuthorityState();
            return authority != null && authority.AdminUserId == userId;
        }

        private static bool IsPermanentAdminTarget(string deviceId)
        {
            var authority = UserRepository.GetAuthorityState();
            return authority != null &&
                   string.Equals(authority.AdminDeviceId, deviceId, StringComparison.OrdinalIgnoreCase);
        }

        private static AdminResult Ok(string msg) =>
            new() { Code = AdminActionResult.Success, Message = msg };

        private static AdminResult Fail(AdminActionResult code, string msg) =>
            new() { Code = code, Message = msg };
    }
}
