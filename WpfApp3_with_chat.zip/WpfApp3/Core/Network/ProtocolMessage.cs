using System;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;

namespace WpfApp3.Core.Network
{
    public static class ProtocolMessageTypes
    {
        public const string Discovery        = "DISCOVERY";
        public const string HandshakeHello   = "HANDSHAKE_HELLO";
        public const string AuthChallenge    = "AUTH_CHALLENGE";
        public const string AuthResponse     = "AUTH_RESPONSE";
        public const string SessionAck       = "SESSION_ACK";
        public const string Chat             = "CHAT";
        public const string FileTransferReq  = "FILE_TRANSFER_REQ";
        public const string FileTransferAck  = "FILE_TRANSFER_ACK";
        public const string MetadataSync     = "METADATA_SYNC";
        public const string AuditSync        = "AUDIT_SYNC";
        public const string AuthEventSync    = "AUTH_EVENT_SYNC";
        public const string Heartbeat        = "HEARTBEAT";
        public const string Disconnect       = "DISCONNECT";
    }

    /// <summary>
    /// Unified application protocol envelope for all P2P network messages.
    /// Provides versioning, replay protection, message validation, and optional cryptographic signatures.
    /// </summary>
    public class ProtocolMessage
    {
        public string MessageType { get; set; } = "";
        public string ProtocolVersion { get; set; } = "1.0";
        public string MessageId { get; set; } = Guid.NewGuid().ToString();
        public string SenderDeviceId { get; set; } = "";
        public string Timestamp { get; set; } = DateTime.UtcNow.ToString("O");
        public string? PayloadJson { get; set; }
        public string? Signature { get; set; }

        private static readonly TimeSpan MaxClockSkew = TimeSpan.FromMinutes(2);
        private static readonly ConcurrentDictionary<string, DateTime> SeenMessageCache = new();

        public static ProtocolMessage Create<T>(
            string messageType,
            string senderDeviceId,
            T payload,
            X509Certificate2? signingCert = null)
        {
            var msg = new ProtocolMessage
            {
                MessageType = messageType,
                ProtocolVersion = "1.0",
                MessageId = Guid.NewGuid().ToString(),
                SenderDeviceId = senderDeviceId,
                Timestamp = DateTime.UtcNow.ToString("O"),
                PayloadJson = JsonSerializer.Serialize(payload)
            };

            if (signingCert != null)
            {
                msg.Sign(signingCert);
            }

            return msg;
        }

        public void Sign(X509Certificate2 cert)
        {
            using RSA? rsa = cert.GetRSAPrivateKey();
            if (rsa == null) return;

            string digest = ComputeDigest();
            byte[] dataBytes = Encoding.UTF8.GetBytes(digest);
            byte[] sigBytes = rsa.SignData(dataBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            Signature = Convert.ToBase64String(sigBytes);
        }

        public bool VerifySignature(X509Certificate2 cert)
        {
            if (string.IsNullOrWhiteSpace(Signature)) return false;

            try
            {
                using RSA? rsa = cert.GetRSAPublicKey();
                if (rsa == null) return false;

                string digest = ComputeDigest();
                byte[] dataBytes = Encoding.UTF8.GetBytes(digest);
                byte[] sigBytes = Convert.FromBase64String(Signature);
                return rsa.VerifyData(dataBytes, sigBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
            catch
            {
                return false;
            }
        }

        public string ComputeDigest()
        {
            return $"{MessageType}:{ProtocolVersion}:{MessageId}:{SenderDeviceId}:{Timestamp}:{PayloadJson ?? ""}";
        }

        /// <summary>
        /// Validates basic protocol formatting, version, timestamp drift, and anti-replay constraints.
        /// </summary>
        public bool Validate(out string error)
        {
            if (string.IsNullOrWhiteSpace(MessageType))
            {
                error = "MessageType is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(ProtocolVersion) || ProtocolVersion != "1.0")
            {
                error = $"Unsupported protocol version '{ProtocolVersion}'.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(MessageId))
            {
                error = "MessageId is required.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(SenderDeviceId))
            {
                error = "SenderDeviceId is required.";
                return false;
            }

            if (!DateTime.TryParse(Timestamp, out DateTime parsedTime))
            {
                error = "Invalid timestamp format.";
                return false;
            }

            DateTime utcNow = DateTime.UtcNow;
            if (Math.Abs((utcNow - parsedTime.ToUniversalTime()).TotalSeconds) > MaxClockSkew.TotalSeconds)
            {
                error = "Message timestamp rejected due to excessive clock skew (>120s).";
                return false;
            }

            // Anti-replay check
            if (!SeenMessageCache.TryAdd(MessageId, utcNow))
            {
                error = "Duplicate message detected (replay protection triggered).";
                return false;
            }

            // Cleanup old cache entries periodically
            if (SeenMessageCache.Count > 5000)
            {
                DateTime cutoff = utcNow - TimeSpan.FromMinutes(5);
                foreach (var kvp in SeenMessageCache)
                {
                    if (kvp.Value < cutoff)
                        SeenMessageCache.TryRemove(kvp.Key, out _);
                }
            }

            error = "";
            return true;
        }

        public T? DeserializePayload<T>()
        {
            if (string.IsNullOrWhiteSpace(PayloadJson)) return default;
            try
            {
                return JsonSerializer.Deserialize<T>(PayloadJson);
            }
            catch
            {
                return default;
            }
        }
    }
}
