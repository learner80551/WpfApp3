using System;
using WpfApp3.Authentication;
using WpfApp3.Database;

namespace WpfApp3.Core.Security
{
    public static class AuthorizationService
    {
        public static bool Authorize(AppSession? session, string permission, object? resource = null)
        {
            if (session == null)
                return false;

            UserRecord? user = UserRepository.FindById(session.UserId);
            if (user == null || !string.Equals(user.Username, session.Username, StringComparison.Ordinal) ||
                !string.Equals(user.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                !user.IsActive)
            {
                AuditRepository.Log("AuthorizationFailure", session.Username, session.DeviceId,
                    permission, "UserStateNotAuthorized");
                return false;
            }

            // 1. Account state enforcement
            if (!string.Equals(session.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("AuthorizationFailure", session.Username, session.DeviceId,
                    permission, $"AccountState:{session.AccountState}");
                return false;
            }

            // 2. Device trust & revocation enforcement
            DeviceRecord? dev = UserRepository.FindDevice(session.DeviceId);
            if (dev == null || dev.IsRevoked || !dev.IsAuthorized ||
                dev.UserId != session.UserId ||
                !string.Equals(dev.DeviceState, DeviceStates.Authorized, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("AuthorizationFailure", session.Username, session.DeviceId,
                    permission, "DeviceNotAuthorizedOrRevoked");
                return false;
            }

            // 3. Admin has root authority for all organizational operations
            if (string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            // 4. Supervisor permissions check
            if (string.Equals(user.Role, "Supervisor", StringComparison.OrdinalIgnoreCase))
            {
                if (IsActingAdmin(session) && !string.Equals(permission, "ADMIN_ROOT", StringComparison.OrdinalIgnoreCase))
                    return true;

                // Supervisors CANNOT perform root admin actions (e.g. creating another permanent admin)
                if (string.Equals(permission, "ADMIN_ROOT", StringComparison.OrdinalIgnoreCase))
                {
                    AuditRepository.Log("AuthorizationFailure", session.Username, session.DeviceId,
                        permission, "SupervisorCannotPerformAdminRoot");
                    return false;
                }

                bool hasPerm = UserRepository.HasSupervisorPermission(session.UserId, permission);
                if (!hasPerm)
                {
                    AuditRepository.Log("AuthorizationFailure", session.Username, session.DeviceId,
                        permission, "SupervisorMissingPermission");
                }
                return hasPerm;
            }

            // 5. User permissions: users cannot perform administrative or supervisory operations
            AuditRepository.Log("AuthorizationFailure", session.Username, session.DeviceId,
                permission, "UserDeniedPrivilegedOperation");
            return false;
        }

        public static bool CanViewUsers(AppSession? session) =>
            Authorize(session, Permissions.UserView);

        public static bool CanApproveUsers(AppSession? session) =>
            Authorize(session, Permissions.UserApprove);

        public static bool CanRejectUsers(AppSession? session) =>
            Authorize(session, Permissions.UserReject);

        public static bool CanSuspendUsers(AppSession? session) =>
            Authorize(session, Permissions.UserSuspend);

        public static bool CanRevokeUsers(AppSession? session) =>
            Authorize(session, Permissions.UserRevoke);

        public static bool CanViewDevices(AppSession? session) =>
            Authorize(session, Permissions.DeviceView);

        public static bool CanApproveDevices(AppSession? session) =>
            Authorize(session, Permissions.DeviceApprove);

        public static bool CanRevokeDevices(AppSession? session) =>
            Authorize(session, Permissions.DeviceRevoke);

        public static bool CanViewHistoryMetadata(AppSession? session)
        {
            bool ok = Authorize(session, Permissions.HistoryMetadataView);
            if (ok && session != null)
            {
                AuditRepository.Log("HISTORY_ACCESS", session.Username, session.DeviceId,
                    "MetadataHistory", "Allowed");
            }
            return ok;
        }

        public static bool CanViewAuditLogs(AppSession? session) =>
            Authorize(session, Permissions.AuditView);

        public static bool CanViewSecurityEvents(AppSession? session) =>
            Authorize(session, Permissions.SecurityEventView);

        public static bool IsDeviceAuthorized(string? deviceId = null, string? fingerprint = null, string? publicKey = null) =>
            UserRepository.IsDeviceAuthorized(deviceId, fingerprint, publicKey);

        public static bool IsPermanentAdmin(AppSession? session)
        {
            if (session == null) return false;
            var authority = UserRepository.GetAuthorityState();
            var user = UserRepository.FindById(session.UserId);
            return authority != null && user != null &&
                   user.Id == authority.AdminUserId &&
                   string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase) &&
                   string.Equals(user.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) &&
                   UserRepository.IsDeviceAuthorized(authority.AdminDeviceId) &&
                   string.Equals(session.DeviceId, authority.AdminDeviceId, StringComparison.OrdinalIgnoreCase);
        }

        public static bool IsActingAdmin(AppSession? session)
        {
            if (session == null) return false;
            var authority = UserRepository.GetAuthorityState();
            var user = UserRepository.FindById(session.UserId);
            var device = UserRepository.FindDevice(session.DeviceId);
            return authority != null && user != null && device != null &&
                   authority.ActingAdminUserId == user.Id &&
                   string.Equals(user.Role, "Supervisor", StringComparison.OrdinalIgnoreCase) &&
                   string.Equals(user.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) &&
                   user.IsActive && device.UserId == user.Id &&
                   UserRepository.IsDeviceAuthorized(session.DeviceId) &&
                   CryptographicAuthority.IsActingAdminValid(authority);
        }
    }
}
