using System;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Core.Security
{
    public static class CryptographicAuthority
    {
        public sealed class RegistrationEventPayload
        {
            public long TargetUserId { get; set; }
            public string TargetDeviceId { get; set; } = "";
            public string TargetPublicKey { get; set; } = "";
        }

        public sealed class SupervisorEventPayload
        {
            public long TargetUserId { get; set; }
            public string TargetDeviceId { get; set; } = "";
            public string[] Permissions { get; set; } = Array.Empty<string>();
        }

        public sealed class ActingAdminLeasePayload
        {
            public long TargetUserId { get; set; }
            public string TargetDeviceId { get; set; } = "";
            public int Epoch { get; set; }
            public DateTime ExpiresAtUtc { get; set; }
            public string LeaseId { get; set; } = "";
        }

        public static string ComputeSha256(string input)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(input);
            byte[] hash = SHA256.HashData(bytes);
            return Convert.ToHexString(hash);
        }

        public static string ComputeSha256(byte[] bytes)
        {
            byte[] hash = SHA256.HashData(bytes);
            return Convert.ToHexString(hash);
        }

        public static string SignData(string dataToSign)
        {
            X509Certificate2 cert = DeviceCertificate.GetOrCreateCertificate();
            using RSA? rsa = cert.GetRSAPrivateKey();
            if (rsa == null)
                throw new InvalidOperationException("Local device certificate does not contain an accessible RSA private key.");

            byte[] dataBytes = Encoding.UTF8.GetBytes(dataToSign);
            byte[] signature = rsa.SignData(dataBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            return Convert.ToBase64String(signature);
        }

        public static bool VerifySignature(string dataToVerify, string base64Signature, X509Certificate2 cert)
        {
            try
            {
                using RSA? rsa = cert.GetRSAPublicKey();
                if (rsa == null) return false;

                byte[] dataBytes = Encoding.UTF8.GetBytes(dataToVerify);
                byte[] sigBytes = Convert.FromBase64String(base64Signature);
                return rsa.VerifyData(dataBytes, sigBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
            catch
            {
                return false;
            }
        }

        public static bool VerifySignatureWithLocalCert(string dataToVerify, string base64Signature)
        {
            try
            {
                X509Certificate2 cert = DeviceCertificate.GetOrCreateCertificate();
                return VerifySignature(dataToVerify, base64Signature, cert);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Creates a signed authorization event from an authenticated authority.
        /// </summary>
        public static AuthorizationEventRecord CreateSignedEvent(
            string eventType,
            long? targetUserId,
            string? targetDeviceId,
            long authorityUserId,
            string authorityRole,
            object payload,
            int sequenceNumber = 0)
        {
            var authState = UserRepository.GetAuthorityState();
            int epoch = authState?.CurrentEpoch ?? 1;
            if (sequenceNumber <= 0)
            {
                sequenceNumber = UserRepository.GetAuthorizationEvents(10000)
                    .Where(e => e.AuthorityUserId == authorityUserId && e.Epoch == epoch)
                    .Select(e => e.SequenceNumber)
                    .DefaultIfEmpty(0)
                    .Max() + 1;
            }

            string payloadJson = JsonSerializer.Serialize(payload);
            string digestInput = $"{eventType}:{epoch}:{sequenceNumber}:{authorityUserId}:{payloadJson}";
            string payloadHash = ComputeSha256(digestInput);
            string signature = SignData(payloadHash);

            return new AuthorizationEventRecord
            {
                EventId         = Guid.NewGuid().ToString(),
                EventType       = eventType,
                UserId          = targetUserId,
                DeviceId        = targetDeviceId,
                AuthorityUserId = authorityUserId,
                AuthorityRole   = authorityRole,
                Epoch           = epoch,
                SequenceNumber  = sequenceNumber,
                PayloadJson     = payloadJson,
                PayloadHash     = payloadHash,
                Signature       = signature,
                Timestamp       = DateTime.UtcNow,
                ProcessedAt     = DateTime.UtcNow
            };
        }

        /// <summary>
        /// Validates, checks replay protection, and records an incoming authorization event.
        /// </summary>
        public static (bool Success, string Reason) ProcessAuthorizationEvent(
            AuthorizationEventRecord evt,
            X509Certificate2? authorityCert = null)
        {
            if (evt == null || string.IsNullOrWhiteSpace(evt.EventId) ||
                string.IsNullOrWhiteSpace(evt.EventType) || evt.AuthorityUserId <= 0 ||
                evt.Epoch <= 0 || evt.SequenceNumber <= 0 ||
                string.IsNullOrWhiteSpace(evt.PayloadJson) ||
                string.IsNullOrWhiteSpace(evt.Signature))
                return (false, "Event cannot be null.");

            if (UserRepository.IsEventProcessed(evt.EventId))
                return (true, "Event already processed (ignored safely).");

            if (UserRepository.IsAuthorizationSequenceProcessed(
                    evt.AuthorityUserId, evt.Epoch, evt.SequenceNumber))
                return (false, "Authorization event sequence has already been processed.");

            string digestInput = $"{evt.EventType}:{evt.Epoch}:{evt.SequenceNumber}:{evt.AuthorityUserId}:{evt.PayloadJson}";
            string computedHash = ComputeSha256(digestInput);
            if (!string.Equals(computedHash, evt.PayloadHash, StringComparison.OrdinalIgnoreCase))
                return (false, "Payload hash mismatch. Event may have been tampered with.");

            var currentAuthState = UserRepository.GetAuthorityState();
            UserRecord? authorityUser = UserRepository.FindById(evt.AuthorityUserId);
            bool advancesEpoch = evt.EventType is "ACTING_ADMIN_GRANTED" or "ACTING_ADMIN_REVOKED";
            if (currentAuthState == null || authorityUser == null ||
                evt.Epoch != currentAuthState.CurrentEpoch + (advancesEpoch ? 1 : 0) ||
                evt.AuthorityUserId != currentAuthState.AdminUserId ||
                !string.Equals(authorityUser.Role, "Admin", StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(authorityUser.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(evt.AuthorityRole, "Admin", StringComparison.OrdinalIgnoreCase))
                return (false, "Event issuer is not the current permanent administrator.");

            DeviceRecord? adminDevice = UserRepository.FindDevice(currentAuthState.AdminDeviceId);
            if (adminDevice == null || adminDevice.UserId != authorityUser.Id ||
                string.IsNullOrWhiteSpace(adminDevice.PublicKey))
                return (false, "Permanent administrator device identity is unavailable.");

            X509Certificate2 signer;
            try
            {
                signer = authorityCert ?? DeviceCertificate.GetOrCreateCertificate();
                using RSA? rsa = signer.GetRSAPublicKey();
                string signerKey = rsa == null
                    ? ""
                    : Convert.ToBase64String(rsa.ExportSubjectPublicKeyInfo());
                if (!string.Equals(signerKey, adminDevice.PublicKey, StringComparison.Ordinal))
                    return (false, "Event signer does not match the administrator public key.");
            }
            catch
            {
                return (false, "Event signer identity could not be established.");
            }

            if (!VerifySignature(evt.PayloadHash, evt.Signature, signer))
                return (false, "Invalid cryptographic signature on authorization event.");

            if (evt.EventType is "USER_APPROVED" or "USER_REJECTED")
            {
                RegistrationEventPayload? registration;
                try
                {
                    registration = JsonSerializer.Deserialize<RegistrationEventPayload>(evt.PayloadJson);
                }
                catch
                {
                    return (false, "Registration event payload is invalid.");
                }

                if (registration == null || registration.TargetUserId != evt.UserId ||
                    !string.Equals(registration.TargetDeviceId, evt.DeviceId, StringComparison.Ordinal) ||
                    string.IsNullOrWhiteSpace(registration.TargetPublicKey))
                    return (false, "Registration event target identity is invalid.");

                bool approve = evt.EventType == "USER_APPROVED";
                if (!UserRepository.ApplyRegistrationDecision(
                        registration.TargetUserId,
                        registration.TargetDeviceId,
                        registration.TargetPublicKey,
                        approve))
                    return (false, "Registration target is missing, mismatched, or no longer pending.");
            }
            else if (evt.EventType is "SUPERVISOR_GRANTED" or "SUPERVISOR_REVOKED")
            {
                SupervisorEventPayload? supervisor;
                try { supervisor = JsonSerializer.Deserialize<SupervisorEventPayload>(evt.PayloadJson); }
                catch { return (false, "Supervisor event payload is invalid."); }

                if (supervisor == null || supervisor.TargetUserId != evt.UserId ||
                    !string.Equals(supervisor.TargetDeviceId, evt.DeviceId, StringComparison.Ordinal) ||
                    supervisor.Permissions.Any(p => !Permissions.AllSupervisorPermissions.Contains(p, StringComparer.OrdinalIgnoreCase)))
                    return (false, "Supervisor event target or permissions are invalid.");

                UserRecord? targetUser = UserRepository.FindById(supervisor.TargetUserId);
                DeviceRecord? targetDevice = UserRepository.FindDevice(supervisor.TargetDeviceId);
                if (targetUser == null || targetDevice == null || targetDevice.UserId != targetUser.Id ||
                    !targetUser.IsActive || !string.Equals(targetUser.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                    !UserRepository.IsDeviceAuthorized(targetDevice.DeviceId) ||
                    string.Equals(targetUser.Role, "Admin", StringComparison.OrdinalIgnoreCase))
                    return (false, "Supervisor target is not an eligible active authorized user.");

                bool grant = evt.EventType == "SUPERVISOR_GRANTED";
                if (!UserRepository.SetUserRole(targetUser.Id, grant ? "Supervisor" : "User"))
                    return (false, "Supervisor role transition failed.");
                UserRepository.SetSupervisorPermissions(targetUser.Id,
                    grant ? supervisor.Permissions : Array.Empty<string>(), evt.AuthorityUserId);
            }
            else if (evt.EventType is "ACTING_ADMIN_GRANTED" or "ACTING_ADMIN_REVOKED")
            {
                ActingAdminLeasePayload? lease;
                try { lease = JsonSerializer.Deserialize<ActingAdminLeasePayload>(evt.PayloadJson); }
                catch { return (false, "Acting Admin lease payload is invalid."); }

                if (lease == null || lease.TargetUserId != evt.UserId ||
                    !string.Equals(lease.TargetDeviceId, evt.DeviceId, StringComparison.Ordinal) ||
                    lease.Epoch != evt.Epoch || string.IsNullOrWhiteSpace(lease.LeaseId))
                    return (false, "Acting Admin lease target is invalid.");

                UserRecord? targetUser = UserRepository.FindById(lease.TargetUserId);
                DeviceRecord? targetDevice = UserRepository.FindDevice(lease.TargetDeviceId);
                if (targetUser == null || targetDevice == null || targetDevice.UserId != targetUser.Id ||
                    !string.Equals(targetUser.Role, "Supervisor", StringComparison.OrdinalIgnoreCase) ||
                    !targetUser.IsActive || !string.Equals(targetUser.AccountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase) ||
                    !UserRepository.IsDeviceAuthorized(targetDevice.DeviceId))
                    return (false, "Acting Admin target is not an eligible active Supervisor.");

                if (evt.EventType == "ACTING_ADMIN_GRANTED" && lease.ExpiresAtUtc <= DateTime.UtcNow)
                    return (false, "Acting Admin lease has already expired.");

                var localAuthority = UserRepository.GetAuthorityState();
                if (localAuthority == null || lease.Epoch != localAuthority.CurrentEpoch + 1)
                    return (false, "Acting Admin lease epoch is stale.");

                if (evt.EventType == "ACTING_ADMIN_GRANTED")
                    UserRepository.SetAuthorityState(lease.Epoch, localAuthority.AdminUserId, localAuthority.AdminDeviceId,
                        lease.TargetUserId, lease.ExpiresAtUtc, evt.Signature);
                else
                    UserRepository.SetAuthorityState(localAuthority.CurrentEpoch + 1, localAuthority.AdminUserId,
                        localAuthority.AdminDeviceId, null, null, null);
            }

            evt.ProcessedAt = DateTime.UtcNow;
            UserRepository.RecordAuthorizationEvent(evt);

            return (true, "Event processed and applied successfully.");
        }

        /// <summary>
        /// Checks if Acting Admin lease is active or expired.
        /// </summary>
        public static bool IsActingAdminValid(AuthorityStateRecord authState)
        {
            if (authState.ActingAdminUserId == null || authState.ActingAdminLeaseExpiry == null)
                return false;

            return DateTime.UtcNow < authState.ActingAdminLeaseExpiry.Value.ToUniversalTime();
        }
    }
}
