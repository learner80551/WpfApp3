using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using WpfApp3.Database;

namespace WpfApp3.Core.Groups
{
    public class GroupManager
    {
        private readonly ConcurrentDictionary<string, GroupRecord> _groups = new(StringComparer.OrdinalIgnoreCase);

        public event Action<GroupRecord>? GroupCreated;
        public event Action<GroupRecord>? GroupUpdated;
        public event Action<string>? GroupDeleted;

        public GroupManager()
        {
            Refresh();
        }

        public void Refresh()
        {
            _groups.Clear();
            var list = GroupRepository.GetGroups();
            foreach (var g in list)
            {
                g.MemberDeviceIds = GroupRepository.GetGroupMembers(g.GroupId);
                _groups[g.GroupId] = g;
            }
        }

        public bool CreateGroup(string name, string description, string createdBy, out string groupId)
        {
            groupId = $"GRP-{Guid.NewGuid().ToString()[..8].ToUpperInvariant()}";
            bool ok = GroupRepository.CreateGroup(groupId, name, description, createdBy);
            if (ok)
            {
                var record = new GroupRecord
                {
                    GroupId = groupId,
                    Name = name,
                    Description = description,
                    CreatedBy = createdBy,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };
                _groups[groupId] = record;
                GroupCreated?.Invoke(record);
                return true;
            }
            return false;
        }

        public bool AddMember(string groupId, string deviceId, string role = "Member")
        {
            bool ok = GroupRepository.AddMember(groupId, deviceId, role);
            if (ok && _groups.TryGetValue(groupId, out var g))
            {
                if (!g.MemberDeviceIds.Contains(deviceId, StringComparer.OrdinalIgnoreCase))
                {
                    g.MemberDeviceIds.Add(deviceId);
                    GroupUpdated?.Invoke(g);
                }
            }
            return ok;
        }

        public bool RemoveMember(string groupId, string deviceId)
        {
            bool ok = GroupRepository.RemoveMember(groupId, deviceId);
            if (ok && _groups.TryGetValue(groupId, out var g))
            {
                g.MemberDeviceIds.RemoveAll(d => string.Equals(d, deviceId, StringComparison.OrdinalIgnoreCase));
                GroupUpdated?.Invoke(g);
            }
            return ok;
        }

        public IReadOnlyList<GroupRecord> GetAllGroups() => _groups.Values.ToList();

        public GroupRecord? GetGroup(string groupId)
        {
            _groups.TryGetValue(groupId, out var g);
            return g;
        }

        public List<GroupRecord> GetGroupsForDevice(string deviceId)
        {
            return _groups.Values
                .Where(g => g.MemberDeviceIds.Contains(deviceId, StringComparer.OrdinalIgnoreCase))
                .ToList();
        }

        public bool DeleteGroup(string groupId)
        {
            // Persist first: the in-memory cache should only drop the group
            // once the repository record is actually gone, otherwise a reload
            // (Refresh) would resurrect a group the UI just deleted.
            bool ok = GroupRepository.DeleteGroup(groupId);
            if (ok)
            {
                _groups.TryRemove(groupId, out _);
                GroupDeleted?.Invoke(groupId);
            }
            return ok;
        }
    }
}
