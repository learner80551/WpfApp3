using System;
using System.Collections.Generic;
using WpfApp3.Core.Devices;
using WpfApp3.Core.Messaging;
using WpfApp3.Core.Transfers;
using WpfApp3.Database;

namespace WpfApp3.Core.Search
{
    public class GlobalSearchResult
    {
        public string Category { get; set; } = ""; // "Device", "Message", "Transfer", "Audit"
        public string Title { get; set; } = "";
        public string Subtitle { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public object? RawItem { get; set; }
    }

    public static class GlobalSearchService
    {
        public static List<GlobalSearchResult> Search(string query, DeviceManager? deviceManager = null, int maxPerCategory = 10)
        {
            var results = new List<GlobalSearchResult>();
            if (string.IsNullOrWhiteSpace(query)) return results;
            string q = query.Trim();

            // 1. Devices
            if (deviceManager != null)
            {
                var matchedDevices = deviceManager.Search(q);
                foreach (var d in matchedDevices)
                {
                    results.Add(new GlobalSearchResult
                    {
                        Category = "Device",
                        Title = d.DisplayName,
                        Subtitle = $"{d.DeviceId} • {d.IpAddress} • {d.Status}",
                        Timestamp = d.LastSeenUtc,
                        RawItem = d
                    });
                }
            }

            // 2. Messages
            var messages = MessageRepository.Search(q, maxPerCategory);
            foreach (var m in messages)
            {
                results.Add(new GlobalSearchResult
                {
                    Category = "Message",
                    Title = $"{m.SenderUsername}: {m.Text}",
                    Subtitle = m.IsGroupMessage ? $"Group: {m.GroupId}" : (m.IsDirectMessage ? $"To: {m.ReceiverDeviceId}" : "Broadcast"),
                    Timestamp = m.Timestamp,
                    RawItem = m
                });
            }

            // 3. Transfers
            var history = TransferRepository.GetHistory(maxPerCategory * 2);
            foreach (var t in history)
            {
                if ((t.Sha256 != null && t.Sha256.Contains(q, StringComparison.OrdinalIgnoreCase)) ||
                    t.RemoteDeviceId.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                    t.TargetDirectory.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                    t.TransferId.Contains(q, StringComparison.OrdinalIgnoreCase))
                {
                    results.Add(new GlobalSearchResult
                    {
                        Category = "Transfer",
                        Title = $"{t.Direction}: {t.TotalFiles} file(s) ({t.TotalBytes:N0} bytes)",
                        Subtitle = $"Peer: {t.RemoteDeviceId} • Status: {t.Status}",
                        Timestamp = t.CreatedAt,
                        RawItem = t
                    });
                }
            }

            // 4. Audit Logs
            var audits = Auditing.AuditSyncService.GetRecentAuditEvents(maxPerCategory * 2);
            foreach (var a in audits)
            {
                if (a.EventType.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                    a.Actor.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                    a.Description.Contains(q, StringComparison.OrdinalIgnoreCase))
                {
                    results.Add(new GlobalSearchResult
                    {
                        Category = "Audit",
                        Title = $"{a.EventType} by {a.Actor}",
                        Subtitle = a.Description,
                        Timestamp = a.Timestamp,
                        RawItem = a
                    });
                }
            }

            return results;
        }
    }
}
