using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp3.Authentication;
using WpfApp3.Core.Groups;
using WpfApp3.Core.Messaging;
using WpfApp3.Database;

namespace WpfApp3.UI.Chat
{
    public class GroupListItem
    {
        public string GroupId { get; set; } = "";
        public string Name { get; set; } = "";
        public int MemberCount { get; set; }
    }

    public class GroupMessageViewModel
    {
        public string SenderUsername { get; set; } = "";
        public string Text { get; set; } = "";
        public string TimeDisplay { get; set; } = "";
        public bool IsSelf { get; set; }
    }

    /// <summary>A device that can be checked on/off when picking group members.</summary>
    public class SelectableDevice
    {
        public string DeviceId { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public bool IsChecked { get; set; }
    }

    public partial class GroupsPanel : UserControl
    {
        private GroupManager? _groupManager;
        private MessageManager? _messageManager;
        private MessagingTransportService? _transport;
        private Func<IEnumerable<PeerInfo>>? _getOnlinePeers;

        private readonly ObservableCollection<GroupListItem> _groups = new();
        private readonly ObservableCollection<GroupMessageViewModel> _messages = new();
        private readonly ObservableCollection<SelectableDevice> _newGroupMembers = new();
        private readonly ObservableCollection<SelectableDevice> _addMemberCandidates = new();

        private string? _selectedGroupId;

        public GroupsPanel()
        {
            InitializeComponent();
            GroupList.ItemsSource = _groups;
            MessagesList.ItemsSource = _messages;
            NewGroupMembersList.ItemsSource = _newGroupMembers;
            AddMemberList.ItemsSource = _addMemberCandidates;
        }

        public void Initialize(
            GroupManager groupManager,
            MessageManager messageManager,
            MessagingTransportService transport,
            Func<IEnumerable<PeerInfo>> getOnlinePeers)
        {
            _groupManager = groupManager;
            _messageManager = messageManager;
            _transport = transport;
            _getOnlinePeers = getOnlinePeers;

            _groupManager.GroupCreated += _ => Dispatcher.Invoke(RefreshGroupList);
            _groupManager.GroupUpdated += _ => Dispatcher.Invoke(RefreshGroupList);
            _groupManager.GroupDeleted += _ => Dispatcher.Invoke(RefreshGroupList);
            _messageManager.MessageReceived += OnMessageReceived;

            RefreshGroupList();
        }

        // ──────────────────────────────────────────────────
        // GROUP LIST
        // ──────────────────────────────────────────────────

        private void RefreshGroupList()
        {
            if (_groupManager == null) return;

            string? selfDeviceId = SessionManager.CurrentSession?.DeviceId;
            List<GroupRecord> groups = selfDeviceId == null
                ? new List<GroupRecord>()
                : _groupManager.GetGroupsForDevice(selfDeviceId).OrderBy(g => g.Name, StringComparer.OrdinalIgnoreCase).ToList();

            string? previouslySelected = _selectedGroupId;

            _groups.Clear();
            foreach (GroupRecord g in groups)
            {
                _groups.Add(new GroupListItem
                {
                    GroupId = g.GroupId,
                    Name = g.Name,
                    MemberCount = g.MemberDeviceIds.Count
                });
            }

            EmptyStateText.Visibility = _groups.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

            if (previouslySelected != null)
            {
                GroupListItem? match = _groups.FirstOrDefault(x =>
                    string.Equals(x.GroupId, previouslySelected, StringComparison.OrdinalIgnoreCase));
                if (match != null)
                {
                    GroupList.SelectedItem = match;
                    return;
                }
            }

            // The previously-selected group is gone (deleted or we were removed).
            _selectedGroupId = null;
            ConversationHeader.Text = "Select a group to start chatting";
            _messages.Clear();
            InputArea.IsEnabled = false;
            ManageMembersBtn.IsEnabled = false;
        }

        private void GroupList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AddMemberPopup.Visibility = Visibility.Collapsed;

            if (GroupList.SelectedItem is not GroupListItem item)
            {
                _selectedGroupId = null;
                ConversationHeader.Text = "Select a group to start chatting";
                _messages.Clear();
                InputArea.IsEnabled = false;
                ManageMembersBtn.IsEnabled = false;
                return;
            }

            _selectedGroupId = item.GroupId;
            ConversationHeader.Text = item.Name;
            InputArea.IsEnabled = true;
            ManageMembersBtn.IsEnabled = true;

            LoadConversation(item.GroupId);
        }

        private void LoadConversation(string groupId)
        {
            _messages.Clear();
            if (_messageManager == null) return;

            foreach (AdvancedChatMessage msg in _messageManager.GetGroupConversation(groupId))
                _messages.Add(ToViewModel(msg));

            MessagesScroll.ScrollToEnd();
        }

        private void OnMessageReceived(AdvancedChatMessage msg)
        {
            if (!msg.IsGroupMessage) return;

            Dispatcher.Invoke(() =>
            {
                if (_selectedGroupId != null &&
                    string.Equals(msg.GroupId, _selectedGroupId, StringComparison.OrdinalIgnoreCase))
                {
                    _messages.Add(ToViewModel(msg));
                    MessagesScroll.ScrollToEnd();
                }
            });
        }

        private GroupMessageViewModel ToViewModel(AdvancedChatMessage msg)
        {
            string? selfDeviceId = SessionManager.CurrentSession?.DeviceId;
            return new GroupMessageViewModel
            {
                SenderUsername = msg.SenderUsername,
                Text = msg.Text,
                TimeDisplay = msg.Timestamp.ToLocalTime().ToString("HH:mm"),
                IsSelf = string.Equals(msg.SenderDeviceId, selfDeviceId, StringComparison.OrdinalIgnoreCase)
            };
        }

        // ──────────────────────────────────────────────────
        // SEND
        // ──────────────────────────────────────────────────

        private async void SendBtn_Click(object sender, RoutedEventArgs e) => await SendMessageAsync();

        private async void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
            {
                e.Handled = true;
                await SendMessageAsync();
            }
        }

        private async System.Threading.Tasks.Task SendMessageAsync()
        {
            string text = InputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(text)) return;
            if (_transport == null || _selectedGroupId == null || _getOnlinePeers == null) return;

            InputBox.Clear();
            SendBtn.IsEnabled = false;

            try
            {
                IEnumerable<PeerInfo> peers = _getOnlinePeers();
                AdvancedChatMessage sent = await _transport.SendGroupMessageAsync(_selectedGroupId, text, peers);
                _messages.Add(ToViewModel(sent));
                MessagesScroll.ScrollToEnd();
            }
            catch { /* Delivery failures are silent; the message stays in local history */ }
            finally
            {
                SendBtn.IsEnabled = true;
                InputBox.Focus();
            }
        }

        // ──────────────────────────────────────────────────
        // NEW GROUP
        // ──────────────────────────────────────────────────

        private void NewGroupBtn_Click(object sender, RoutedEventArgs e)
        {
            AddMemberPopup.Visibility = Visibility.Collapsed;

            NewGroupNameBox.Clear();
            NewGroupDescBox.Clear();
            _newGroupMembers.Clear();

            string? selfDeviceId = SessionManager.CurrentSession?.DeviceId;
            foreach (DeviceRecord d in GetAuthorizedDevices(selfDeviceId))
            {
                _newGroupMembers.Add(new SelectableDevice
                {
                    DeviceId = d.DeviceId,
                    DisplayName = string.IsNullOrWhiteSpace(d.DisplayName) ? d.DeviceId : d.DisplayName
                });
            }

            NewGroupPopup.Visibility = Visibility.Visible;
        }

        private void CancelNewGroupBtn_Click(object sender, RoutedEventArgs e)
        {
            NewGroupPopup.Visibility = Visibility.Collapsed;
        }

        private void CreateGroupBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_groupManager == null) return;

            string name = NewGroupNameBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Enter a group name.", "New Group", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            AppSession? session = SessionManager.CurrentSession;
            if (session == null) return;

            string description = NewGroupDescBox.Text.Trim();

            if (!_groupManager.CreateGroup(name, description, session.Username, out string groupId))
            {
                MessageBox.Show("Could not create the group.", "New Group", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Creator is always a member.
            _groupManager.AddMember(groupId, session.DeviceId, "Owner");

            foreach (SelectableDevice d in _newGroupMembers.Where(x => x.IsChecked))
                _groupManager.AddMember(groupId, d.DeviceId, "Member");

            NewGroupPopup.Visibility = Visibility.Collapsed;
            RefreshGroupList();

            GroupListItem? created = _groups.FirstOrDefault(g =>
                string.Equals(g.GroupId, groupId, StringComparison.OrdinalIgnoreCase));
            if (created != null) GroupList.SelectedItem = created;
        }

        // ──────────────────────────────────────────────────
        // MANAGE MEMBERS
        // ──────────────────────────────────────────────────

        private void ManageMembersBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_groupManager == null || _selectedGroupId == null) return;

            GroupRecord? group = _groupManager.GetGroup(_selectedGroupId);
            if (group == null) return;

            var currentMembers = new HashSet<string>(group.MemberDeviceIds, StringComparer.OrdinalIgnoreCase);

            _addMemberCandidates.Clear();
            foreach (DeviceRecord d in GetAuthorizedDevices(null).Where(d => !currentMembers.Contains(d.DeviceId)))
            {
                _addMemberCandidates.Add(new SelectableDevice
                {
                    DeviceId = d.DeviceId,
                    DisplayName = string.IsNullOrWhiteSpace(d.DisplayName) ? d.DeviceId : d.DisplayName
                });
            }

            CurrentMembersText.Text = "Current members: " +
                (group.MemberDeviceIds.Count == 0 ? "(none)" : string.Join(", ", group.MemberDeviceIds));

            AddMemberPopup.Visibility = Visibility.Visible;
        }

        private void CloseAddMemberBtn_Click(object sender, RoutedEventArgs e)
        {
            AddMemberPopup.Visibility = Visibility.Collapsed;
        }

        private void AddSelectedMembersBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_groupManager == null || _selectedGroupId == null) return;

            foreach (SelectableDevice d in _addMemberCandidates.Where(x => x.IsChecked))
                _groupManager.AddMember(_selectedGroupId, d.DeviceId, "Member");

            AddMemberPopup.Visibility = Visibility.Collapsed;
            RefreshGroupList();
        }

        private static IEnumerable<DeviceRecord> GetAuthorizedDevices(string? excludeDeviceId)
        {
            try
            {
                return UserRepository.GetAllDevices()
                    .Where(d => d.IsAuthorized &&
                                !string.IsNullOrWhiteSpace(d.DeviceId) &&
                                (excludeDeviceId == null ||
                                 !string.Equals(d.DeviceId, excludeDeviceId, StringComparison.OrdinalIgnoreCase)))
                    .OrderBy(d => d.DisplayName, StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
            catch { return Enumerable.Empty<DeviceRecord>(); }
        }
    }
}
