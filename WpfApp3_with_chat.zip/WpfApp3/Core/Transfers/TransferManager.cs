using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using WpfApp3.Database;

namespace WpfApp3.Core.Transfers
{
    public class TransferManager
    {
        private readonly ConcurrentDictionary<string, TransferSession> _activeSessions = new();
        private readonly ConcurrentDictionary<string, CancellationTokenSource> _cancellationSources = new();

        public event Action<TransferSession>? TransferQueued;
        public event Action<TransferProgressReport>? TransferProgressChanged;
        public event Action<TransferSession>? TransferCompleted;
        public event Action<TransferSession>? TransferFailed;

        public static string ResolveCollision(string targetDirectory, string fileName)
        {
            string fullPath = Path.Combine(targetDirectory, fileName);
            if (!File.Exists(fullPath)) return fullPath;

            string nameWithoutExt = Path.GetFileNameWithoutExtension(fileName);
            string ext = Path.GetExtension(fileName);

            int counter = 1;
            while (true)
            {
                string candidate = $"{nameWithoutExt} ({counter}){ext}";
                string candidatePath = Path.Combine(targetDirectory, candidate);
                if (!File.Exists(candidatePath))
                {
                    return candidatePath;
                }
                counter++;
            }
        }

        public static List<TransferItem> ScanItems(IEnumerable<string> paths)
        {
            var items = new List<TransferItem>();
            foreach (var path in paths)
            {
                if (File.Exists(path))
                {
                    var fi = new FileInfo(path);
                    items.Add(new TransferItem
                    {
                        RelativePath = fi.Name,
                        LocalFullPath = fi.FullName,
                        FileSize = fi.Length,
                        Status = TransferStatus.QUEUED
                    });
                }
                else if (Directory.Exists(path))
                {
                    var dir = new DirectoryInfo(path);
                    int prefixLen = dir.Parent != null ? dir.Parent.FullName.Length + 1 : dir.FullName.Length;
                    foreach (var file in dir.EnumerateFiles("*", SearchOption.AllDirectories))
                    {
                        string rel = file.FullName[prefixLen..];
                        items.Add(new TransferItem
                        {
                            RelativePath = rel,
                            LocalFullPath = file.FullName,
                            FileSize = file.Length,
                            Status = TransferStatus.QUEUED
                        });
                    }
                }
            }
            return items;
        }

        public TransferSession CreateOutgoingSession(string remoteDeviceId, string remoteEndpoint, List<TransferItem> items)
        {
            long totalBytes = 0;
            foreach (var it in items) totalBytes += it.FileSize;

            var session = new TransferSession
            {
                TransferId = Guid.NewGuid().ToString(),
                Direction = TransferDirection.OUTGOING,
                RemoteDeviceId = remoteDeviceId,
                RemoteEndpoint = remoteEndpoint,
                TotalFiles = items.Count,
                TotalBytes = totalBytes,
                TransferredBytes = 0,
                Status = TransferStatus.QUEUED,
                Items = items
            };

            foreach (var it in session.Items) it.TransferId = session.TransferId;

            _activeSessions[session.TransferId] = session;
            _cancellationSources[session.TransferId] = new CancellationTokenSource();

            TransferRepository.SaveSession(session);
            TransferQueued?.Invoke(session);

            return session;
        }

        public void ReportProgress(string transferId, long transferredBytes, string currentFile, double bytesPerSec = 0)
        {
            if (_activeSessions.TryGetValue(transferId, out var session))
            {
                session.TransferredBytes = transferredBytes;
                session.Status = TransferStatus.TRANSFERRING;

                TimeSpan? eta = null;
                if (bytesPerSec > 0 && session.TotalBytes > transferredBytes)
                {
                    double remainingSec = (session.TotalBytes - transferredBytes) / bytesPerSec;
                    eta = TimeSpan.FromSeconds(remainingSec);
                }

                var report = new TransferProgressReport
                {
                    TransferId = transferId,
                    TransferredBytes = transferredBytes,
                    TotalBytes = session.TotalBytes,
                    Percentage = session.Percentage,
                    BytesPerSecond = bytesPerSec,
                    Eta = eta,
                    CurrentFileName = currentFile
                };

                TransferProgressChanged?.Invoke(report);
            }
        }

        public void CompleteTransfer(string transferId, string? sha256 = null)
        {
            if (_activeSessions.TryGetValue(transferId, out var session))
            {
                session.Status = TransferStatus.COMPLETED;
                session.CompletedAt = DateTime.UtcNow;
                session.Sha256 = sha256;
                session.TransferredBytes = session.TotalBytes;

                TransferRepository.MarkCompleted(transferId, TransferStatus.COMPLETED, sha256);
                TransferCompleted?.Invoke(session);

                _activeSessions.TryRemove(transferId, out _);
                _cancellationSources.TryRemove(transferId, out _);
            }
        }

        public void FailTransfer(string transferId, string error)
        {
            if (_activeSessions.TryGetValue(transferId, out var session))
            {
                session.Status = TransferStatus.FAILED;
                session.CompletedAt = DateTime.UtcNow;
                session.ErrorMessage = error;

                TransferRepository.SaveSession(session);
                TransferFailed?.Invoke(session);

                _activeSessions.TryRemove(transferId, out _);
                _cancellationSources.TryRemove(transferId, out _);
            }
        }

        public bool CancelTransfer(string transferId)
        {
            if (_cancellationSources.TryGetValue(transferId, out var cts))
            {
                cts.Cancel();
                if (_activeSessions.TryGetValue(transferId, out var session))
                {
                    session.Status = TransferStatus.CANCELLED;
                    session.CompletedAt = DateTime.UtcNow;
                    TransferRepository.MarkCompleted(transferId, TransferStatus.CANCELLED);
                }
                return true;
            }
            return false;
        }

        public CancellationToken GetCancellationToken(string transferId)
        {
            if (_cancellationSources.TryGetValue(transferId, out var cts))
            {
                return cts.Token;
            }
            return CancellationToken.None;
        }

        public List<TransferSession> GetHistory(int limit = 100) => TransferRepository.GetHistory(limit);
    }
}
