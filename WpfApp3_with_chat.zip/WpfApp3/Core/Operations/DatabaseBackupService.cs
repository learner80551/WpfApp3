using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using WpfApp3.Database;

namespace WpfApp3.Core.Operations
{
    public static class DatabaseBackupService
    {
        public static bool BackupTo(string destinationFilePath)
        {
            try
            {
                string? dir = Path.GetDirectoryName(destinationFilePath);
                if (!string.IsNullOrWhiteSpace(dir))
                {
                    Directory.CreateDirectory(dir);
                }

                using var sourceConn = AppDatabase.OpenConnection();
                using var destConn = new SqliteConnection($"Data Source={destinationFilePath};");
                destConn.Open();

                sourceConn.BackupDatabase(destConn);
                return true;
            }
            catch { return false; }
        }

        public static int PurgeExpiredLogs(int retentionDays)
        {
            if (retentionDays <= 0) return 0;
            int totalPurged = 0;

            try
            {
                string cutoff = DateTime.UtcNow.AddDays(-retentionDays).ToString("O");
                using var conn = AppDatabase.OpenConnection();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM AuditLogs WHERE Timestamp < @co;";
                    cmd.Parameters.AddWithValue("@co", cutoff);
                    totalPurged += cmd.ExecuteNonQuery();
                }

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM ChatMessages WHERE Timestamp < @co;";
                    cmd.Parameters.AddWithValue("@co", cutoff);
                    totalPurged += cmd.ExecuteNonQuery();
                }
            }
            catch { }

            return totalPurged;
        }

        public static string ExportAuditLogsToCsv()
        {
            var sb = new StringBuilder();
            sb.AppendLine("Timestamp,ActorUsername,ActorDeviceId,Action,Target,Result");

            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Timestamp, ActorUsername, ActorDeviceId, Action, Target, Result FROM AuditLogs ORDER BY Timestamp DESC;";
                using var r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string ts = r.GetString(0);
                    string user = r.IsDBNull(1) ? "" : r.GetString(1).Replace("\"", "\"\"");
                    string dev = r.IsDBNull(2) ? "" : r.GetString(2).Replace("\"", "\"\"");
                    string act = r.GetString(3).Replace("\"", "\"\"");
                    string target = r.IsDBNull(4) ? "" : r.GetString(4).Replace("\"", "\"\"");
                    string res = r.IsDBNull(5) ? "" : r.GetString(5).Replace("\"", "\"\"");

                    sb.AppendLine($"\"{ts}\",\"{user}\",\"{dev}\",\"{act}\",\"{target}\",\"{res}\"");
                }
            }
            catch { }

            return sb.ToString();
        }

        public static string ExportAuditLogsToJson()
        {
            var list = Auditing.AuditSyncService.GetRecentAuditEvents(5000);
            return JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true });
        }
    }
}
