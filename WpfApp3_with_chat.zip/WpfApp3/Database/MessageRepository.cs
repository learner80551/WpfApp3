using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using WpfApp3.Core.Messaging;

namespace WpfApp3.Database
{
    public static class MessageRepository
    {
        public static bool Save(AdvancedChatMessage msg)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
INSERT OR IGNORE INTO ChatMessages (
    MessageId, SenderDeviceId, SenderUsername, Message, Timestamp,
    ReceiverDeviceId, GroupId, Status, Type, ReplyToMessageId,
    AttachmentFileName, AttachmentFileSize, AttachmentSha256
) VALUES (
    @mid, @sd, @su, @text, @ts,
    @rd, @gid, @st, @tp, @rep,
    @afn, @afs, @asha
);";
                cmd.Parameters.AddWithValue("@mid", msg.MessageId);
                cmd.Parameters.AddWithValue("@sd", msg.SenderDeviceId);
                cmd.Parameters.AddWithValue("@su", msg.SenderUsername);
                cmd.Parameters.AddWithValue("@text", msg.Text);
                cmd.Parameters.AddWithValue("@ts", msg.Timestamp.ToString("O"));
                cmd.Parameters.AddWithValue("@rd", (object?)msg.ReceiverDeviceId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@gid", (object?)msg.GroupId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@st", msg.Status.ToString());
                cmd.Parameters.AddWithValue("@tp", msg.Type.ToString());
                cmd.Parameters.AddWithValue("@rep", (object?)msg.ReplyToMessageId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@afn", (object?)msg.AttachmentFileName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@afs", (object?)msg.AttachmentFileSize ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@asha", (object?)msg.AttachmentSha256 ?? DBNull.Value);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool UpdateStatus(string messageId, MessageDeliveryStatus status)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE ChatMessages SET Status=@st WHERE MessageId=@mid;";
                cmd.Parameters.AddWithValue("@st", status.ToString());
                cmd.Parameters.AddWithValue("@mid", messageId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static List<AdvancedChatMessage> LoadDirectConversation(string localDeviceId, string remoteDeviceId, int limit = 100)
        {
            var list = new List<AdvancedChatMessage>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT MessageId, SenderDeviceId, SenderUsername, Message, Timestamp,
       ReceiverDeviceId, GroupId, Status, Type, ReplyToMessageId,
       AttachmentFileName, AttachmentFileSize, AttachmentSha256
FROM ChatMessages
WHERE (SenderDeviceId = @local AND ReceiverDeviceId = @remote)
   OR (SenderDeviceId = @remote AND ReceiverDeviceId = @local)
ORDER BY Timestamp DESC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@local", localDeviceId);
                cmd.Parameters.AddWithValue("@remote", remoteDeviceId);
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read()) list.Add(ReadMessage(r));
                list.Reverse();
            }
            catch { }
            return list;
        }

        public static List<AdvancedChatMessage> LoadGroupMessages(string groupId, int limit = 100)
        {
            var list = new List<AdvancedChatMessage>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT MessageId, SenderDeviceId, SenderUsername, Message, Timestamp,
       ReceiverDeviceId, GroupId, Status, Type, ReplyToMessageId,
       AttachmentFileName, AttachmentFileSize, AttachmentSha256
FROM ChatMessages
WHERE GroupId = @gid
ORDER BY Timestamp DESC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@gid", groupId);
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read()) list.Add(ReadMessage(r));
                list.Reverse();
            }
            catch { }
            return list;
        }

        public static List<AdvancedChatMessage> LoadBroadcastMessages(int limit = 100)
        {
            var list = new List<AdvancedChatMessage>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT MessageId, SenderDeviceId, SenderUsername, Message, Timestamp,
       ReceiverDeviceId, GroupId, Status, Type, ReplyToMessageId,
       AttachmentFileName, AttachmentFileSize, AttachmentSha256
FROM ChatMessages
WHERE ReceiverDeviceId IS NULL AND GroupId IS NULL
ORDER BY Timestamp DESC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read()) list.Add(ReadMessage(r));
                list.Reverse();
            }
            catch { }
            return list;
        }

        public static List<AdvancedChatMessage> Search(string query, int limit = 50)
        {
            var list = new List<AdvancedChatMessage>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT MessageId, SenderDeviceId, SenderUsername, Message, Timestamp,
       ReceiverDeviceId, GroupId, Status, Type, ReplyToMessageId,
       AttachmentFileName, AttachmentFileSize, AttachmentSha256
FROM ChatMessages
WHERE Message LIKE @q OR SenderUsername LIKE @q OR AttachmentFileName LIKE @q
ORDER BY Timestamp DESC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@q", $"%{query}%");
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read()) list.Add(ReadMessage(r));
            }
            catch { }
            return list;
        }

        public static bool DeleteMessage(string messageId)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "DELETE FROM ChatMessages WHERE MessageId=@mid;";
                cmd.Parameters.AddWithValue("@mid", messageId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        private static AdvancedChatMessage ReadMessage(SqliteDataReader r)
        {
            _ = Enum.TryParse<MessageDeliveryStatus>(r.IsDBNull(7) ? "SENT" : r.GetString(7), true, out var st);
            _ = Enum.TryParse<MessageType>(r.IsDBNull(8) ? "TEXT" : r.GetString(8), true, out var tp);

            return new AdvancedChatMessage
            {
                MessageId = r.GetString(0),
                SenderDeviceId = r.GetString(1),
                SenderUsername = r.GetString(2),
                Text = r.GetString(3),
                Timestamp = DateTime.Parse(r.GetString(4)),
                ReceiverDeviceId = r.IsDBNull(5) ? null : r.GetString(5),
                GroupId = r.IsDBNull(6) ? null : r.GetString(6),
                Status = st,
                Type = tp,
                ReplyToMessageId = r.IsDBNull(9) ? null : r.GetString(9),
                AttachmentFileName = r.IsDBNull(10) ? null : r.GetString(10),
                AttachmentFileSize = r.IsDBNull(11) ? null : r.GetInt64(11),
                AttachmentSha256 = r.IsDBNull(12) ? null : r.GetString(12)
            };
        }
    }
}
