using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace WpfApp3.Database
{
    /// <summary>
    /// Transactional, non-destructive database migration manager.
    /// Tracks schema version and ensures backward-compatible upgrades.
    /// </summary>
    public static class DatabaseMigrator
    {
        public const int CurrentVersion = 4;

        public static void Migrate(SqliteConnection connection)
        {
            EnsureVersionTable(connection);
            int currentVersion = GetCurrentVersion(connection);

            if (currentVersion < 1)
            {
                ApplyMigration1(connection);
                SetVersion(connection, 1);
            }

            if (currentVersion < 2)
            {
                ApplyMigration2(connection);
                SetVersion(connection, 2);
            }

            if (currentVersion < 3)
            {
                ApplyMigration3(connection);
                SetVersion(connection, 3);
            }

            if (currentVersion < 4)
            {
                ApplyMigration4(connection);
                SetVersion(connection, 4);
            }
        }

        private static void EnsureVersionTable(SqliteConnection connection)
        {
            using SqliteCommand cmd = connection.CreateCommand();
            cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS SchemaVersion (
    Version INTEGER PRIMARY KEY,
    AppliedAt TEXT NOT NULL
);";
            cmd.ExecuteNonQuery();
        }

        private static int GetCurrentVersion(SqliteConnection connection)
        {
            using SqliteCommand cmd = connection.CreateCommand();
            cmd.CommandText = "SELECT COALESCE(MAX(Version), 0) FROM SchemaVersion;";
            object? result = cmd.ExecuteScalar();
            return result != null && result != DBNull.Value ? Convert.ToInt32(result) : 0;
        }

        private static void SetVersion(SqliteConnection connection, int version)
        {
            using SqliteCommand cmd = connection.CreateCommand();
            cmd.CommandText = "INSERT INTO SchemaVersion (Version, AppliedAt) VALUES (@v, @ts);";
            cmd.Parameters.AddWithValue("@v", version);
            cmd.Parameters.AddWithValue("@ts", DateTime.UtcNow.ToString("O"));
            cmd.ExecuteNonQuery();
        }

        private static void ApplyMigration1(SqliteConnection connection)
        {
            using var transaction = connection.BeginTransaction();

            // 1. Check and add extended columns to Devices table if missing
            HashSet<string> existingCols = GetColumnNames(connection, "Devices", transaction);

            AddColumnIfMissing(connection, transaction, "Devices", existingCols, "Hostname", "TEXT");
            AddColumnIfMissing(connection, transaction, "Devices", existingCols, "IpAddress", "TEXT");
            AddColumnIfMissing(connection, transaction, "Devices", existingCols, "OperatingSystem", "TEXT");
            AddColumnIfMissing(connection, transaction, "Devices", existingCols, "ClientVersion", "TEXT");
            AddColumnIfMissing(connection, transaction, "Devices", existingCols, "Status", "TEXT NOT NULL DEFAULT 'UNKNOWN'");
            AddColumnIfMissing(connection, transaction, "Devices", existingCols, "TrustStatus", "TEXT NOT NULL DEFAULT 'UNKNOWN'");

            // 2. Groups & Group Members
            using (var cmd = connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Groups (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    GroupId TEXT NOT NULL UNIQUE,
    Name TEXT NOT NULL,
    Description TEXT,
    CreatedBy TEXT,
    CreatedAt TEXT NOT NULL,
    IsActive INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS GroupMembers (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    GroupId TEXT NOT NULL,
    DeviceId TEXT NOT NULL,
    Role TEXT NOT NULL DEFAULT 'Member',
    JoinedAt TEXT NOT NULL,
    UNIQUE(GroupId, DeviceId)
);

CREATE TABLE IF NOT EXISTS SecurityAlerts (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    AlertId TEXT NOT NULL UNIQUE,
    Severity TEXT NOT NULL,
    Type TEXT NOT NULL,
    SourceDeviceId TEXT,
    Message TEXT NOT NULL,
    Timestamp TEXT NOT NULL,
    Acknowledged INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS AuditSyncQueue (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EventId TEXT NOT NULL UNIQUE,
    PayloadJson TEXT NOT NULL,
    TargetAdminDeviceId TEXT,
    Status TEXT NOT NULL DEFAULT 'Pending',
    Attempts INTEGER NOT NULL DEFAULT 0,
    LastAttemptAt TEXT,
    CreatedAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS SystemPolicies (
    Key TEXT PRIMARY KEY,
    Value TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_groupmembers_group ON GroupMembers(GroupId);
CREATE INDEX IF NOT EXISTS idx_groupmembers_device ON GroupMembers(DeviceId);
CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON SecurityAlerts(Timestamp);
CREATE INDEX IF NOT EXISTS idx_auditsync_status ON AuditSyncQueue(Status);
";
                cmd.ExecuteNonQuery();
            }

            transaction.Commit();
        }

        private static void ApplyMigration2(SqliteConnection connection)
        {
            using var transaction = connection.BeginTransaction();

            // 1. Extend ChatMessages table (ensure base table exists first)
            using (var baseCmd = connection.CreateCommand())
            {
                baseCmd.Transaction = transaction;
                baseCmd.CommandText = @"
CREATE TABLE IF NOT EXISTS ChatMessages (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    MessageId TEXT NOT NULL UNIQUE,
    SenderDeviceId TEXT NOT NULL,
    SenderUsername TEXT NOT NULL,
    Message TEXT NOT NULL,
    Timestamp TEXT NOT NULL
);";
                baseCmd.ExecuteNonQuery();
            }

            HashSet<string> chatCols = GetColumnNames(connection, "ChatMessages", transaction);
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "ReceiverDeviceId", "TEXT");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "GroupId", "TEXT");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "Status", "TEXT NOT NULL DEFAULT 'SENT'");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "Type", "TEXT NOT NULL DEFAULT 'TEXT'");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "ReplyToMessageId", "TEXT");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "AttachmentFileName", "TEXT");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "AttachmentFileSize", "INTEGER");
            AddColumnIfMissing(connection, transaction, "ChatMessages", chatCols, "AttachmentSha256", "TEXT");

            // 2. Transfers and TransferItems tables
            using (var cmd = connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Transfers (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    TransferId TEXT NOT NULL UNIQUE,
    Direction TEXT NOT NULL,
    RemoteDeviceId TEXT NOT NULL,
    RemoteEndpoint TEXT,
    TotalFiles INTEGER NOT NULL DEFAULT 1,
    TotalBytes INTEGER NOT NULL,
    TransferredBytes INTEGER NOT NULL DEFAULT 0,
    Status TEXT NOT NULL DEFAULT 'QUEUED',
    Sha256 TEXT,
    TargetDirectory TEXT,
    CreatedAt TEXT NOT NULL,
    CompletedAt TEXT,
    ErrorMessage TEXT
);

CREATE TABLE IF NOT EXISTS TransferItems (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    TransferId TEXT NOT NULL,
    RelativePath TEXT NOT NULL,
    FileSize INTEGER NOT NULL,
    TransferredBytes INTEGER NOT NULL DEFAULT 0,
    Sha256 TEXT,
    Status TEXT NOT NULL DEFAULT 'QUEUED'
);

CREATE INDEX IF NOT EXISTS idx_chat_receiver ON ChatMessages(ReceiverDeviceId);
CREATE INDEX IF NOT EXISTS idx_chat_group ON ChatMessages(GroupId);
CREATE INDEX IF NOT EXISTS idx_transfers_status ON Transfers(Status);
CREATE INDEX IF NOT EXISTS idx_transferitems_tid ON TransferItems(TransferId);
";
                cmd.ExecuteNonQuery();
            }

            transaction.Commit();
        }

        private static void ApplyMigration3(SqliteConnection connection)
        {
            using var transaction = connection.BeginTransaction();

            // 1. Extend Users table
            HashSet<string> userCols = GetColumnNames(connection, "Users", transaction);
            AddColumnIfMissing(connection, transaction, "Users", userCols, "Role", "TEXT NOT NULL DEFAULT 'User'");
            AddColumnIfMissing(connection, transaction, "Users", userCols, "AccountState", "TEXT NOT NULL DEFAULT 'ACTIVE'");
            AddColumnIfMissing(connection, transaction, "Users", userCols, "DisplayName", "TEXT");
            AddColumnIfMissing(connection, transaction, "Users", userCols, "Email", "TEXT");

            // 2. Strict One Permanent Admin index
            using (var cmd = connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandText = @"
CREATE UNIQUE INDEX IF NOT EXISTS idx_single_admin ON Users(Role) WHERE Role = 'Admin';

CREATE TABLE IF NOT EXISTS SupervisorPermissions (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId INTEGER NOT NULL,
    Permission TEXT NOT NULL,
    GrantedBy INTEGER,
    GrantedAt TEXT NOT NULL,
    UNIQUE(UserId, Permission),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS AuthorityState (
    Id INTEGER PRIMARY KEY,
    CurrentEpoch INTEGER NOT NULL DEFAULT 1,
    AdminUserId INTEGER NOT NULL,
    AdminDeviceId TEXT NOT NULL,
    ActingAdminUserId INTEGER,
    ActingAdminLeaseExpiry TEXT,
    EpochStartedAt TEXT NOT NULL,
    EpochSignature TEXT
);

CREATE TABLE IF NOT EXISTS AuthorizationEvents (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EventId TEXT NOT NULL UNIQUE,
    EventType TEXT NOT NULL,
    UserId INTEGER,
    DeviceId TEXT,
    AuthorityUserId INTEGER NOT NULL,
    AuthorityRole TEXT NOT NULL,
    Epoch INTEGER NOT NULL,
    SequenceNumber INTEGER NOT NULL,
    PayloadJson TEXT NOT NULL,
    PayloadHash TEXT NOT NULL,
    Signature TEXT NOT NULL,
    Timestamp TEXT NOT NULL,
    ProcessedAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ProcessedEvents (
    EventId TEXT PRIMARY KEY,
    ProcessedAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS MetadataEvents (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EventId TEXT NOT NULL UNIQUE,
    EventType TEXT NOT NULL,
    SenderUsername TEXT,
    ReceiverUsername TEXT,
    SenderUserId INTEGER,
    ReceiverUserId INTEGER,
    SenderDeviceId TEXT,
    ReceiverDeviceId TEXT,
    Subject TEXT,
    MessageType TEXT,
    FileName TEXT,
    FileExtension TEXT,
    ContentType TEXT,
    FileSize INTEGER,
    TransferId TEXT,
    ConversationId TEXT,
    MessageId TEXT,
    CreatedAt TEXT NOT NULL,
    StartedAt TEXT,
    CompletedAt TEXT,
    DeliveryStatus TEXT,
    ReadStatus TEXT,
    TransferStatus TEXT,
    IntegrityStatus TEXT,
    AttachmentPresent INTEGER NOT NULL DEFAULT 0,
    AttachmentType TEXT,
    ProtocolVersion TEXT,
    OriginEventId TEXT,
    SequenceNumber INTEGER,
    PreviousEventHash TEXT,
    MetadataSignature TEXT
);

CREATE INDEX IF NOT EXISTS idx_meta_sender ON MetadataEvents(SenderUsername);
CREATE INDEX IF NOT EXISTS idx_meta_receiver ON MetadataEvents(ReceiverUsername);
CREATE INDEX IF NOT EXISTS idx_meta_created ON MetadataEvents(CreatedAt);
CREATE INDEX IF NOT EXISTS idx_auth_events_user ON AuthorizationEvents(UserId);
CREATE INDEX IF NOT EXISTS idx_sup_perm_user ON SupervisorPermissions(UserId);
";
                cmd.ExecuteNonQuery();
            }

            transaction.Commit();
        }

        private static void ApplyMigration4(SqliteConnection connection)
        {
            using var transaction = connection.BeginTransaction();

            HashSet<string> deviceCols = GetColumnNames(connection, "Devices", transaction);

            // 1. Check and add PublicKey and DeviceState columns to Devices table if missing
            AddColumnIfMissing(connection, transaction, "Devices", deviceCols, "PublicKey", "TEXT");
            AddColumnIfMissing(connection, transaction, "Devices", deviceCols, "DeviceState", "TEXT NOT NULL DEFAULT 'PENDING_APPROVAL'");

            // 2. Safely migrate existing records
            // - Explicitly authorized devices that are not revoked -> AUTHORIZED
            // - Revoked devices -> REVOKED
            // - All other devices safely default to PENDING_APPROVAL rather than silently granting trust
            using (var cmd = connection.CreateCommand())
            {
                cmd.Transaction = transaction;
                cmd.CommandText = @"
UPDATE Devices
SET DeviceState = 'AUTHORIZED'
WHERE IsAuthorized = 1 AND (IsRevoked = 0 OR IsRevoked IS NULL);

UPDATE Devices
SET DeviceState = 'REVOKED'
WHERE IsRevoked = 1;

UPDATE Devices
SET DeviceState = 'PENDING_APPROVAL'
WHERE DeviceState IS NULL OR DeviceState = '';

CREATE INDEX IF NOT EXISTS idx_devices_devicestate ON Devices(DeviceState);
";
                cmd.ExecuteNonQuery();
            }

            transaction.Commit();
        }

        private static HashSet<string> GetColumnNames(SqliteConnection connection, string table, SqliteTransaction transaction)
        {
            var cols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using var cmd = connection.CreateCommand();
            cmd.Transaction = transaction;
            cmd.CommandText = $"PRAGMA table_info({table});";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                cols.Add(reader.GetString(1));
            }
            return cols;
        }

        private static void AddColumnIfMissing(
            SqliteConnection connection,
            SqliteTransaction transaction,
            string table,
            HashSet<string> existingCols,
            string columnName,
            string columnDef)
        {
            if (!existingCols.Contains(columnName))
            {
                using var cmd = connection.CreateCommand();
                cmd.Transaction = transaction;
                cmd.CommandText = $"ALTER TABLE {table} ADD COLUMN {columnName} {columnDef};";
                cmd.ExecuteNonQuery();
                existingCols.Add(columnName);
            }
        }
    }
}
