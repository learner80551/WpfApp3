using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp3.Authentication;
using WpfApp3.Identity;
using WpfApp3.Theme;

namespace WpfApp3.UI.Login
{
    public partial class LoginWindow : Window
    {
        public bool LoginSucceeded { get; private set; }
        public bool ForcePasswordReset { get; private set; }

        private bool _isUpdatingTheme;
        private bool _signupMode;

        public LoginWindow()
        {
            InitializeComponent();

            // Display device ID
            DeviceIdText.Text = DeviceIdentity.GetOrCreateDeviceId();

            // Sync theme toggle state
            _isUpdatingTheme = true;
            try
            {
                ThemeToggleBtn.IsChecked = ThemeManager.IsDark;
                ThemeToggleBtn.Content = ThemeManager.IsDark ? "☀ Light Mode" : "🌙 Dark Mode";
            }
            finally
            {
                _isUpdatingTheme = false;
            }

            ThemeManager.ThemeChanged += isDark =>
            {
                Dispatcher.Invoke(() =>
                {
                    _isUpdatingTheme = true;
                    try
                    {
                        ThemeToggleBtn.IsChecked = isDark;
                        ThemeToggleBtn.Content = isDark ? "☀ Light Mode" : "🌙 Dark Mode";
                    }
                    finally
                    {
                        _isUpdatingTheme = false;
                    }
                });
            };

            UsernameBox.Focus();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (_signupMode) CreateAccount();
            else DoLogin();
        }

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (_signupMode) CreateAccount();
                else DoLogin();
            }
        }

        private void DoLogin(bool staffOnly = false)
        {
            ErrorText.Visibility = Visibility.Collapsed;
            LoginButton.IsEnabled = false;

            string username = UsernameBox.Text.Trim();
            string password = PasswordBox.Password;
            string deviceId = DeviceIdentity.GetOrCreateDeviceId();

            if (string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password))
            {
                ShowError("Please enter your username and password.");
                LoginButton.IsEnabled = true;
                return;
            }

            LoginResult result = AuthenticationService.Login(username, password, deviceId);

            if (result.IsSuccess)
            {
                if (staffOnly && result.Session != null &&
                    !result.Session.IsAdmin && !result.Session.IsSupervisor)
                {
                    SessionManager.InvalidateSession();
                    ShowError("Staff Login requires an administrator or supervisor account.");
                    LoginButton.IsEnabled = true;
                    return;
                }

                LoginSucceeded = true;
                ForcePasswordReset = result.Code == LoginResultCode.ForcePasswordReset;
                DialogResult = true;
                Close();
            }
            else
            {
                ShowError(result.Message);
                PasswordBox.Clear();
                LoginButton.IsEnabled = true;
            }
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            if (!_signupMode)
            {
                _signupMode = true;
                ConfirmPasswordPanel.Visibility = Visibility.Visible;
                LoginButton.Content = "Create Account";
                SignUpButton.Content = "Back to Login";
                StaffLoginButton.Visibility = Visibility.Collapsed;
                ForgotPasswordButton.Visibility = Visibility.Collapsed;
                ErrorText.Visibility = Visibility.Collapsed;
                return;
            }

            _signupMode = false;
            ConfirmPasswordPanel.Visibility = Visibility.Collapsed;
            LoginButton.Content = "Login";
            SignUpButton.Content = "Sign Up";
            StaffLoginButton.Visibility = Visibility.Visible;
            ForgotPasswordButton.Visibility = Visibility.Visible;
            ConfirmPasswordBox.Clear();
            ErrorText.Visibility = Visibility.Collapsed;
        }

        private void StaffLoginButton_Click(object sender, RoutedEventArgs e) => DoLogin(staffOnly: true);

        private void ForgotPasswordButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult confirm = MessageBox.Show(
                "Navlan stores all accounts locally on this device — there is " +
                "no email or phone recovery, so a forgotten password cannot " +
                "be emailed to you.\n\n" +
                "\"Reset & Start Fresh\" permanently deletes ALL local " +
                "accounts, authorized devices, chat history and paired-device " +
                "trust data on THIS computer, then restarts Navlan so you can " +
                "create a new administrator.\n\n" +
                "Other computers on the network are not affected, but every " +
                "device will need to be re-paired afterwards.\n\n" +
                "Do you want to continue?",
                "Forgot Password?",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning,
                MessageBoxResult.No);

            if (confirm != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                Database.AppDatabase.ResetLocalLoginData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Could not reset the local login data:\n\n" +
                    ex.Message +
                    "\n\nMake sure Navlan is not running in another window, " +
                    "then try again.",
                    "Reset Failed",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }

            MessageBox.Show(
                "Local login data has been erased.\n\n" +
                "Navlan will now restart — create a new administrator " +
                "account in the setup window.",
                "Reset Complete",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            RestartApplication();
        }

        private static void RestartApplication()
        {
            string? exePath = Environment.ProcessPath;

            if (!string.IsNullOrWhiteSpace(exePath))
            {
                Process.Start(new ProcessStartInfo(exePath)
                {
                    UseShellExecute = true
                });
            }

            Application.Current.Shutdown();
        }

        private void CreateAccount()
        {
            ErrorText.Visibility = Visibility.Collapsed;
            string username = UsernameBox.Text.Trim();
            string password = PasswordBox.Password;
            string confirmation = ConfirmPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ShowError("Username and password are required.");
                return;
            }

            if (password.Length < 8)
            {
                ShowError("Password must be at least 8 characters.");
                return;
            }

            if (!string.Equals(password, confirmation, StringComparison.Ordinal))
            {
                ShowError("Passwords do not match.");
                return;
            }

            var result = AuthenticationService.SignUp(username, password);
            if (!result.Success)
            {
                ShowError(result.Error);
                return;
            }

            MessageBox.Show(result.Error, "LANShare", MessageBoxButton.OK, MessageBoxImage.Information);
            SignUpButton_Click(this, new RoutedEventArgs());
            PasswordBox.Clear();
        }

        private void ShowError(string msg)
        {
            ErrorText.Text = msg;
            ErrorText.Visibility = Visibility.Visible;
        }

        private void ThemeToggle_Changed(object sender, RoutedEventArgs e)
        {
            if (_isUpdatingTheme) return;
            bool isDark = ThemeToggleBtn.IsChecked == true;
            ThemeManager.ApplyTheme(isDark);
            ThemeToggleBtn.Content = isDark ? "☀ Light Mode" : "🌙 Dark Mode";
        }
    }
}
