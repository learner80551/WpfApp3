using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using WpfApp3.Database;

namespace WpfApp3.Admin
{
    public static class PolicyManager
    {
        private static readonly ConcurrentDictionary<string, string> _policyCache = new();

        public static void SetPolicy(string key, string value)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
INSERT INTO SystemPolicies (Key, Value, UpdatedAt)
VALUES (@k, @v, @ts)
ON CONFLICT(Key) DO UPDATE SET Value = excluded.Value, UpdatedAt = excluded.UpdatedAt;";
                cmd.Parameters.AddWithValue("@k", key);
                cmd.Parameters.AddWithValue("@v", value);
                cmd.Parameters.AddWithValue("@ts", DateTime.UtcNow.ToString("O"));
                cmd.ExecuteNonQuery();

                _policyCache[key] = value;
            }
            catch { }
        }

        public static string GetPolicy(string key, string defaultValue = "")
        {
            if (_policyCache.TryGetValue(key, out var val)) return val;

            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Value FROM SystemPolicies WHERE Key = @k LIMIT 1;";
                cmd.Parameters.AddWithValue("@k", key);
                object? res = cmd.ExecuteScalar();
                if (res != null && res != DBNull.Value)
                {
                    string s = res.ToString()!;
                    _policyCache[key] = s;
                    return s;
                }
            }
            catch { }

            return defaultValue;
        }

        public static bool IsMessagingEnabled() =>
            bool.TryParse(GetPolicy("MessagingEnabled", "True"), out bool val) && val;

        public static long GetMaxTransferFileSize() =>
            long.TryParse(GetPolicy("MaxFileSize", (100L * 1024L * 1024L * 1024L).ToString()), out long val) ? val : (100L * 1024L * 1024L * 1024L);

        public static int GetLogRetentionDays() =>
            int.TryParse(GetPolicy("LogRetentionDays", "90"), out int val) ? val : 90;
    }
}
