using System;
using System.Collections.Generic;

namespace WpfApp3.Core.Transfers
{
    public enum TransferStatus
    {
        QUEUED,
        CONNECTING,
        TRANSFERRING,
        PAUSED,
        VERIFYING,
        VERIFIED,
        COMPLETED,
        FAILED,
        CANCELLED,
        REJECTED
    }

    public enum TransferDirection
    {
        INCOMING,
        OUTGOING
    }

    public class TransferSession
    {
        public string TransferId { get; set; } = Guid.NewGuid().ToString();
        public TransferDirection Direction { get; set; } = TransferDirection.OUTGOING;
        public string RemoteDeviceId { get; set; } = "";
        public string RemoteEndpoint { get; set; } = "";
        public int TotalFiles { get; set; } = 1;
        public long TotalBytes { get; set; }
        public long TransferredBytes { get; set; }
        public TransferStatus Status { get; set; } = TransferStatus.QUEUED;
        public string? Sha256 { get; set; }
        public string TargetDirectory { get; set; } = "";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? CompletedAt { get; set; }
        public string? ErrorMessage { get; set; }
        public List<TransferItem> Items { get; set; } = new();

        public double Percentage => TotalBytes <= 0 ? 0 : Math.Min(100.0, (double)TransferredBytes / TotalBytes * 100.0);
    }

    public class TransferItem
    {
        public string TransferId { get; set; } = "";
        public string RelativePath { get; set; } = "";
        public string LocalFullPath { get; set; } = "";
        public long FileSize { get; set; }
        public long TransferredBytes { get; set; }
        public string? Sha256 { get; set; }
        public TransferStatus Status { get; set; } = TransferStatus.QUEUED;
    }

    public class TransferProgressReport
    {
        public string TransferId { get; set; } = "";
        public long TransferredBytes { get; set; }
        public long TotalBytes { get; set; }
        public double Percentage { get; set; }
        public double BytesPerSecond { get; set; }
        public TimeSpan? Eta { get; set; }
        public string CurrentFileName { get; set; } = "";
    }
}
