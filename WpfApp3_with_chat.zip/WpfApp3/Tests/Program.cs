using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading.Tasks;
using Xunit;

namespace WpfApp3.Tests
{
    public static class Program
    {
        public static async Task<int> Main(string[] args)
        {
            Console.WriteLine("==================================================================");
            Console.WriteLine("  LANShare / WpfApp3 - Test Runner");
            Console.WriteLine("==================================================================");

            var assembly = typeof(Program).Assembly;
            var types = assembly.GetTypes();

            int total = 0;
            int passed = 0;
            int failed = 0;
            var failures = new List<(string Name, Exception Ex)>();

            var stopwatch = Stopwatch.StartNew();

            foreach (var type in types)
            {
                var methods = type.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static);
                var testMethods = new List<MethodInfo>();

                foreach (var method in methods)
                {
                    if (method.GetCustomAttribute<FactAttribute>() != null ||
                        method.GetCustomAttribute<TheoryAttribute>() != null)
                    {
                        testMethods.Add(method);
                    }
                }

                if (testMethods.Count == 0) continue;

                Console.WriteLine($"\n[Running {type.Name}] ({testMethods.Count} tests)");

                foreach (var method in testMethods)
                {
                    total++;
                    string testName = $"{type.Name}.{method.Name}";
                    object? instance = null;

                    try
                    {
                        if (!method.IsStatic)
                        {
                            instance = Activator.CreateInstance(type);
                        }

                        var result = method.Invoke(instance, null);
                        if (result is Task task)
                        {
                            await task;
                        }

                        passed++;
                        Console.WriteLine($"  [PASS] {method.Name}");
                    }
                    catch (Exception ex)
                    {
                        var actualEx = ex is TargetInvocationException tie ? tie.InnerException ?? ex : ex;
                        failed++;
                        failures.Add((testName, actualEx));
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"  [FAIL] {method.Name}: {actualEx.Message}");
                        Console.ResetColor();
                    }
                    finally
                    {
                        if (instance is IDisposable disposable)
                        {
                            disposable.Dispose();
                        }
                    }
                }
            }

            stopwatch.Stop();

            Console.WriteLine("\n==================================================================");
            Console.WriteLine($"Summary: Total: {total} | Passed: {passed} | Failed: {failed} | Time: {stopwatch.Elapsed.TotalSeconds:F2}s");
            Console.WriteLine("==================================================================");

            if (failures.Count > 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nFAILURES:");
                foreach (var (name, ex) in failures)
                {
                    Console.WriteLine($"--- {name} ---");
                    Console.WriteLine(ex.ToString());
                }
                Console.ResetColor();
                return 1;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nALL TESTS PASSED SUCCESSFULLY.");
            Console.ResetColor();
            return 0;
        }
    }
}
