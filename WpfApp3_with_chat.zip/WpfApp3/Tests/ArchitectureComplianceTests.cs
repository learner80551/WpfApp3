using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using Xunit;
using WpfApp3.Admin;
using WpfApp3.Authentication;
using WpfApp3.Core.Network;
using WpfApp3.Core.Security;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Tests
{
    public class ArchitectureComplianceTests
    {
        [Fact]
        public void Argon2id_HashAndVerify_ProducesValidResult()
        {
            string password = "SecureP2PPassword!123";
            var (hash, salt) = PasswordHasher.HashPassword(password);

            Assert.StartsWith("ARGON2ID:", hash);
            Assert.False(string.IsNullOrWhiteSpace(salt));

            bool valid = PasswordHasher.VerifyPassword(password, hash, salt);
            Assert.True(valid);

            bool invalid = PasswordHasher.VerifyPassword("WrongPassword", hash, salt);
            Assert.False(invalid);
        }

        [Fact]
        public void Argon2id_LegacyPbkdf2Fallback_VerifiesCorrectly()
        {
            // Simulate a legacy PBKDF2 hash (without ARGON2ID: prefix)
            byte[] saltBytes = new byte[32];
            new Random(42).NextBytes(saltBytes);
            string saltBase64 = Convert.ToBase64String(saltBytes);

            byte[] legacyHash = System.Security.Cryptography.Rfc2898DeriveBytes.Pbkdf2(
                System.Text.Encoding.UTF8.GetBytes("LegacyPassword123"),
                saltBytes,
                600_000,
                System.Security.Cryptography.HashAlgorithmName.SHA256,
                32);
            string legacyHashBase64 = Convert.ToBase64String(legacyHash);

            bool verified = PasswordHasher.VerifyPassword("LegacyPassword123", legacyHashBase64, saltBase64);
            Assert.True(verified);

            bool wrong = PasswordHasher.VerifyPassword("IncorrectPassword", legacyHashBase64, saltBase64);
            Assert.False(wrong);
        }

        [Fact]
        public void DeviceCertificate_GeneratesCertAndFingerprint_WithDpapiProtection()
        {
            X509Certificate2 cert = DeviceCertificate.GetOrCreateCertificate();
            Assert.NotNull(cert);
            Assert.True(cert.HasPrivateKey);

            string fingerprint = DeviceCertificate.GetFingerprint(cert);
            Assert.NotNull(fingerprint);
            Assert.Equal(64, fingerprint.Length); // SHA-256 hex string is 64 characters
        }

        [Fact]
        public void PeerDiscovery_UsesMulticast_AndSanitizesDiscoveryPacket()
        {
            Assert.Equal("239.255.42.99", PeerDiscovery.MulticastAddress.ToString());

            var msg = new DiscoveryMessage
            {
                DeviceName = "TestNode",
                IpAddress = "192.168.1.50",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                OperatingSystem = "LANShare Peer",
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            Assert.Contains("\"OperatingSystem\":\"LANShare Peer\"", json);
            Assert.Contains("\"DeviceId\":\"NAV-TEST01\"", json);
            Assert.Contains("\"TransferPort\":42001", json);
        }

        [Fact]
        public void ProtocolMessage_ValidatesEnvelope_AndEnforcesReplayProtection()
        {
            string deviceId = "NAV-TEST01";
            var msg = ProtocolMessage.Create(
                ProtocolMessageTypes.Chat,
                deviceId,
                new { Content = "Hello P2P" });

            Assert.Equal(ProtocolMessageTypes.Chat, msg.MessageType);
            Assert.Equal("1.0", msg.ProtocolVersion);

            // First validation should succeed
            bool validFirst = msg.Validate(out string err1);
            Assert.True(validFirst, err1);

            // Immediate replay of same MessageId must be rejected
            bool validReplay = msg.Validate(out string err2);
            Assert.False(validReplay);
            Assert.Contains("replay", err2, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void ProtocolMessage_RejectsClockSkew()
        {
            var oldMsg = new ProtocolMessage
            {
                MessageType = ProtocolMessageTypes.Heartbeat,
                ProtocolVersion = "1.0",
                MessageId = Guid.NewGuid().ToString(),
                SenderDeviceId = "NAV-OLD01",
                Timestamp = DateTime.UtcNow.AddMinutes(-10).ToString("O"), // 10 minutes old
                PayloadJson = "{}"
            };

            bool valid = oldMsg.Validate(out string err);
            Assert.False(valid);
            Assert.Contains("clock skew", err, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void ProtocolMessage_SignsAndVerifies_WithRsaCertificate()
        {
            X509Certificate2 cert = DeviceCertificate.GetOrCreateCertificate();
            var msg = ProtocolMessage.Create(
                ProtocolMessageTypes.AuthEventSync,
                "NAV-SIGNER",
                new { Event = "TEST_EVENT" },
                cert);

            Assert.False(string.IsNullOrWhiteSpace(msg.Signature));
            Assert.True(msg.VerifySignature(cert));
        }

        [Fact]
        public void SupervisorPermissions_ContainsAllGranularGroups()
        {
            Assert.Contains(Permissions.UserApprove, Permissions.AllSupervisorPermissions);
            Assert.Contains(Permissions.UserSuspend, Permissions.AllSupervisorPermissions);
            Assert.Contains(Permissions.DeviceRevoke, Permissions.AllSupervisorPermissions);
            Assert.Contains(Permissions.AuditView, Permissions.AllSupervisorPermissions);
            Assert.Contains(Permissions.HistoryMetadataView, Permissions.AllSupervisorPermissions);
            Assert.Contains(Permissions.SecurityEventView, Permissions.AllSupervisorPermissions);
        }

        [Fact]
        public void AdminService_BlocksUnauthorizedNonAdmin_FromApprovingUsers()
        {
            var regularUserSession = new AppSession
            {
                UserId = 99,
                Username = "normal_user",
                DeviceId = "NAV-NORM01",
                Role = "User",
                AccountState = AccountStates.Active
            };

            var result = AdminService.ApproveUser(regularUserSession, 100);
            Assert.False(result.IsSuccess);
            Assert.Equal(AdminActionResult.Unauthorized, result.Code);
        }

        [Fact]
        public void AdminService_BlocksNonAdmin_FromGrantingActingAdminLease()
        {
            var supervisorSession = new AppSession
            {
                UserId = 88,
                Username = "supervisor_1",
                DeviceId = "NAV-SUP01",
                Role = "Supervisor",
                AccountState = AccountStates.Active
            };

            var result = AdminService.GrantActingAdminLease(supervisorSession, 88, 4);
            Assert.False(result.IsSuccess);
            Assert.Equal(AdminActionResult.Unauthorized, result.Code);
        }
    }
}
