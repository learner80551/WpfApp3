using System;
using System.IO;

namespace WpfApp3.Core.Security
{
    public static class PathTraversalSanitizer
    {
        public static string SanitizeRelativePath(string rawRelativePath)
        {
            if (string.IsNullOrWhiteSpace(rawRelativePath))
                throw new ArgumentException("Relative path cannot be empty.", nameof(rawRelativePath));

            // Remove null bytes
            string clean = rawRelativePath.Replace("\0", "");

            // Normalize slashes
            clean = clean.Replace('/', Path.DirectorySeparatorChar)
                         .Replace('\\', Path.DirectorySeparatorChar);

            // Strip drive letters or rooted paths (e.g., "C:\", "\")
            if (Path.IsPathRooted(clean))
            {
                clean = clean.TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                int colonIdx = clean.IndexOf(':');
                if (colonIdx >= 0)
                {
                    clean = clean[(colonIdx + 1)..].TrimStart(Path.DirectorySeparatorChar);
                }
            }

            // Split segments and filter out '.' and '..'
            string[] segments = clean.Split(new[] { Path.DirectorySeparatorChar }, StringSplitOptions.RemoveEmptyEntries);
            var safeSegments = new System.Collections.Generic.List<string>();

            foreach (var seg in segments)
            {
                string s = seg.Trim();
                if (s == "." || s == "..")
                    continue;

                // Remove invalid file name chars
                char[] invalidChars = Path.GetInvalidFileNameChars();
                foreach (char c in invalidChars)
                {
                    s = s.Replace(c, '_');
                }

                if (!string.IsNullOrWhiteSpace(s))
                {
                    safeSegments.Add(s);
                }
            }

            if (safeSegments.Count == 0)
            {
                return $"file_{Guid.NewGuid().ToString()[..8]}.dat";
            }

            return Path.Combine(safeSegments.ToArray());
        }

        public static bool IsSafeDestination(string destinationDirectory, string relativePath, out string fullPath)
        {
            string sanitizedRel = SanitizeRelativePath(relativePath);
            string destDirFull = Path.GetFullPath(destinationDirectory);
            fullPath = Path.GetFullPath(Path.Combine(destDirFull, sanitizedRel));

            return fullPath.StartsWith(destDirFull, StringComparison.OrdinalIgnoreCase);
        }
    }
}
