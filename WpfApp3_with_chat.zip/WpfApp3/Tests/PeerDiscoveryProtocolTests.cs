using System.Text.Json;
using Xunit;
using WpfApp3;

namespace WpfApp3.Tests
{
    public class PeerDiscoveryProtocolTests
    {
        [Fact]
        public void DiscoveryMessage_SerializesAndDeserializes_EnrichedFields()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "HQ-PC-01",
                IpAddress = "192.168.1.100",
                CertificateFingerprint = "11223344556677889900AABBCCDDEEFF11223344556677889900AABBCCDDEEFF",
                TransferPort = 42001,
                DeviceId = "NAV-HQ01",
                Hostname = "DESKTOP-HQ01",
                OperatingSystem = "Microsoft Windows 11 Pro",
                ClientVersion = "2.0.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            var deserialized = JsonSerializer.Deserialize<DiscoveryMessage>(json);

            Assert.NotNull(deserialized);
            Assert.Equal("LANSHARE_DISCOVERY", deserialized.Type);
            Assert.Equal("HQ-PC-01", deserialized.DeviceName);
            Assert.Equal("192.168.1.100", deserialized.IpAddress);
            Assert.Equal("NAV-HQ01", deserialized.DeviceId);
            Assert.Equal("DESKTOP-HQ01", deserialized.Hostname);
            Assert.Equal("Microsoft Windows 11 Pro", deserialized.OperatingSystem);
            Assert.Equal("2.0.0", deserialized.ClientVersion);
            Assert.Equal("ONLINE", deserialized.Status);
        }

        [Fact]
        public void PeerInfo_Clone_PreservesAllFields()
        {
            var peer = new PeerInfo
            {
                Name = "Peer-A",
                IpAddress = "10.0.0.5",
                CertificateFingerprint = "ABCDEF",
                DeviceId = "NAV-A",
                Hostname = "HOST-A",
                OperatingSystem = "Windows",
                ClientVersion = "2.0",
                Status = "ONLINE",
                IsOnline = true
            };

            Assert.Equal("NAV-A", peer.DeviceId);
            Assert.Equal("HOST-A", peer.Hostname);
            Assert.Equal("Windows", peer.OperatingSystem);
            Assert.Equal("2.0", peer.ClientVersion);
        }
    }
}
