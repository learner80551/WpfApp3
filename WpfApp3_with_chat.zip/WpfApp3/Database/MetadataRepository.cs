using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Data.Sqlite;
using WpfApp3.Core.Metadata;
using WpfApp3.Core.Security;

namespace WpfApp3.Database
{
    public static class MetadataRepository
    {
        public static void RecordMetadata(MetadataRecord record)
        {
            if (record == null) return;

            try
            {
                if (string.IsNullOrWhiteSpace(record.MetadataSignature))
                {
                    string digest = $"{record.EventId}:{record.SenderUsername}:{record.ReceiverUsername}:{record.Subject}:{record.FileName}:{record.FileSize}:{record.CreatedAt:O}";
                    record.MetadataSignature = CryptographicAuthority.SignData(CryptographicAuthority.ComputeSha256(digest));
                }

                using SqliteConnection conn = AppDatabase.OpenConnection();
                using SqliteCommand cmd = conn.CreateCommand();
                cmd.CommandText = @"
INSERT OR IGNORE INTO MetadataEvents (
    EventId, EventType, SenderUsername, ReceiverUsername, SenderUserId, ReceiverUserId,
    SenderDeviceId, ReceiverDeviceId, Subject, MessageType, FileName, FileExtension,
    ContentType, FileSize, TransferId, ConversationId, MessageId, CreatedAt, StartedAt,
    CompletedAt, DeliveryStatus, ReadStatus, TransferStatus, IntegrityStatus,
    AttachmentPresent, AttachmentType, ProtocolVersion, OriginEventId, SequenceNumber,
    PreviousEventHash, MetadataSignature
) VALUES (
    @eid, @et, @su, @ru, @sui, @rui, @sdi, @rdi, @sub, @mt, @fn, @fe, @ct, @fs,
    @tid, @cid, @mid, @ca, @sa, @comp, @ds, @rs, @ts, @is, @ap, @at, @pv, @oei,
    @seq, @peh, @sig
);";
                cmd.Parameters.AddWithValue("@eid",  record.EventId);
                cmd.Parameters.AddWithValue("@et",   record.EventType);
                cmd.Parameters.AddWithValue("@su",   record.SenderUsername);
                cmd.Parameters.AddWithValue("@ru",   record.ReceiverUsername);
                cmd.Parameters.AddWithValue("@sui",  (object?)record.SenderUserId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@rui",  (object?)record.ReceiverUserId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@sdi",  record.SenderDeviceId);
                cmd.Parameters.AddWithValue("@rdi",  record.ReceiverDeviceId);
                cmd.Parameters.AddWithValue("@sub",  record.Subject ?? "");
                cmd.Parameters.AddWithValue("@mt",   record.MessageType);
                cmd.Parameters.AddWithValue("@fn",   (object?)record.FileName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@fe",   (object?)record.FileExtension ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ct",   (object?)record.ContentType ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@fs",   (object?)record.FileSize ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@tid",  (object?)record.TransferId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@cid",  (object?)record.ConversationId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@mid",  (object?)record.MessageId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ca",   record.CreatedAt.ToString("O"));
                cmd.Parameters.AddWithValue("@sa",   record.StartedAt?.ToString("O") ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@comp", record.CompletedAt?.ToString("O") ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ds",   record.DeliveryStatus ?? "SENT");
                cmd.Parameters.AddWithValue("@rs",   (object?)record.ReadStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ts",   (object?)record.TransferStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@is",   (object?)record.IntegrityStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ap",   record.AttachmentPresent ? 1 : 0);
                cmd.Parameters.AddWithValue("@at",   (object?)record.AttachmentType ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@pv",   record.ProtocolVersion ?? "2.0");
                cmd.Parameters.AddWithValue("@oei",  (object?)record.OriginEventId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@seq",  record.SequenceNumber);
                cmd.Parameters.AddWithValue("@peh",  (object?)record.PreviousEventHash ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@sig",  (object?)record.MetadataSignature ?? DBNull.Value);

                cmd.ExecuteNonQuery();
            }
            catch { }
        }

        public static void RecordChatMessageMetadata(
            string senderUsername, string receiverUsername, string senderDeviceId,
            string receiverDeviceId, string subject, string messageId, bool hasAttachment = false)
        {
            RecordMetadata(new MetadataRecord
            {
                EventType         = "MESSAGE",
                SenderUsername    = senderUsername,
                ReceiverUsername  = receiverUsername,
                SenderDeviceId    = senderDeviceId,
                ReceiverDeviceId  = receiverDeviceId,
                Subject           = string.IsNullOrWhiteSpace(subject) ? "Direct Message" : subject,
                MessageType       = "TEXT",
                MessageId         = messageId,
                DeliveryStatus    = "DELIVERED",
                AttachmentPresent = hasAttachment
            });
        }

        public static void RecordFileTransferMetadata(
            string senderUsername, string receiverUsername, string senderDeviceId,
            string receiverDeviceId, string fileName, long fileSize, string transferId,
            string status = "COMPLETED", string integrityStatus = "VERIFIED")
        {
            string ext = System.IO.Path.GetExtension(fileName).TrimStart('.');
            RecordMetadata(new MetadataRecord
            {
                EventType        = "FILE_TRANSFER",
                SenderUsername   = senderUsername,
                ReceiverUsername = receiverUsername,
                SenderDeviceId   = senderDeviceId,
                ReceiverDeviceId = receiverDeviceId,
                Subject          = $"File: {fileName}",
                MessageType      = "FILE",
                FileName         = fileName,
                FileExtension    = ext,
                FileSize         = fileSize,
                TransferId       = transferId,
                TransferStatus   = status,
                IntegrityStatus  = integrityStatus,
                CompletedAt      = DateTime.UtcNow
            });
        }

        public static List<MetadataRecord> GetMetadataHistory(MetadataFilterCriteria? criteria = null, int limit = 200)
        {
            var list = new List<MetadataRecord>();
            try
            {
                using SqliteConnection conn = AppDatabase.OpenConnection();
                using SqliteCommand cmd = conn.CreateCommand();

                var sb = new StringBuilder("SELECT Id, EventId, EventType, SenderUsername, ReceiverUsername, " +
                    "SenderUserId, ReceiverUserId, SenderDeviceId, ReceiverDeviceId, Subject, MessageType, " +
                    "FileName, FileExtension, ContentType, FileSize, TransferId, ConversationId, MessageId, " +
                    "CreatedAt, StartedAt, CompletedAt, DeliveryStatus, ReadStatus, TransferStatus, IntegrityStatus, " +
                    "AttachmentPresent, AttachmentType, ProtocolVersion, OriginEventId, SequenceNumber, " +
                    "PreviousEventHash, MetadataSignature FROM MetadataEvents WHERE 1=1 ");

                if (criteria != null)
                {
                    if (!string.IsNullOrWhiteSpace(criteria.Sender))
                    {
                        sb.Append("AND SenderUsername LIKE @sender ");
                        cmd.Parameters.AddWithValue("@sender", $"%{criteria.Sender}%");
                    }
                    if (!string.IsNullOrWhiteSpace(criteria.Receiver))
                    {
                        sb.Append("AND ReceiverUsername LIKE @receiver ");
                        cmd.Parameters.AddWithValue("@receiver", $"%{criteria.Receiver}%");
                    }
                    if (!string.IsNullOrWhiteSpace(criteria.MessageType))
                    {
                        sb.Append("AND MessageType = @mt ");
                        cmd.Parameters.AddWithValue("@mt", criteria.MessageType);
                    }
                    if (!string.IsNullOrWhiteSpace(criteria.FileExtension))
                    {
                        sb.Append("AND FileExtension = @fe ");
                        cmd.Parameters.AddWithValue("@fe", criteria.FileExtension.TrimStart('.'));
                    }
                    if (!string.IsNullOrWhiteSpace(criteria.TransferStatus))
                    {
                        sb.Append("AND TransferStatus = @ts ");
                        cmd.Parameters.AddWithValue("@ts", criteria.TransferStatus);
                    }
                    if (!string.IsNullOrWhiteSpace(criteria.IntegrityStatus))
                    {
                        sb.Append("AND IntegrityStatus = @is ");
                        cmd.Parameters.AddWithValue("@is", criteria.IntegrityStatus);
                    }
                    if (!string.IsNullOrWhiteSpace(criteria.SubjectQuery))
                    {
                        sb.Append("AND Subject LIKE @sub ");
                        cmd.Parameters.AddWithValue("@sub", $"%{criteria.SubjectQuery}%");
                    }
                }

                sb.Append("ORDER BY CreatedAt DESC LIMIT @lim;");
                cmd.Parameters.AddWithValue("@lim", limit);
                cmd.CommandText = sb.ToString();

                using SqliteDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    list.Add(ReadMetadata(r));
                }
            }
            catch { }

            return list;
        }

        public static List<MetadataRecord> GetUserMetadataHistory(string username, int limit = 200)
        {
            var list = new List<MetadataRecord>();
            try
            {
                using SqliteConnection conn = AppDatabase.OpenConnection();
                using SqliteCommand cmd = conn.CreateCommand();
                cmd.CommandText =
                    "SELECT Id, EventId, EventType, SenderUsername, ReceiverUsername, " +
                    "SenderUserId, ReceiverUserId, SenderDeviceId, ReceiverDeviceId, Subject, MessageType, " +
                    "FileName, FileExtension, ContentType, FileSize, TransferId, ConversationId, MessageId, " +
                    "CreatedAt, StartedAt, CompletedAt, DeliveryStatus, ReadStatus, TransferStatus, IntegrityStatus, " +
                    "AttachmentPresent, AttachmentType, ProtocolVersion, OriginEventId, SequenceNumber, " +
                    "PreviousEventHash, MetadataSignature FROM MetadataEvents " +
                    "WHERE SenderUsername=@u OR ReceiverUsername=@u " +
                    "ORDER BY CreatedAt DESC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@u", username);
                cmd.Parameters.AddWithValue("@lim", limit);

                using SqliteDataReader r = cmd.ExecuteReader();
                while (r.Read())
                {
                    list.Add(ReadMetadata(r));
                }
            }
            catch { }

            return list;
        }

        private static MetadataRecord ReadMetadata(SqliteDataReader r) => new()
        {
            Id                = r.GetInt64(0),
            EventId           = r.GetString(1),
            EventType         = r.GetString(2),
            SenderUsername    = r.GetString(3),
            ReceiverUsername  = r.GetString(4),
            SenderUserId      = r.IsDBNull(5) ? null : r.GetInt64(5),
            ReceiverUserId    = r.IsDBNull(6) ? null : r.GetInt64(6),
            SenderDeviceId    = r.GetString(7),
            ReceiverDeviceId  = r.GetString(8),
            Subject           = r.IsDBNull(9) ? "" : r.GetString(9),
            MessageType       = r.GetString(10),
            FileName          = r.IsDBNull(11) ? null : r.GetString(11),
            FileExtension     = r.IsDBNull(12) ? null : r.GetString(12),
            ContentType       = r.IsDBNull(13) ? null : r.GetString(13),
            FileSize          = r.IsDBNull(14) ? null : r.GetInt64(14),
            TransferId        = r.IsDBNull(15) ? null : r.GetString(15),
            ConversationId    = r.IsDBNull(16) ? null : r.GetString(16),
            MessageId         = r.IsDBNull(17) ? null : r.GetString(17),
            CreatedAt         = DateTime.Parse(r.GetString(18)),
            StartedAt         = r.IsDBNull(19) ? null : DateTime.Parse(r.GetString(19)),
            CompletedAt       = r.IsDBNull(20) ? null : DateTime.Parse(r.GetString(20)),
            DeliveryStatus    = r.GetString(21),
            ReadStatus        = r.IsDBNull(22) ? null : r.GetString(22),
            TransferStatus    = r.IsDBNull(23) ? null : r.GetString(23),
            IntegrityStatus   = r.IsDBNull(24) ? null : r.GetString(24),
            AttachmentPresent = r.GetInt64(25) != 0,
            AttachmentType    = r.IsDBNull(26) ? null : r.GetString(26),
            ProtocolVersion   = r.GetString(27),
            OriginEventId     = r.IsDBNull(28) ? null : r.GetString(28),
            SequenceNumber    = r.GetInt32(29),
            PreviousEventHash = r.IsDBNull(30) ? null : r.GetString(30),
            MetadataSignature = r.IsDBNull(31) ? null : r.GetString(31)
        };
    }
}
