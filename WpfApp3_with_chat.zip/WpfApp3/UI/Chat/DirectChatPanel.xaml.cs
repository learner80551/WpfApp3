using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp3.Authentication;
using WpfApp3.Core.Messaging;

namespace WpfApp3.UI.Chat
{
    public class DirectPeerListItem
    {
        public string DeviceId { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public bool IsOnline { get; set; }
        public string StatusText => IsOnline ? "Online" : "Offline";
    }

    public class DirectMessageViewModel
    {
        public string SenderUsername { get; set; } = "";
        public string Text { get; set; } = "";
        public string TimeDisplay { get; set; } = "";
        public bool IsSelf { get; set; }
    }

    public partial class DirectChatPanel : UserControl
    {
        private MessageManager? _messageManager;
        private MessagingTransportService? _transport;
        private Func<IEnumerable<PeerInfo>>? _getPeers;

        private readonly ObservableCollection<DirectPeerListItem> _peers = new();
        private readonly ObservableCollection<DirectMessageViewModel> _messages = new();

        private string? _selectedPeerDeviceId;

        public DirectChatPanel()
        {
            InitializeComponent();
            PeerList.ItemsSource = _peers;
            MessagesList.ItemsSource = _messages;
        }

        public void Initialize(
            MessageManager messageManager,
            MessagingTransportService transport,
            Func<IEnumerable<PeerInfo>> getPeers)
        {
            _messageManager = messageManager;
            _transport = transport;
            _getPeers = getPeers;

            _messageManager.MessageReceived += OnMessageReceived;

            RefreshPeerList();
        }

        /// <summary>Called by MainWindow whenever the discovered-peer set changes.</summary>
        public void RefreshPeerList()
        {
            if (_getPeers == null) return;

            string? selfDeviceId = SessionManager.CurrentSession?.DeviceId;

            List<PeerInfo> peers = _getPeers()
                .Where(p => !string.Equals(p.DeviceId, selfDeviceId, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(p => p.IsOnline)
                .ThenBy(p => p.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();

            string? previouslySelected = _selectedPeerDeviceId;

            _peers.Clear();
            foreach (PeerInfo p in peers)
            {
                _peers.Add(new DirectPeerListItem
                {
                    DeviceId = p.DeviceId,
                    DisplayName = string.IsNullOrWhiteSpace(p.Name) ? p.DeviceId : p.Name,
                    IsOnline = p.IsOnline
                });
            }

            if (previouslySelected != null)
            {
                DirectPeerListItem? match = _peers.FirstOrDefault(x =>
                    string.Equals(x.DeviceId, previouslySelected, StringComparison.OrdinalIgnoreCase));
                if (match != null) PeerList.SelectedItem = match;
            }

            EmptyStateText.Visibility = _peers.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        private void PeerList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PeerList.SelectedItem is not DirectPeerListItem item)
            {
                _selectedPeerDeviceId = null;
                ConversationHeader.Text = "Select a device to start chatting";
                _messages.Clear();
                InputArea.IsEnabled = false;
                return;
            }

            _selectedPeerDeviceId = item.DeviceId;
            ConversationHeader.Text = item.DisplayName;
            InputArea.IsEnabled = true;

            LoadConversation(item.DeviceId);
        }

        private void LoadConversation(string peerDeviceId)
        {
            _messages.Clear();
            if (_messageManager == null) return;

            foreach (AdvancedChatMessage msg in _messageManager.GetDirectConversation(peerDeviceId))
                _messages.Add(ToViewModel(msg));

            MessagesScroll.ScrollToEnd();
        }

        private void OnMessageReceived(AdvancedChatMessage msg)
        {
            if (!msg.IsDirectMessage) return;

            Dispatcher.Invoke(() =>
            {
                string? selfDeviceId = SessionManager.CurrentSession?.DeviceId;
                string? otherParty = string.Equals(msg.SenderDeviceId, selfDeviceId, StringComparison.OrdinalIgnoreCase)
                    ? msg.ReceiverDeviceId
                    : msg.SenderDeviceId;

                if (_selectedPeerDeviceId != null &&
                    string.Equals(otherParty, _selectedPeerDeviceId, StringComparison.OrdinalIgnoreCase))
                {
                    _messages.Add(ToViewModel(msg));
                    MessagesScroll.ScrollToEnd();
                }

                RefreshPeerList();
            });
        }

        private DirectMessageViewModel ToViewModel(AdvancedChatMessage msg)
        {
            string? selfDeviceId = SessionManager.CurrentSession?.DeviceId;
            return new DirectMessageViewModel
            {
                SenderUsername = msg.SenderUsername,
                Text = msg.Text,
                TimeDisplay = msg.Timestamp.ToLocalTime().ToString("HH:mm"),
                IsSelf = string.Equals(msg.SenderDeviceId, selfDeviceId, StringComparison.OrdinalIgnoreCase)
            };
        }

        private async void SendBtn_Click(object sender, RoutedEventArgs e) => await SendMessageAsync();

        private async void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
            {
                e.Handled = true;
                await SendMessageAsync();
            }
        }

        private async System.Threading.Tasks.Task SendMessageAsync()
        {
            string text = InputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(text)) return;
            if (_transport == null || _selectedPeerDeviceId == null) return;
            if (_getPeers == null) return;

            PeerInfo? target = _getPeers()
                .FirstOrDefault(p => string.Equals(p.DeviceId, _selectedPeerDeviceId, StringComparison.OrdinalIgnoreCase));

            if (target == null) return;

            InputBox.Clear();
            SendBtn.IsEnabled = false;

            try
            {
                AdvancedChatMessage sent = await _transport.SendDirectMessageAsync(target, text);
                _messages.Add(ToViewModel(sent));
                MessagesScroll.ScrollToEnd();
            }
            catch { /* Delivery failures are silent; the message stays in local history */ }
            finally
            {
                SendBtn.IsEnabled = true;
                InputBox.Focus();
            }
        }
    }
}
