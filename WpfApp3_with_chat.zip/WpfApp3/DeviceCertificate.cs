using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace WpfApp3
{
    public static class DeviceCertificate
    {
        private static readonly string CertificatePath =
            Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                "LANShare",
                "device.pfx");

        private static readonly byte[] DpapiEntropy =
            Encoding.UTF8.GetBytes("LANShare-Device-DPAPI-Entropy-v1");

        public static X509Certificate2 GetOrCreateCertificate()
        {
            string? folder =
                Path.GetDirectoryName(CertificatePath);

            if (!string.IsNullOrEmpty(folder))
            {
                Directory.CreateDirectory(folder);
            }

            // Load existing certificate
            if (File.Exists(CertificatePath))
            {
                byte[] rawFile = File.ReadAllBytes(CertificatePath);
                byte[] pfxBytes;
                bool wasLegacyUnencrypted = false;

                try
                {
                    // Windows Secure Storage via DPAPI
                    pfxBytes = ProtectedData.Unprotect(
                        rawFile,
                        DpapiEntropy,
                        DataProtectionScope.CurrentUser);
                }
                catch
                {
                    // Fallback: file was previously unencrypted legacy PKCS#12
                    pfxBytes = rawFile;
                    wasLegacyUnencrypted = true;
                }

                X509Certificate2 loadedCert = new X509Certificate2(
                    pfxBytes,
                    password: (string?)null,
                    keyStorageFlags:
                        X509KeyStorageFlags.Exportable |
                        X509KeyStorageFlags.PersistKeySet);

                // If it was legacy unencrypted, upgrade to DPAPI secure storage immediately
                if (wasLegacyUnencrypted)
                {
                    try
                    {
                        byte[] reEncrypted = ProtectedData.Protect(
                            pfxBytes,
                            DpapiEntropy,
                            DataProtectionScope.CurrentUser);
                        File.WriteAllBytes(CertificatePath, reEncrypted);
                    }
                    catch { }
                }

                return loadedCert;
            }

            // Create a new device key
            using RSA rsa = RSA.Create(2048);

            CertificateRequest request =
                new CertificateRequest(
                    "CN=LANShare Device",
                    rsa,
                    HashAlgorithmName.SHA256,
                    RSASignaturePadding.Pkcs1);

            request.CertificateExtensions.Add(
                new X509BasicConstraintsExtension(
                    certificateAuthority: false,
                    hasPathLengthConstraint: false,
                    pathLengthConstraint: 0,
                    critical: false));

            request.CertificateExtensions.Add(
                new X509KeyUsageExtension(
                    X509KeyUsageFlags.DigitalSignature,
                    critical: false));

            using X509Certificate2 certificate =
                request.CreateSelfSigned(
                    DateTimeOffset.UtcNow.AddMinutes(-5),
                    DateTimeOffset.UtcNow.AddYears(5));

            // Export certificate + private key
            byte[] pfx =
                certificate.Export(
                    X509ContentType.Pfx);

            // Protect with Windows DPAPI before writing to disk
            byte[] protectedPfx = ProtectedData.Protect(
                pfx,
                DpapiEntropy,
                DataProtectionScope.CurrentUser);

            File.WriteAllBytes(
                CertificatePath,
                protectedPfx);

            // Load the saved certificate
            return new X509Certificate2(
                pfx,
                password: (string?)null,
                keyStorageFlags:
                    X509KeyStorageFlags.Exportable |
                    X509KeyStorageFlags.PersistKeySet);
        }

        public static string GetFingerprint(
            X509Certificate2 certificate)
        {
            return certificate.GetCertHashString(
                HashAlgorithmName.SHA256);
        }
    }
}