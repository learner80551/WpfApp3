using System;
using Microsoft.Data.Sqlite;
using WpfApp3.Database;

namespace WpfApp3.Admin
{
    public class DashboardSummary
    {
        // Device metrics
        public int TotalDevices { get; set; }
        public int OnlineDevices { get; set; }
        public int OfflineDevices { get; set; }
        public int BlockedDevices { get; set; }

        // Today metrics
        public int TodayMessages { get; set; }
        public int TodayTransfers { get; set; }
        public long TodayBytesTransferred { get; set; }

        // Security metrics
        public int SecurityAlertsCount { get; set; }
        public int UnacknowledgedAlerts { get; set; }
    }

    public static class DashboardMetrics
    {
        public static DashboardSummary GetSummary()
        {
            var summary = new DashboardSummary();
            try
            {
                using var conn = AppDatabase.OpenConnection();

                // 1. Device stats
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
SELECT 
    COUNT(*),
    SUM(CASE WHEN Status='ONLINE' AND IsRevoked=0 THEN 1 ELSE 0 END),
    SUM(CASE WHEN Status='OFFLINE' AND IsRevoked=0 THEN 1 ELSE 0 END),
    SUM(CASE WHEN Status='BLOCKED' OR IsRevoked=1 THEN 1 ELSE 0 END)
FROM Devices;";
                    using var r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        summary.TotalDevices = r.IsDBNull(0) ? 0 : r.GetInt32(0);
                        summary.OnlineDevices = r.IsDBNull(1) ? 0 : r.GetInt32(1);
                        summary.OfflineDevices = r.IsDBNull(2) ? 0 : r.GetInt32(2);
                        summary.BlockedDevices = r.IsDBNull(3) ? 0 : r.GetInt32(3);
                    }
                }

                // 2. Today's Messages
                string todayStart = DateTime.UtcNow.Date.ToString("O");
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT COUNT(*) FROM ChatMessages WHERE Timestamp >= @today;";
                    cmd.Parameters.AddWithValue("@today", todayStart);
                    summary.TodayMessages = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);
                }

                // 3. Today's Transfers
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
SELECT COUNT(*), COALESCE(SUM(TransferredBytes), 0) 
FROM Transfers 
WHERE CreatedAt >= @today AND Status='COMPLETED';";
                    cmd.Parameters.AddWithValue("@today", todayStart);
                    using var r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        summary.TodayTransfers = r.IsDBNull(0) ? 0 : r.GetInt32(0);
                        summary.TodayBytesTransferred = r.IsDBNull(1) ? 0 : r.GetInt64(1);
                    }
                }

                // 4. Security Alerts
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"
SELECT COUNT(*), SUM(CASE WHEN Acknowledged=0 THEN 1 ELSE 0 END) 
FROM SecurityAlerts;";
                    using var r = cmd.ExecuteReader();
                    if (r.Read())
                    {
                        summary.SecurityAlertsCount = r.IsDBNull(0) ? 0 : r.GetInt32(0);
                        summary.UnacknowledgedAlerts = r.IsDBNull(1) ? 0 : r.GetInt32(1);
                    }
                }
            }
            catch { }

            return summary;
        }
    }
}
