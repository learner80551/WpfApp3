using System;
using System.Collections.Generic;

namespace WpfApp3.Core.Security
{
    public static class Permissions
    {
        public const string UserView            = "USER_VIEW";
        public const string UserApprove         = "USER_APPROVE";
        public const string UserReject          = "USER_REJECT";
        public const string UserSuspend         = "USER_SUSPEND";
        public const string UserRevoke          = "USER_REVOKE";

        public const string DeviceView          = "DEVICE_VIEW";
        public const string DeviceApprove       = "DEVICE_APPROVE";
        public const string DeviceSuspend       = "DEVICE_SUSPEND";
        public const string DeviceRevoke        = "DEVICE_REVOKE";

        public const string HistoryMetadataView = "HISTORY_METADATA_VIEW";
        public const string AuditView           = "AUDIT_VIEW";
        public const string SecurityEventView   = "SECURITY_EVENT_VIEW";

        public static readonly IReadOnlyList<string> AllSupervisorPermissions = new[]
        {
            UserView,
            UserApprove,
            UserReject,
            UserSuspend,
            UserRevoke,
            DeviceView,
            DeviceApprove,
            DeviceSuspend,
            DeviceRevoke,
            HistoryMetadataView,
            AuditView,
            SecurityEventView
        };
    }
}
