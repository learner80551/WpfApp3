using System;
using System.Collections.Generic;

namespace WpfApp3.Core.Devices
{
    public enum DeviceStatus
    {
        ONLINE,
        AWAY,
        OFFLINE,
        BLOCKED,
        UNKNOWN
    }

    [Obsolete("Legacy trust status enum; use DeviceState instead for authoritative lifecycle.")]
    public enum DeviceTrustStatus
    {
        PAIRED,
        UNPAIRED,
        REVOKED,
        UNKNOWN
    }

    public enum DeviceState
    {
        DISCOVERED,
        UNTRUSTED,
        PENDING_APPROVAL,
        AUTHORIZED,
        SUSPENDED,
        REVOKED
    }

    /// <summary>
    /// Unified representation of a LANShare device across discovery,
    /// persistence, and active connections.
    /// </summary>
    public class DeviceInfo
    {
        public string DeviceId { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string Hostname { get; set; } = "";
        public string IpAddress { get; set; } = "";
        public string OperatingSystem { get; set; } = "";
        public string ClientVersion { get; set; } = "";
        public DeviceStatus Status { get; set; } = DeviceStatus.UNKNOWN;
        public DeviceTrustStatus TrustStatus { get; set; } = DeviceTrustStatus.UNKNOWN;
        public DeviceState State { get; set; } = DeviceState.PENDING_APPROVAL;
        public string? PublicKey { get; set; }
        public DateTime LastSeenUtc { get; set; } = DateTime.UtcNow;
        public string CertificateFingerprint { get; set; } = "";
        public bool IsAuthorized { get; set; }
        public bool IsRevoked { get; set; }
        public long? UserId { get; set; }
        public string Username { get; set; } = "";
        public List<string> GroupIds { get; set; } = new();

        public bool IsOnline => Status == DeviceStatus.ONLINE;

        public DeviceInfo Clone()
        {
            return new DeviceInfo
            {
                DeviceId = DeviceId,
                DisplayName = DisplayName,
                Hostname = Hostname,
                IpAddress = IpAddress,
                OperatingSystem = OperatingSystem,
                ClientVersion = ClientVersion,
                Status = Status,
                TrustStatus = TrustStatus,
                State = State,
                PublicKey = PublicKey,
                LastSeenUtc = LastSeenUtc,
                CertificateFingerprint = CertificateFingerprint,
                IsAuthorized = IsAuthorized,
                IsRevoked = IsRevoked,
                UserId = UserId,
                Username = Username,
                GroupIds = new List<string>(GroupIds)
            };
        }
    }
}
