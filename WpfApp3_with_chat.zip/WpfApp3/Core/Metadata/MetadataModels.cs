using System;

namespace WpfApp3.Core.Metadata
{
    public class MetadataRecord
    {
        public long Id { get; set; }
        public string EventId { get; set; } = Guid.NewGuid().ToString();
        public string EventType { get; set; } = "MESSAGE"; // MESSAGE or FILE_TRANSFER
        public string SenderUsername { get; set; } = "";
        public string ReceiverUsername { get; set; } = "";
        public long? SenderUserId { get; set; }
        public long? ReceiverUserId { get; set; }
        public string SenderDeviceId { get; set; } = "";
        public string ReceiverDeviceId { get; set; } = "";
        public string Subject { get; set; } = "";
        public string MessageType { get; set; } = "TEXT"; // TEXT, FILE, SYSTEM
        public string? FileName { get; set; }
        public string? FileExtension { get; set; }
        public string? ContentType { get; set; }
        public long? FileSize { get; set; }
        public string? TransferId { get; set; }
        public string? ConversationId { get; set; }
        public string? MessageId { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? StartedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public string DeliveryStatus { get; set; } = "SENT"; // SENT, DELIVERED, READ
        public string? ReadStatus { get; set; }
        public string? TransferStatus { get; set; } // QUEUED, IN_PROGRESS, COMPLETED, FAILED
        public string? IntegrityStatus { get; set; } // VERIFIED, FAILED, UNCHECKED
        public bool AttachmentPresent { get; set; }
        public string? AttachmentType { get; set; }
        public string ProtocolVersion { get; set; } = "2.0";
        public string? OriginEventId { get; set; }
        public int SequenceNumber { get; set; } = 1;
        public string? PreviousEventHash { get; set; }
        public string? MetadataSignature { get; set; }

        // Formatted display helpers
        public string FormattedSize => FileSize.HasValue ? $"{FileSize.Value / 1024.0 / 1024.0:F2} MB" : "-";
        public string DisplayTimestamp => CreatedAt.ToLocalTime().ToString("dd-MM-yyyy HH:mm:ss");
    }

    public class MetadataFilterCriteria
    {
        public string? Sender { get; set; }
        public string? Receiver { get; set; }
        public string? MessageType { get; set; }
        public string? FileExtension { get; set; }
        public string? TransferStatus { get; set; }
        public string? IntegrityStatus { get; set; }
        public string? SubjectQuery { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
