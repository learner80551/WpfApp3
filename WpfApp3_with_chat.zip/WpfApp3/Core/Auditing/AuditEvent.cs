using System;

namespace WpfApp3.Core.Auditing
{
    public enum AuditSeverity
    {
        INFO,
        WARNING,
        HIGH,
        CRITICAL
    }

    public class AuditEvent
    {
        public string EventId { get; set; } = Guid.NewGuid().ToString();
        public string EventType { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string SourceDeviceId { get; set; } = "";
        public string? TargetDeviceId { get; set; }
        public string Actor { get; set; } = "";
        public AuditSeverity Severity { get; set; } = AuditSeverity.INFO;
        public string Description { get; set; } = "";
        public string? MetadataJson { get; set; }
    }
}
