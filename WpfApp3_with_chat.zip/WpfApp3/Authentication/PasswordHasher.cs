using System;
using System.Security.Cryptography;
using System.Text;
using Konscious.Security.Cryptography;

namespace WpfApp3.Authentication
{
    /// <summary>
    /// Argon2id password hashing with secure parameters.
    /// Memory: 64 MB (65,536 KB), Iterations: 3, Parallelism: 2, Salt: 16 bytes.
    /// Includes backward compatibility for verifying and upgrading legacy PBKDF2 hashes.
    /// Passwords are NEVER stored in plaintext.
    /// </summary>
    public static class PasswordHasher
    {
        private const int SaltBytes = 16;
        private const int HashBytes = 32;
        private const int MemorySizeKb = 65536; // 64 MB
        private const int Iterations = 3;
        private const int DegreeOfParallelism = 2;

        private const string Argon2Prefix = "ARGON2ID:";

        // Legacy PBKDF2 parameters for backward compatibility
        private const int LegacyIterations = 600_000;
        private static readonly HashAlgorithmName LegacyAlgorithm = HashAlgorithmName.SHA256;

        /// <summary>Returns (hash, salt) both as Base64 strings using Argon2id.</summary>
        public static (string Hash, string Salt) HashPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
                throw new ArgumentException("Password must not be empty.", nameof(password));

            byte[] saltBytes = RandomNumberGenerator.GetBytes(SaltBytes);

            using var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
            {
                Salt = saltBytes,
                DegreeOfParallelism = DegreeOfParallelism,
                MemorySize = MemorySizeKb,
                Iterations = Iterations
            };

            byte[] hashBytes = argon2.GetBytes(HashBytes);

            return (
                Argon2Prefix + Convert.ToBase64String(hashBytes),
                Convert.ToBase64String(saltBytes)
            );
        }

        /// <summary>Returns true if the password matches the stored hash+salt.</summary>
        public static bool VerifyPassword(
            string password,
            string storedHashBase64,
            string storedSaltBase64)
        {
            if (string.IsNullOrEmpty(password))         return false;
            if (string.IsNullOrEmpty(storedHashBase64)) return false;
            if (string.IsNullOrEmpty(storedSaltBase64)) return false;

            try
            {
                byte[] saltBytes = Convert.FromBase64String(storedSaltBase64);

                if (storedHashBase64.StartsWith(Argon2Prefix, StringComparison.OrdinalIgnoreCase))
                {
                    string rawHashBase64 = storedHashBase64.Substring(Argon2Prefix.Length);
                    byte[] expectedHash = Convert.FromBase64String(rawHashBase64);

                    using var argon2 = new Argon2id(Encoding.UTF8.GetBytes(password))
                    {
                        Salt = saltBytes,
                        DegreeOfParallelism = DegreeOfParallelism,
                        MemorySize = MemorySizeKb,
                        Iterations = Iterations
                    };

                    byte[] computedHash = argon2.GetBytes(expectedHash.Length);
                    return CryptographicOperations.FixedTimeEquals(computedHash, expectedHash);
                }
                else
                {
                    // Fallback to legacy PBKDF2 for pre-existing accounts
                    byte[] expectedHash = Convert.FromBase64String(storedHashBase64);
                    byte[] computedHash = Rfc2898DeriveBytes.Pbkdf2(
                        Encoding.UTF8.GetBytes(password),
                        saltBytes,
                        LegacyIterations,
                        LegacyAlgorithm,
                        expectedHash.Length);

                    return CryptographicOperations.FixedTimeEquals(computedHash, expectedHash);
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Returns true if the stored hash is an older format that should be re-hashed.</summary>
        public static bool NeedsRehash(string storedHash)
        {
            return !storedHash.StartsWith(Argon2Prefix, StringComparison.OrdinalIgnoreCase);
        }
    }
}
