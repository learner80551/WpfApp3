using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;
using WpfApp3.Core.Transfers;

namespace WpfApp3.Database
{
    public static class TransferRepository
    {
        public static bool SaveSession(TransferSession session)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
INSERT INTO Transfers (
    TransferId, Direction, RemoteDeviceId, RemoteEndpoint, TotalFiles,
    TotalBytes, TransferredBytes, Status, Sha256, TargetDirectory,
    CreatedAt, CompletedAt, ErrorMessage
) VALUES (
    @tid, @dir, @rd, @rep, @tf,
    @tb, @trb, @st, @sha, @td,
    @ca, @cma, @err
)
ON CONFLICT(TransferId) DO UPDATE SET
    TransferredBytes = excluded.TransferredBytes,
    Status = excluded.Status,
    CompletedAt = excluded.CompletedAt,
    ErrorMessage = excluded.ErrorMessage;";

                cmd.Parameters.AddWithValue("@tid", session.TransferId);
                cmd.Parameters.AddWithValue("@dir", session.Direction.ToString());
                cmd.Parameters.AddWithValue("@rd", session.RemoteDeviceId);
                cmd.Parameters.AddWithValue("@rep", (object?)session.RemoteEndpoint ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@tf", session.TotalFiles);
                cmd.Parameters.AddWithValue("@tb", session.TotalBytes);
                cmd.Parameters.AddWithValue("@trb", session.TransferredBytes);
                cmd.Parameters.AddWithValue("@st", session.Status.ToString());
                cmd.Parameters.AddWithValue("@sha", (object?)session.Sha256 ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@td", (object?)session.TargetDirectory ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@ca", session.CreatedAt.ToString("O"));
                cmd.Parameters.AddWithValue("@cma", session.CompletedAt.HasValue ? session.CompletedAt.Value.ToString("O") : DBNull.Value);
                cmd.Parameters.AddWithValue("@err", (object?)session.ErrorMessage ?? DBNull.Value);

                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool UpdateProgress(string transferId, long transferredBytes, TransferStatus status)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE Transfers SET TransferredBytes=@trb, Status=@st WHERE TransferId=@tid;";
                cmd.Parameters.AddWithValue("@trb", transferredBytes);
                cmd.Parameters.AddWithValue("@st", status.ToString());
                cmd.Parameters.AddWithValue("@tid", transferId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool MarkCompleted(string transferId, TransferStatus status = TransferStatus.COMPLETED, string? sha256 = null)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
UPDATE Transfers 
SET Status=@st, CompletedAt=@ts, Sha256=COALESCE(@sha, Sha256)
WHERE TransferId=@tid;";
                cmd.Parameters.AddWithValue("@st", status.ToString());
                cmd.Parameters.AddWithValue("@ts", DateTime.UtcNow.ToString("O"));
                cmd.Parameters.AddWithValue("@sha", (object?)sha256 ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@tid", transferId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static List<TransferSession> GetHistory(int limit = 100)
        {
            var list = new List<TransferSession>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT TransferId, Direction, RemoteDeviceId, RemoteEndpoint, TotalFiles,
       TotalBytes, TransferredBytes, Status, Sha256, TargetDirectory,
       CreatedAt, CompletedAt, ErrorMessage
FROM Transfers
ORDER BY CreatedAt DESC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read())
                {
                    _ = Enum.TryParse<TransferDirection>(r.GetString(1), true, out var dir);
                    _ = Enum.TryParse<TransferStatus>(r.GetString(7), true, out var st);

                    list.Add(new TransferSession
                    {
                        TransferId = r.GetString(0),
                        Direction = dir,
                        RemoteDeviceId = r.GetString(2),
                        RemoteEndpoint = r.IsDBNull(3) ? "" : r.GetString(3),
                        TotalFiles = r.GetInt32(4),
                        TotalBytes = r.GetInt64(5),
                        TransferredBytes = r.GetInt64(6),
                        Status = st,
                        Sha256 = r.IsDBNull(8) ? null : r.GetString(8),
                        TargetDirectory = r.IsDBNull(9) ? "" : r.GetString(9),
                        CreatedAt = DateTime.Parse(r.GetString(10)),
                        CompletedAt = r.IsDBNull(11) ? null : DateTime.Parse(r.GetString(11)),
                        ErrorMessage = r.IsDBNull(12) ? null : r.GetString(12)
                    });
                }
            }
            catch { }
            return list;
        }
    }
}
