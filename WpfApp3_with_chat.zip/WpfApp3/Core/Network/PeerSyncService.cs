using System;
using System.Collections.Generic;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using WpfApp3.Core.Auditing;
using WpfApp3.Core.Metadata;
using WpfApp3.Core.Security;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Core.Network
{
    /// <summary>
    /// Background P2P Synchronization Service for the Metadata and Authority planes.
    /// Strictly maintains three-plane isolation: only metadata, audit trails, and signed authorization events
    /// are synchronized. Chat bodies and file content are NEVER transferred via this service.
    /// </summary>
    public static class PeerSyncService
    {
        private static readonly TimeSpan ConnectTimeout = TimeSpan.FromSeconds(5);
        private static readonly TimeSpan ReadTimeout = TimeSpan.FromSeconds(10);

        /// <summary>
        /// Pushes pending audit sync records and authorization events to an authorized online peer.
        /// </summary>
        public static async Task SyncWithPeerAsync(
            string peerIp,
            int transferPort,
            string expectedFingerprint,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(peerIp) || string.IsNullOrWhiteSpace(expectedFingerprint))
                return;

            // Authoritative Zero-Trust check: peer must be explicitly AUTHORIZED
            if (!UserRepository.IsDeviceAuthorized(fingerprint: expectedFingerprint))
                return;

            List<AuditSyncQueueItem> pendingAudits = AuditSyncService.GetPendingSyncItems(25);
            List<AuthorizationEventRecord> authorizationEvents = UserRepository.GetAuthorizationEvents(25);
            if (pendingAudits.Count == 0 && authorizationEvents.Count == 0)
                return;

            X509Certificate2 localCert;
            try
            {
                localCert = DeviceCertificate.GetOrCreateCertificate();
            }
            catch
            {
                return;
            }

            string localDeviceId = DeviceIdentity.GetOrCreateDeviceId();

            using var client = new TcpClient();
            client.NoDelay = true;

            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(ConnectTimeout);

            try
            {
                await client.ConnectAsync(peerIp, transferPort, cts.Token);

                using var ssl = new SslStream(
                    client.GetStream(),
                    false,
                    (_, cert, _, _) =>
                    {
                        if (cert == null) return false;
                        string fp = cert.GetCertHashString(System.Security.Cryptography.HashAlgorithmName.SHA256);
                        return string.Equals(fp, expectedFingerprint, StringComparison.OrdinalIgnoreCase);
                    });

                await ssl.AuthenticateAsClientAsync(new SslClientAuthenticationOptions
                {
                    TargetHost = "LANShare Device",
                    ClientCertificates = new X509CertificateCollection { localCert },
                    EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
                    CertificateRevocationCheckMode = X509RevocationMode.NoCheck
                }, cts.Token);

                if (authorizationEvents.Count > 0)
                {
                    var authMsg = ProtocolMessage.Create(
                        ProtocolMessageTypes.AuthEventSync,
                        localDeviceId,
                        authorizationEvents,
                        localCert);
                    byte[] authBytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(authMsg) + "\n");
                    await ssl.WriteAsync(authBytes, cancellationToken);
                    await ssl.FlushAsync(cancellationToken);
                }

                if (pendingAudits.Count > 0)
                {
                    var auditMsg = ProtocolMessage.Create(
                        ProtocolMessageTypes.AuditSync,
                        localDeviceId,
                        pendingAudits,
                        localCert);
                    byte[] auditBytes = Encoding.UTF8.GetBytes(JsonSerializer.Serialize(auditMsg) + "\n");
                    await ssl.WriteAsync(auditBytes, cancellationToken);
                    await ssl.FlushAsync(cancellationToken);
                }

                // Mark synchronized locally upon successful transmission
                foreach (var item in pendingAudits)
                {
                    AuditSyncService.MarkSynchronized(item.EventId);
                }
            }
            catch
            {
                foreach (var item in pendingAudits)
                {
                    AuditSyncService.RecordFailedAttempt(item.EventId);
                }
            }
        }

        /// <summary>
        /// Handles incoming metadata/audit/auth sync messages received on authenticated TLS connections.
        /// </summary>
        public static bool HandleIncomingSyncMessage(
            string jsonLine,
            string clientFingerprint,
            X509Certificate2? clientCert)
        {
            if (string.IsNullOrWhiteSpace(jsonLine)) return false;

            ProtocolMessage? msg;
            try
            {
                msg = JsonSerializer.Deserialize<ProtocolMessage>(jsonLine);
            }
            catch
            {
                return false;
            }

            if (msg == null) return false;

            // Replay protection & envelope validation
            if (!msg.Validate(out _)) return false;

            // Authoritative Zero-Trust check: bind the claimed sender to the
            // authenticated TLS client certificate. Checking deviceId alone
            // trusts a spoofable claim, and passing the fingerprint only as a
            // fallback never verifies that both refer to the same device.
            DeviceRecord? certDevice =
                UserRepository.FindDeviceByFingerprint(clientFingerprint);

            if (certDevice == null ||
                !UserRepository.IsDeviceAuthorized(deviceId: certDevice.DeviceId))
            {
                AuditRepository.Log("SecurityAlert", "System", msg.SenderDeviceId,
                    "UnauthorizedSyncAttempt", "Rejected: Device is not authorized.");
                return false;
            }

            DeviceRecord? claimedDevice =
                UserRepository.FindDevice(msg.SenderDeviceId);

            if (claimedDevice != null &&
                (!FingerprintsMatch(claimedDevice.CertificateFingerprint, clientFingerprint) ||
                 !UserRepository.IsDeviceAuthorized(deviceId: claimedDevice.DeviceId)))
            {
                AuditRepository.Log("SecurityAlert", "System", msg.SenderDeviceId,
                    "SenderIdentityMismatch",
                    "Rejected: Claimed device id does not match the connection certificate.");
                return false;
            }

            // Attribute the rest of processing (heartbeats, audit logs) to the
            // verified identity.
            msg.SenderDeviceId = claimedDevice?.DeviceId ?? certDevice.DeviceId;

            // If signature is provided, verify it
            if (!string.IsNullOrWhiteSpace(msg.Signature) && clientCert != null)
            {
                if (!msg.VerifySignature(clientCert))
                {
                    AuditRepository.Log("SecurityAlert", "System", msg.SenderDeviceId,
                        "InvalidSyncSignature", "Rejected");
                    return false;
                }
            }

            switch (msg.MessageType)
            {
                case ProtocolMessageTypes.AuditSync:
                    var items = msg.DeserializePayload<List<AuditSyncQueueItem>>();
                    if (items != null)
                    {
                        foreach (var itm in items)
                        {
                            try
                            {
                                var auditEvt = JsonSerializer.Deserialize<AuditEvent>(itm.PayloadJson);
                                if (auditEvt != null)
                                {
                                    AuditSyncService.LogAndEnqueue(auditEvt);
                                }
                            }
                            catch { }
                        }
                    }
                    return true;

                case ProtocolMessageTypes.AuthEventSync:
                    var authEvents = msg.DeserializePayload<List<AuthorizationEventRecord>>();
                    if (authEvents != null)
                    {
                        foreach (var evt in authEvents)
                        {
                            var result = CryptographicAuthority.ProcessAuthorizationEvent(evt, clientCert);
                            if (!result.Success)
                            {
                                AuditRepository.Log("SecurityAlert", "System", msg.SenderDeviceId,
                                    "InvalidAuthorizationEvent", result.Reason);
                            }
                        }
                    }
                    return true;

                case ProtocolMessageTypes.MetadataSync:
                    var metaRecords = msg.DeserializePayload<List<MetadataRecord>>();
                    if (metaRecords != null)
                    {
                        foreach (var meta in metaRecords)
                        {
                            MetadataRepository.RecordMetadata(meta);
                        }
                    }
                    return true;

                case ProtocolMessageTypes.Heartbeat:
                    UserRepository.UpdateDeviceLastSeen(msg.SenderDeviceId);
                    return true;

                default:
                    return false;
            }
        }

        private static bool FingerprintsMatch(string? a, string? b)
        {
            static string Norm(string? s) =>
                (s ?? "")
                    .Replace(":", "")
                    .Replace("-", "")
                    .Replace(" ", "")
                    .Trim()
                    .ToUpperInvariant();

            return !string.IsNullOrWhiteSpace(a) &&
                   !string.IsNullOrWhiteSpace(b) &&
                   string.Equals(Norm(a), Norm(b), StringComparison.Ordinal);
        }
    }
}
