using System;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Authentication
{
    public enum LoginResultCode
    {
        Success,
        InvalidCredentials,
        AccountDisabled,
        PendingApproval,
        DeviceNotAuthorized,
        DeviceRevoked,
        ForcePasswordReset
    }

    public class LoginResult
    {
        public LoginResultCode Code    { get; init; }
        public AppSession?     Session { get; init; }
        public string          Message { get; init; } = "";

        public bool IsSuccess => Code == LoginResultCode.Success ||
                                 Code == LoginResultCode.ForcePasswordReset;
    }

    public static class AuthenticationService
    {
        // ──────────────────────────────────────────────────
        // FIRST RUN
        // ──────────────────────────────────────────────────

        public static bool IsFirstRun() => !UserRepository.AdminExists();

        /// <summary>
        /// Creates the initial administrator account.
        /// Atomic race protection prevents multiple Admins.
        /// </summary>
        public static (bool Success, string Error, string DeviceId) CreateAdmin(
            string username, string password, string displayName = "")
        {
            if (string.IsNullOrWhiteSpace(username))
                return (false, "Username is required.", "");

            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                return (false, "Password must be at least 8 characters.", "");

            if (UserRepository.AdminExists())
                return (false, "An administrator already exists. Only one permanent administrator is permitted.", "");

            if (UserRepository.FindByUsername(username) != null)
                return (false, "Username already exists.", "");

            string deviceId = DeviceIdentity.GetOrCreateDeviceId();
            string? fingerprint = DeviceIdentity.GetCertificateFingerprint();
            string? publicKey = DeviceIdentity.GetPublicKeyString();

            if (string.IsNullOrWhiteSpace(publicKey))
                return (false, "The device public key could not be established.", "");

            if (UserRepository.FindDevice(deviceId) != null)
                return (false, "This device is already registered.", "");

            try
            {
                var (hash, salt) = PasswordHasher.HashPassword(password);

                // User + device + authority epoch commit in ONE transaction:
                // any failure rolls everything back, so a partial failure can
                // no longer brick first-run setup with an orphaned admin row.
                long userId = UserRepository.CreateUserWithDevice(
                    username, "Admin", hash, salt,
                    accountState: AccountStates.Active,
                    displayName: string.IsNullOrWhiteSpace(displayName) ? username : displayName,
                    email: "",
                    deviceId: deviceId,
                    deviceDisplayName: "LANShare Peer",
                    certFingerprint: fingerprint,
                    publicKey: publicKey,
                    deviceState: DeviceStates.Authorized,
                    isAuthorized: true,
                    initializeAuthority: true);

                // Post-commit audit/event writes must never make CreateAdmin
                // report failure after the admin row is already committed.
                try
                {
                    var evt = Core.Security.CryptographicAuthority.CreateSignedEvent(
                        "ADMIN_CREATED", userId, deviceId, userId, "Admin", new { Admin = username });
                    UserRepository.RecordAuthorizationEvent(evt);

                    AuditRepository.Log(
                        action: "AdminCreated",
                        actorUsername: username,
                        actorDeviceId: deviceId,
                        target: username,
                        result: "Success");
                }
                catch { }

                return (true, "", deviceId);
            }
            catch (Exception ex)
            {
                return (false, $"Administrator creation failed: {ex.Message}", "");
            }
        }

        // ──────────────────────────────────────────────────
        // USER SIGNUP (Starts in PENDING state)
        // ──────────────────────────────────────────────────

        public static (bool Success, string Error, long UserId) SignUp(
            string username, string password, string displayName = "", string email = "")
        {
            if (string.IsNullOrWhiteSpace(username))
                return (false, "Username is required.", 0);

            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                return (false, "Password must be at least 8 characters.", 0);

            if (UserRepository.FindByUsername(username) != null)
                return (false, $"Username '{username}' is already taken.", 0);

            string deviceId = DeviceIdentity.GetOrCreateDeviceId();
            string? fingerprint = DeviceIdentity.GetCertificateFingerprint();
            string? publicKey = DeviceIdentity.GetPublicKeyString();
            if (string.IsNullOrWhiteSpace(publicKey))
                return (false, "The device public key could not be established.", 0);

            if (UserRepository.FindDevice(deviceId) != null)
                return (false, "This device is already registered.", 0);

            try
            {
                var (hash, salt) = PasswordHasher.HashPassword(password);

                // User + device commit in ONE transaction: a partial failure
                // can no longer leave an orphaned Pending user behind that
                // reserves the username forever.
                long userId = UserRepository.CreateUserWithDevice(
                    username, "User", hash, salt,
                    accountState: AccountStates.Pending,
                    displayName: string.IsNullOrWhiteSpace(displayName) ? username : displayName,
                    email: email,
                    deviceId: deviceId,
                    deviceDisplayName: "LANShare Peer",
                    certFingerprint: fingerprint,
                    publicKey: publicKey,
                    deviceState: DeviceStates.PendingApproval,
                    isAuthorized: false);

                try
                {
                    AuditRepository.Log("USER_REGISTERED", username, deviceId, username, "PendingApproval");
                }
                catch { }

                return (true, "Account registered successfully. Your account is PENDING approval by an administrator or supervisor.", userId);
            }
            catch (Exception ex)
            {
                return (false, $"Registration failed: {ex.Message}", 0);
            }
        }

        // ──────────────────────────────────────────────────
        // LOGIN
        // ──────────────────────────────────────────────────

        public static LoginResult Login(
            string username, string password, string deviceId)
        {
            if (string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password))
            {
                return Fail(LoginResultCode.InvalidCredentials, "Credentials are required.");
            }

            UserRecord? user = UserRepository.FindByUsername(username);

            if (user == null)
            {
                // Perform dummy hash to prevent username enumeration via timing
                PasswordHasher.VerifyPassword(
                    password,
                    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
                    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
                AuditRepository.Log("LoginFailure", username, deviceId,
                    username, "UserNotFound");
                return Fail(LoginResultCode.InvalidCredentials, "Invalid credentials.");
            }

            // Verify the password BEFORE disclosing any account state —
            // otherwise an unauthenticated caller can learn that an account
            // exists in pending/suspended/locked/etc. state.
            bool passwordOk = PasswordHasher.VerifyPassword(
                password, user.PasswordHash, user.PasswordSalt);

            if (!passwordOk)
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    username, "WrongPassword");
                return Fail(LoginResultCode.InvalidCredentials, "Invalid credentials.");
            }

            // Check Account States: PENDING, SUSPENDED, REVOKED, LOCKED, EXPIRED
            if (string.Equals(user.AccountState, AccountStates.Pending, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("LoginPending", username, deviceId, username, "AccountPendingApproval");
                return Fail(LoginResultCode.PendingApproval,
                    "Your account registration is pending administrator or supervisor approval.");
            }

            if (string.Equals(user.AccountState, AccountStates.Suspended, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("LoginFailure", username, deviceId, username, "AccountSuspended");
                return Fail(LoginResultCode.AccountDisabled,
                    "This account is currently suspended. Contact your administrator.");
            }

            if (string.Equals(user.AccountState, AccountStates.Revoked, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("LoginFailure", username, deviceId, username, "AccountRevoked");
                return Fail(LoginResultCode.AccountDisabled,
                    "This account authorization has been revoked.");
            }

            if (string.Equals(user.AccountState, AccountStates.Locked, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("LoginFailure", username, deviceId, username, "AccountLocked");
                return Fail(LoginResultCode.AccountDisabled,
                    "This account is temporarily locked.");
            }

            if (string.Equals(user.AccountState, AccountStates.Expired, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("LoginFailure", username, deviceId, username, "AccountExpired");
                return Fail(LoginResultCode.AccountDisabled,
                    "This account authorization has expired.");
            }

            if (!user.IsActive)
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    username, "AccountDisabled");
                return Fail(LoginResultCode.AccountDisabled,
                    "This account is disabled. Contact your administrator.");
            }

            // Device authorization check
            DeviceRecord? device = UserRepository.FindDevice(deviceId);

            if (device == null)
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    deviceId, "DeviceNotFound");
                return Fail(LoginResultCode.DeviceNotAuthorized,
                    "This device is not authorized. Contact your administrator.");
            }

            if (device.UserId != user.Id)
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    deviceId, "DeviceUserMismatch");
                return Fail(LoginResultCode.DeviceNotAuthorized,
                    "This device is not registered to this account.");
            }

            if (device.IsRevoked)
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    deviceId, "DeviceRevoked");
                return Fail(LoginResultCode.DeviceRevoked,
                    "This device has been revoked. Contact your administrator.");
            }

            if (!device.IsAuthorized)
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    deviceId, "DeviceNotAuthorized");
                return Fail(LoginResultCode.DeviceNotAuthorized,
                    "This device is not authorized. Contact your administrator.");
            }

            if (!string.Equals(device.DeviceState, DeviceStates.Authorized, StringComparison.OrdinalIgnoreCase))
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    deviceId, "DeviceStateNotAuthorized");
                return Fail(LoginResultCode.DeviceNotAuthorized,
                    "This device is not authorized. Contact your administrator.");
            }

            string? currentPublicKey = DeviceIdentity.GetPublicKeyString();
            if (string.IsNullOrWhiteSpace(device.PublicKey) ||
                !string.Equals(device.PublicKey, currentPublicKey, StringComparison.Ordinal))
            {
                AuditRepository.Log("LoginFailure", username, deviceId,
                    deviceId, "DevicePublicKeyMismatch");
                return Fail(LoginResultCode.DeviceNotAuthorized,
                    "This device identity does not match its registration.");
            }

            // Update cert fingerprint in DB so admin can see it
            string? currentFingerprint = DeviceIdentity.GetCertificateFingerprint();
            if (!string.IsNullOrWhiteSpace(currentFingerprint))
                UserRepository.UpdateDeviceCertFingerprint(deviceId, currentFingerprint);

            UserRepository.RecordLogin(user.Id);
            UserRepository.UpdateDeviceLastSeen(deviceId);

            var session = SessionManager.CreateSession(
                user.Id, user.Username, user.Role, deviceId, user.AccountState, user.DisplayName);

            AuditRepository.Log("LoginSuccess", username, deviceId,
                username, "Success");

            if (user.ForcePasswordReset)
            {
                return new LoginResult
                {
                    Code    = LoginResultCode.ForcePasswordReset,
                    Session = session,
                    Message = "Your password has been reset. Please choose a new password."
                };
            }

            return new LoginResult
            {
                Code    = LoginResultCode.Success,
                Session = session,
                Message = "Login successful."
            };
        }

        // ──────────────────────────────────────────────────
        // PASSWORD CHANGE
        // ──────────────────────────────────────────────────

        public static (bool Success, string Error) ChangePassword(
            long userId, string currentPassword, string newPassword)
        {
            if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 8)
                return (false, "New password must be at least 8 characters.");

            UserRecord? user = UserRepository.FindById(userId);
            if (user == null)
                return (false, "User not found.");

            if (!PasswordHasher.VerifyPassword(currentPassword, user.PasswordHash, user.PasswordSalt))
                return (false, "Current password is incorrect.");

            var (newHash, newSalt) = PasswordHasher.HashPassword(newPassword);
            bool ok = UserRepository.UpdatePassword(userId, newHash, newSalt, forceReset: false);

            AuditRepository.Log("PasswordChanged",
                user.Username,
                SessionManager.CurrentSession?.DeviceId,
                user.Username,
                ok ? "Success" : "Failed");

            return ok ? (true, "") : (false, "Password update failed.");
        }

        // ──────────────────────────────────────────────────
        // ADMIN: RESET ACCESS
        // ──────────────────────────────────────────────────

        /// <summary>
        /// Admin sets a new temporary password for a user and forces
        /// them to change it on next login. The admin does NOT see
        /// the new password after this method returns.
        /// Returns the temporary password to hand to the user.
        /// </summary>
        public static (bool Success, string Error, string TempPassword) AdminResetAccess(
            long adminUserId, long targetUserId)
        {
            AppSession? session = SessionManager.CurrentSession;
            if (session == null || session.UserId != adminUserId || !session.IsAdmin)
                return (false, "Unauthorized.", "");

            UserRecord? target = UserRepository.FindById(targetUserId);
            if (target == null)
                return (false, "User not found.", "");

            // Generate a random temporary password
            string tempPassword = GenerateTemporaryPassword();

            var (hash, salt) = PasswordHasher.HashPassword(tempPassword);
            bool ok = UserRepository.UpdatePassword(targetUserId, hash, salt, forceReset: true);

            AuditRepository.Log("AdminResetAccess",
                session.Username, session.DeviceId,
                target.Username, ok ? "Success" : "Failed");

            return ok
                ? (true, "", tempPassword)
                : (false, "Reset failed.", "");
        }

        private static string GenerateTemporaryPassword()
        {
            const string chars =
                "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$";
            var buf = new char[16];
            byte[] rnd = System.Security.Cryptography.RandomNumberGenerator.GetBytes(16);
            for (int i = 0; i < buf.Length; i++)
                buf[i] = chars[rnd[i] % chars.Length];
            return new string(buf);
        }

        // ──────────────────────────────────────────────────
        // HELPERS
        // ──────────────────────────────────────────────────

        private static LoginResult Fail(LoginResultCode code, string message) =>
            new() { Code = code, Message = message };
    }
}
