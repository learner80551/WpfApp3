using System;
using System.Collections.Generic;
using Microsoft.Data.Sqlite;

namespace WpfApp3.Database
{
    public class GroupRecord
    {
        public long Id { get; set; }
        public string GroupId { get; set; } = "";
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public string CreatedBy { get; set; } = "";
        public DateTime CreatedAt { get; set; }
        public bool IsActive { get; set; } = true;
        public List<string> MemberDeviceIds { get; set; } = new();
    }

    public class GroupMemberRecord
    {
        public string GroupId { get; set; } = "";
        public string DeviceId { get; set; } = "";
        public string Role { get; set; } = "Member";
        public DateTime JoinedAt { get; set; }
    }

    public static class GroupRepository
    {
        public static bool CreateGroup(string groupId, string name, string description, string createdBy)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
INSERT INTO Groups (GroupId, Name, Description, CreatedBy, CreatedAt, IsActive)
VALUES (@gid, @name, @desc, @cb, @ca, 1);";
                cmd.Parameters.AddWithValue("@gid", groupId);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@desc", description);
                cmd.Parameters.AddWithValue("@cb", createdBy);
                cmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("O"));
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool UpdateGroup(string groupId, string name, string description)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE Groups SET Name=@name, Description=@desc WHERE GroupId=@gid;";
                cmd.Parameters.AddWithValue("@gid", groupId);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@desc", description);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool DeleteGroup(string groupId)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE Groups SET IsActive=0 WHERE GroupId=@gid;";
                cmd.Parameters.AddWithValue("@gid", groupId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool AddMember(string groupId, string deviceId, string role = "Member")
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
INSERT OR REPLACE INTO GroupMembers (GroupId, DeviceId, Role, JoinedAt)
VALUES (@gid, @did, @role, @ja);";
                cmd.Parameters.AddWithValue("@gid", groupId);
                cmd.Parameters.AddWithValue("@did", deviceId);
                cmd.Parameters.AddWithValue("@role", role);
                cmd.Parameters.AddWithValue("@ja", DateTime.UtcNow.ToString("O"));
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool RemoveMember(string groupId, string deviceId)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "DELETE FROM GroupMembers WHERE GroupId=@gid AND DeviceId=@did;";
                cmd.Parameters.AddWithValue("@gid", groupId);
                cmd.Parameters.AddWithValue("@did", deviceId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static List<GroupRecord> GetGroups()
        {
            var list = new List<GroupRecord>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Id, GroupId, Name, Description, CreatedBy, CreatedAt, IsActive FROM Groups WHERE IsActive=1 ORDER BY Name;";
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new GroupRecord
                    {
                        Id = reader.GetInt64(0),
                        GroupId = reader.GetString(1),
                        Name = reader.GetString(2),
                        Description = reader.IsDBNull(3) ? "" : reader.GetString(3),
                        CreatedBy = reader.IsDBNull(4) ? "" : reader.GetString(4),
                        CreatedAt = DateTime.Parse(reader.GetString(5)),
                        IsActive = reader.GetInt32(6) == 1
                    });
                }
            }
            catch { }
            return list;
        }

        public static List<string> GetGroupMembers(string groupId)
        {
            var list = new List<string>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT DeviceId FROM GroupMembers WHERE GroupId=@gid;";
                cmd.Parameters.AddWithValue("@gid", groupId);
                using var reader = cmd.ExecuteReader();
                while (reader.Read()) list.Add(reader.GetString(0));
            }
            catch { }
            return list;
        }

        public static List<string> GetDeviceGroups(string deviceId)
        {
            var list = new List<string>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT GroupId FROM GroupMembers WHERE DeviceId=@did;";
                cmd.Parameters.AddWithValue("@did", deviceId);
                using var reader = cmd.ExecuteReader();
                while (reader.Read()) list.Add(reader.GetString(0));
            }
            catch { }
            return list;
        }
    }
}
