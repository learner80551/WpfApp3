using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Xunit;
using WpfApp3.Theme;

namespace WpfApp3.Tests
{
    public class ThemeManagerTests
    {
        [Fact]
        public void ThemePreference_Persistence_RoundTrips()
        {
            // Test persistence of light theme
            ThemeManager.SaveThemePreference(false);
            Assert.False(ThemeManager.LoadThemePreference());

            // Test persistence of dark theme
            ThemeManager.SaveThemePreference(true);
            Assert.True(ThemeManager.LoadThemePreference());
        }

        [Fact]
        public void ThemeManager_API_SwitchesStateAndFiresEvent()
        {
            bool? eventResult = null;
            Action<bool> handler = isDark => { eventResult = isDark; };
            ThemeManager.ThemeChanged += handler;

            try
            {
                ThemeManager.ApplyLightTheme();
                Assert.False(ThemeManager.IsDark);
                Assert.Equal(AppTheme.Light, ThemeManager.CurrentTheme);

                ThemeManager.ApplyDarkTheme();
                Assert.True(ThemeManager.IsDark);
                Assert.Equal(AppTheme.Dark, ThemeManager.CurrentTheme);

                ThemeManager.ToggleTheme();
                Assert.False(ThemeManager.IsDark);
                Assert.Equal(AppTheme.Light, ThemeManager.CurrentTheme);
            }
            finally
            {
                ThemeManager.ThemeChanged -= handler;
            }
        }

        [Fact]
        public void LightAndDarkThemeDictionaries_ContainMatchingKeys()
        {
            // Locate the project directory
            string baseDir = AppContext.BaseDirectory;
            string? projectDir = null;
            var current = new DirectoryInfo(baseDir);
            while (current != null)
            {
                if (File.Exists(Path.Combine(current.FullName, "WpfApp3.csproj")))
                {
                    projectDir = current.FullName;
                    break;
                }
                current = current.Parent;
            }

            Assert.NotNull(projectDir);

            string lightPath = Path.Combine(projectDir, "Theme", "LightTheme.xaml");
            string darkPath = Path.Combine(projectDir, "Theme", "DarkTheme.xaml");

            Assert.True(File.Exists(lightPath), $"LightTheme.xaml missing at {lightPath}");
            Assert.True(File.Exists(darkPath), $"DarkTheme.xaml missing at {darkPath}");

            XNamespace x = "http://schemas.microsoft.com/winfx/2006/xaml";

            var lightDoc = XDocument.Load(lightPath);
            var darkDoc = XDocument.Load(darkPath);

            var lightKeys = lightDoc.Descendants()
                .Select(e => e.Attribute(x + "Key")?.Value)
                .Where(v => !string.IsNullOrEmpty(v))
                .ToHashSet();

            var darkKeys = darkDoc.Descendants()
                .Select(e => e.Attribute(x + "Key")?.Value)
                .Where(v => !string.IsNullOrEmpty(v))
                .ToHashSet();

            Assert.NotEmpty(lightKeys);
            Assert.NotEmpty(darkKeys);

            // Verify essential keys
            string[] requiredKeys =
            {
                "AppBackgroundBrush", "WindowBackgroundBrush", "SurfaceBrush", "CardBackgroundBrush",
                "PrimaryBackgroundBrush", "SecondaryBackgroundBrush", "InputBackgroundBrush",
                "BorderBrush", "PrimaryTextBrush", "SecondaryTextBrush", "MutedTextBrush",
                "AccentBrush", "AccentHoverBrush", "AccentPressedBrush", "SuccessBrush",
                "WarningBrush", "ErrorBrush", "ButtonBackgroundBrush", "ButtonForegroundBrush",
                "ButtonHoverBrush", "ButtonPressedBrush", "SidebarBackgroundBrush", "HeaderBackgroundBrush",
                "ChatBackgroundBrush", "ChatMessageBackgroundBrush", "ReceivedMessageBackgroundBrush",
                "SentMessageBackgroundBrush", "ListBackgroundBrush", "ListItemBackgroundBrush",
                "AppBg", "SidebarBg", "PanelBg", "PanelBorder", "TextPrimary", "TextSecondary"
            };

            foreach (var key in requiredKeys)
            {
                Assert.True(lightKeys.Contains(key), $"LightTheme.xaml missing required key: {key}");
                Assert.True(darkKeys.Contains(key), $"DarkTheme.xaml missing required key: {key}");
            }

            // Verify parity
            var missingInDark = lightKeys.Except(darkKeys).ToList();
            var missingInLight = darkKeys.Except(lightKeys).ToList();

            Assert.Empty(missingInDark);
            Assert.Empty(missingInLight);
        }
    }
}
