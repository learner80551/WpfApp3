using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using Xunit;
using WpfApp3.Core.Devices;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Tests
{
    public class Migration4AndDeviceStateTests
    {
        private static void CreateBaseSchema(SqliteConnection connection)
        {
            using var cmd = connection.CreateCommand();
            cmd.CommandText = @"
CREATE TABLE IF NOT EXISTS Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL UNIQUE,
    Role TEXT NOT NULL DEFAULT 'User',
    PasswordHash TEXT NOT NULL,
    PasswordSalt TEXT NOT NULL,
    CreatedAt TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Devices (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    DeviceId TEXT NOT NULL UNIQUE,
    UserId INTEGER NOT NULL,
    DisplayName TEXT NOT NULL,
    CertificateFingerprint TEXT,
    IsAuthorized INTEGER NOT NULL DEFAULT 1,
    IsRevoked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    LastSeenAt TEXT,
    FOREIGN KEY (UserId) REFERENCES Users(Id)
);";
            cmd.ExecuteNonQuery();
        }

        [Fact]
        public void Migration4_ExecutesSuccessfully_OnFreshDatabase()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            // Establish base schema then run migrations
            CreateBaseSchema(connection);
            DatabaseMigrator.Migrate(connection);

            // Verify SchemaVersion reached version 4
            using (var cmd = connection.CreateCommand())
            {
                cmd.CommandText = "SELECT MAX(Version) FROM SchemaVersion;";
                int ver = Convert.ToInt32(cmd.ExecuteScalar());
                Assert.Equal(4, ver);
            }

            // Verify DeviceState and PublicKey columns exist in Devices
            var cols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var colCmd = connection.CreateCommand())
            {
                colCmd.CommandText = "PRAGMA table_info(Devices);";
                using var r = colCmd.ExecuteReader();
                while (r.Read()) cols.Add(r.GetString(1));
            }

            Assert.Contains("DeviceState", cols);
            Assert.Contains("PublicKey", cols);

            // Verify idx_devices_devicestate index exists
            using (var idxCmd = connection.CreateCommand())
            {
                idxCmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='idx_devices_devicestate';";
                long count = Convert.ToInt64(idxCmd.ExecuteScalar());
                Assert.Equal(1, count);
            }
        }

        [Fact]
        public void Migration4_CanRunAgainstDatabaseWithExistingMigration1To3Data()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            // 1. Simulate a database that has run Migrations 1, 2, and 3
            using (var initCmd = connection.CreateCommand())
            {
                initCmd.CommandText = @"
CREATE TABLE SchemaVersion (Version INTEGER PRIMARY KEY, AppliedAt TEXT);
INSERT INTO SchemaVersion VALUES (1, '2026-01-01T00:00:00Z');
INSERT INTO SchemaVersion VALUES (2, '2026-01-01T00:00:00Z');
INSERT INTO SchemaVersion VALUES (3, '2026-01-01T00:00:00Z');

CREATE TABLE Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL UNIQUE,
    Role TEXT NOT NULL DEFAULT 'User',
    PasswordHash TEXT NOT NULL,
    PasswordSalt TEXT NOT NULL,
    ForcePasswordReset INTEGER NOT NULL DEFAULT 0,
    IsActive INTEGER NOT NULL DEFAULT 1,
    CreatedAt TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL,
    LastLoginAt TEXT,
    AccountState TEXT NOT NULL DEFAULT 'ACTIVE',
    DisplayName TEXT,
    Email TEXT
);

CREATE TABLE Devices (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    DeviceId TEXT NOT NULL UNIQUE,
    UserId INTEGER NOT NULL,
    DisplayName TEXT NOT NULL,
    CertificateFingerprint TEXT,
    IsAuthorized INTEGER NOT NULL DEFAULT 1,
    IsRevoked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    LastSeenAt TEXT,
    Hostname TEXT,
    IpAddress TEXT,
    OperatingSystem TEXT,
    ClientVersion TEXT,
    Status TEXT NOT NULL DEFAULT 'UNKNOWN',
    TrustStatus TEXT NOT NULL DEFAULT 'UNKNOWN'
);

INSERT INTO Users (Id, Username, PasswordHash, PasswordSalt, CreatedAt, UpdatedAt)
VALUES (1, 'alice', 'hash', 'salt', '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z');

-- Legacy authorized device
INSERT INTO Devices (DeviceId, UserId, DisplayName, IsAuthorized, IsRevoked, CreatedAt)
VALUES ('DEV-AUTH', 1, 'Alice Auth PC', 1, 0, '2026-01-01T00:00:00Z');

-- Legacy unauthorized device
INSERT INTO Devices (DeviceId, UserId, DisplayName, IsAuthorized, IsRevoked, CreatedAt)
VALUES ('DEV-UNAUTH', 1, 'Alice Unauth PC', 0, 0, '2026-01-01T00:00:00Z');

-- Legacy revoked device
INSERT INTO Devices (DeviceId, UserId, DisplayName, IsAuthorized, IsRevoked, CreatedAt)
VALUES ('DEV-REVOKED', 1, 'Alice Revoked PC', 0, 1, '2026-01-01T00:00:00Z');
";
                initCmd.ExecuteNonQuery();
            }

            // 2. Run Migration (should apply Migration 4)
            DatabaseMigrator.Migrate(connection);

            // 3. Verify Version is now 4
            using (var verCmd = connection.CreateCommand())
            {
                verCmd.CommandText = "SELECT MAX(Version) FROM SchemaVersion;";
                Assert.Equal(4, Convert.ToInt32(verCmd.ExecuteScalar()));
            }

            // 4. Verify existing records were safely and correctly transitioned
            using (var queryCmd = connection.CreateCommand())
            {
                queryCmd.CommandText = "SELECT DeviceId, DeviceState, IsAuthorized, IsRevoked FROM Devices ORDER BY DeviceId;";
                using var reader = queryCmd.ExecuteReader();

                // DEV-AUTH
                Assert.True(reader.Read());
                Assert.Equal("DEV-AUTH", reader.GetString(0));
                Assert.Equal("AUTHORIZED", reader.GetString(1));
                Assert.Equal(1, reader.GetInt64(2));
                Assert.Equal(0, reader.GetInt64(3));

                // DEV-REVOKED
                Assert.True(reader.Read());
                Assert.Equal("DEV-REVOKED", reader.GetString(0));
                Assert.Equal("REVOKED", reader.GetString(1));
                Assert.Equal(1, reader.GetInt64(3));

                // DEV-UNAUTH
                Assert.True(reader.Read());
                Assert.Equal("DEV-UNAUTH", reader.GetString(0));
                Assert.Equal("PENDING_APPROVAL", reader.GetString(1));
                Assert.Equal(0, reader.GetInt64(2));
            }
        }

        [Fact]
        public void Migration4_DoesNotCreateDuplicateSchemaObjects()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            using (var initCmd = connection.CreateCommand())
            {
                initCmd.CommandText = @"
CREATE TABLE Users (Id INTEGER PRIMARY KEY, Username TEXT);
CREATE TABLE Devices (Id INTEGER PRIMARY KEY, DeviceId TEXT, UserId INTEGER, DisplayName TEXT, IsAuthorized INT, IsRevoked INT, CreatedAt TEXT);";
                initCmd.ExecuteNonQuery();
            }

            // Run migration 3 times
            DatabaseMigrator.Migrate(connection);
            DatabaseMigrator.Migrate(connection);
            DatabaseMigrator.Migrate(connection);

            // Exactly 1 row for Version 4 in SchemaVersion
            using (var verCmd = connection.CreateCommand())
            {
                verCmd.CommandText = "SELECT COUNT(*) FROM SchemaVersion WHERE Version = 4;";
                Assert.Equal(1, Convert.ToInt64(verCmd.ExecuteScalar()));
            }

            // Exactly 1 index named idx_devices_devicestate
            using (var idxCmd = connection.CreateCommand())
            {
                idxCmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='idx_devices_devicestate';";
                Assert.Equal(1, Convert.ToInt64(idxCmd.ExecuteScalar()));
            }

            // Column counts in Devices: PublicKey and DeviceState must each appear exactly once
            var cols = new List<string>();
            using (var colCmd = connection.CreateCommand())
            {
                colCmd.CommandText = "PRAGMA table_info(Devices);";
                using var r = colCmd.ExecuteReader();
                while (r.Read()) cols.Add(r.GetString(1));
            }

            Assert.Equal(1, cols.Count(c => string.Equals(c, "DeviceState", StringComparison.OrdinalIgnoreCase)));
            Assert.Equal(1, cols.Count(c => string.Equals(c, "PublicKey", StringComparison.OrdinalIgnoreCase)));
        }

        [Fact]
        public void NewlyCreatedDevices_AreNotAutomaticallyAuthorized()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            // Initialize schema with Migration 4 defaults
            using (var schemaCmd = connection.CreateCommand())
            {
                schemaCmd.CommandText = @"
CREATE TABLE Users (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Username TEXT NOT NULL
);

CREATE TABLE Devices (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    DeviceId TEXT NOT NULL UNIQUE,
    UserId INTEGER NOT NULL,
    DisplayName TEXT NOT NULL,
    CertificateFingerprint TEXT,
    PublicKey TEXT,
    DeviceState TEXT NOT NULL DEFAULT 'PENDING_APPROVAL',
    IsAuthorized INTEGER NOT NULL DEFAULT 0,
    IsRevoked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL,
    LastSeenAt TEXT
);";
                schemaCmd.ExecuteNonQuery();
            }

            DatabaseMigrator.Migrate(connection);

            // Insert a device relying on column defaults
            using (var insCmd = connection.CreateCommand())
            {
                insCmd.CommandText = @"
INSERT INTO Devices (DeviceId, UserId, DisplayName, CreatedAt)
VALUES ('DEV-NEW-01', 1, 'New Untrusted Device', '2026-09-21T00:00:00Z');";
                insCmd.ExecuteNonQuery();
            }

            // Verify defaults enforce zero-trust: NOT authorized, state is PENDING_APPROVAL
            using (var checkCmd = connection.CreateCommand())
            {
                checkCmd.CommandText = "SELECT IsAuthorized, DeviceState FROM Devices WHERE DeviceId='DEV-NEW-01';";
                using var r = checkCmd.ExecuteReader();
                Assert.True(r.Read());
                Assert.Equal(0, r.GetInt64(0)); // IsAuthorized must default to 0
                Assert.Equal("PENDING_APPROVAL", r.GetString(1)); // DeviceState must default to PENDING_APPROVAL
            }
        }

        [Fact]
        public void DeviceState_SupportsAllSixRequiredStates()
        {
            // Requirement 1: Exactly DISCOVERED, UNTRUSTED, PENDING_APPROVAL, AUTHORIZED, SUSPENDED, REVOKED
            var expectedNames = new[]
            {
                "DISCOVERED",
                "UNTRUSTED",
                "PENDING_APPROVAL",
                "AUTHORIZED",
                "SUSPENDED",
                "REVOKED"
            };

            var enumNames = Enum.GetNames(typeof(DeviceState));
            Assert.Equal(6, enumNames.Length);
            Assert.All(expectedNames, name => Assert.Contains(name, enumNames));

            // Verify each state can be mapped to DeviceInfo and DeviceRecord
            foreach (var name in expectedNames)
            {
                var state = Enum.Parse<DeviceState>(name);
                var info = new DeviceInfo { State = state };
                Assert.Equal(state, info.State);

                var record = new DeviceRecord { DeviceState = name };
                Assert.Equal(state, record.State);
            }
        }

        [Fact]
        public void ExistingExplicitlyAuthorizedDevices_RetainAuthorizedStatusDuringMigration()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();

            // Set up pre-migration database with authorized device
            using (var cmd = connection.CreateCommand())
            {
                cmd.CommandText = @"
CREATE TABLE Users (Id INTEGER PRIMARY KEY, Username TEXT);
CREATE TABLE Devices (
    Id INTEGER PRIMARY KEY,
    DeviceId TEXT,
    UserId INTEGER,
    DisplayName TEXT,
    IsAuthorized INTEGER NOT NULL DEFAULT 1,
    IsRevoked INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT
);
INSERT INTO Devices (Id, DeviceId, UserId, DisplayName, IsAuthorized, IsRevoked, CreatedAt)
VALUES (1, 'NAV-EXP-AUTH', 1, 'Authorized PC', 1, 0, '2026-09-01T00:00:00Z');";
                cmd.ExecuteNonQuery();
            }

            // Run migration
            DatabaseMigrator.Migrate(connection);

            // Verify device retained authorized status
            using (var checkCmd = connection.CreateCommand())
            {
                checkCmd.CommandText = "SELECT IsAuthorized, DeviceState FROM Devices WHERE DeviceId='NAV-EXP-AUTH';";
                using var reader = checkCmd.ExecuteReader();
                Assert.True(reader.Read());
                Assert.Equal(1, reader.GetInt64(0));
                Assert.Equal("AUTHORIZED", reader.GetString(1));
            }
        }

        [Fact]
        public void PublicKeyPersistence_Works()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();
            CreateBaseSchema(connection);
            DatabaseMigrator.Migrate(connection);

            // Generate test RSA public key in SubjectPublicKeyInfo format
            using var rsa = RSA.Create(2048);
            string fakePublicKeyBase64 = Convert.ToBase64String(rsa.ExportSubjectPublicKeyInfo());

            using (var insCmd = connection.CreateCommand())
            {
                insCmd.CommandText = @"
INSERT INTO Users (Id, Username, PasswordHash, PasswordSalt, CreatedAt, UpdatedAt)
VALUES (1, 'pkuser', 'h', 's', '2026-09-21T00:00:00Z', '2026-09-21T00:00:00Z');

INSERT INTO Devices (DeviceId, UserId, DisplayName, PublicKey, DeviceState, IsAuthorized, IsRevoked, CreatedAt)
VALUES ('DEV-PK-01', 1, 'PK Device', @pk, 'AUTHORIZED', 1, 0, '2026-09-21T00:00:00Z');";
                insCmd.Parameters.AddWithValue("@pk", fakePublicKeyBase64);
                insCmd.ExecuteNonQuery();
            }

            using (var queryCmd = connection.CreateCommand())
            {
                queryCmd.CommandText = "SELECT PublicKey FROM Devices WHERE DeviceId='DEV-PK-01';";
                string? storedPk = queryCmd.ExecuteScalar() as string;
                Assert.NotNull(storedPk);
                Assert.Equal(fakePublicKeyBase64, storedPk);

                // Verify the stored key can be imported back as an RSA public key
                byte[] spkiBytes = Convert.FromBase64String(storedPk);
                using var rsaImported = RSA.Create();
                rsaImported.ImportSubjectPublicKeyInfo(spkiBytes, out _);
                Assert.NotNull(rsaImported);
            }
        }

        [Fact]
        public void PrivateKeys_AreNeverWrittenToDatabase()
        {
            using var connection = new SqliteConnection("Data Source=:memory:;");
            connection.Open();
            CreateBaseSchema(connection);
            DatabaseMigrator.Migrate(connection);

            // 1. Inspect all columns across all tables in SQLite
            using var cmd = connection.CreateCommand();
            cmd.CommandText = @"
SELECT m.name as table_name, p.name as column_name
FROM sqlite_master m
JOIN pragma_table_info(m.name) p
WHERE m.type = 'table';";

            using var reader = cmd.ExecuteReader();
            var forbiddenTerms = new[] { "private", "privkey", "privatekey", "rsa_d", "pfx" };
            while (reader.Read())
            {
                string tableName = reader.GetString(0);
                string colName = reader.GetString(1);

                foreach (var term in forbiddenTerms)
                {
                    Assert.DoesNotContain(term, colName, StringComparison.OrdinalIgnoreCase);
                }
            }

            // 2. Verify DeviceIdentity.GetPublicKeyString returns SubjectPublicKeyInfo (public key only)
            string? pk = DeviceIdentity.GetPublicKeyString();
            if (pk != null)
            {
                byte[] keyBytes = Convert.FromBase64String(pk);
                using var rsa = RSA.Create();
                rsa.ImportSubjectPublicKeyInfo(keyBytes, out _);

                // Exporting private key from public-only RSA must throw CryptographicException
                Assert.ThrowsAny<CryptographicException>(() => rsa.ExportRSAPrivateKey());
            }
        }
    }
}
