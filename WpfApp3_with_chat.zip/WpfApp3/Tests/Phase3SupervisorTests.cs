using System;
using System.IO;
using System.Security.Cryptography;
using Xunit;
using WpfApp3.Admin;
using WpfApp3.Authentication;
using WpfApp3.Core.Security;
using WpfApp3.Database;

namespace WpfApp3.Tests
{
    public sealed class Phase3SupervisorTests : IDisposable
    {
        private readonly string _dbPath;

        public Phase3SupervisorTests()
        {
            _dbPath = Path.Combine(Path.GetTempPath(), $"lanshare_phase3_{Guid.NewGuid():N}.db");
            AppDatabase.SetCustomDatabasePath(_dbPath);
            AppDatabase.Initialize();
        }

        public void Dispose()
        {
            AppDatabase.ResetCustomDatabasePath();
            try { if (File.Exists(_dbPath)) File.Delete(_dbPath); } catch { }
        }

        private static (long UserId, string DeviceId, string PublicKey) CreateActiveUser(string suffix)
        {
            var (hash, salt) = PasswordHasher.HashPassword("SupervisorPassword123!");
            long userId = UserRepository.CreateUser($"user-{suffix}", "User", hash, salt,
                AccountStates.Active, $"User {suffix}");
            using RSA rsa = RSA.Create(2048);
            string publicKey = Convert.ToBase64String(rsa.ExportSubjectPublicKeyInfo());
            string deviceId = $"NAV-{suffix}";
            UserRepository.CreateDevice(deviceId, userId, "LANShare Peer",
                $"{suffix}{new string('A', 64 - suffix.Length)}", publicKey,
                DeviceStates.Authorized, isAuthorized: true);
            return (userId, deviceId, publicKey);
        }

        private static AppSession CreateAdminSession(out string deviceId)
        {
            var result = AuthenticationService.CreateAdmin(
                "admin", "AdminPassword123!", "Admin");
            Assert.True(result.Success, result.Error);
            deviceId = result.DeviceId;
            UserRecord admin = UserRepository.FindAdmin()!;
            return SessionManager.CreateSession(admin.Id, admin.Username, admin.Role,
                deviceId, admin.AccountState, admin.DisplayName);
        }

        [Fact]
        public void PermanentAdmin_RemainsExactlyOne_AndUserCannotSelfPromote()
        {
            AppSession admin = CreateAdminSession(out _);
            var user = CreateActiveUser("SELF01");
            var userSession = new AppSession
            {
                UserId = user.UserId,
                Username = UserRepository.FindById(user.UserId)!.Username,
                Role = "User",
                AccountState = AccountStates.Active,
                DeviceId = user.DeviceId
            };

            AdminResult result = AdminService.GrantSupervisor(
                userSession, user.UserId, user.DeviceId, new[] { Permissions.UserView });

            Assert.False(result.IsSuccess);
            Assert.Equal("Admin", UserRepository.FindAdmin()!.Role);
            Assert.Single(UserRepository.GetAllUsers(), u => u.Role == "Admin");
            Assert.Equal("User", UserRepository.FindById(user.UserId)!.Role);
            _ = admin;
        }

        [Fact]
        public void Admin_GrantsGranularPermissions_AndBackendEnforcesThem()
        {
            AppSession admin = CreateAdminSession(out _);
            var user = CreateActiveUser("SUP02");
            AdminResult grant = AdminService.GrantSupervisor(
                admin, user.UserId, user.DeviceId,
                new[] { Permissions.UserView, Permissions.AuditView });

            Assert.True(grant.IsSuccess, grant.Message);
            Assert.Equal("Supervisor", UserRepository.FindById(user.UserId)!.Role);
            Assert.Contains(Permissions.UserView, UserRepository.GetSupervisorPermissions(user.UserId));
            Assert.DoesNotContain(Permissions.DeviceRevoke, UserRepository.GetSupervisorPermissions(user.UserId));

            AppSession supervisor = new()
            {
                UserId = user.UserId,
                Username = UserRepository.FindById(user.UserId)!.Username,
                Role = "Supervisor",
                AccountState = AccountStates.Active,
                DeviceId = user.DeviceId
            };
            Assert.True(AuthorizationService.Authorize(supervisor, Permissions.UserView));
            Assert.False(AuthorizationService.Authorize(supervisor, Permissions.DeviceRevoke));

            Assert.True(AdminService.RevokeSupervisor(admin, user.UserId, user.DeviceId).IsSuccess);
            Assert.False(AuthorizationService.Authorize(supervisor, Permissions.UserView));
        }

        [Fact]
        public void ActingAdmin_RequiresEligibleSupervisor_AndExpiresDeterministically()
        {
            AppSession admin = CreateAdminSession(out _);
            var user = CreateActiveUser("ACT03");
            Assert.True(AdminService.GrantSupervisor(
                admin, user.UserId, user.DeviceId, new[] { Permissions.UserView }).IsSuccess);

            AdminResult lease = AdminService.GrantActingAdminLease(admin, user.UserId, 1);
            Assert.True(lease.IsSuccess, lease.Message);
            AppSession supervisor = new()
            {
                UserId = user.UserId,
                Username = UserRepository.FindById(user.UserId)!.Username,
                Role = "Supervisor",
                AccountState = AccountStates.Active,
                DeviceId = user.DeviceId
            };
            Assert.True(AuthorizationService.IsActingAdmin(supervisor));
            Assert.True(AuthorizationService.Authorize(supervisor, Permissions.DeviceRevoke));
            Assert.False(AuthorizationService.Authorize(supervisor, "ADMIN_ROOT"));

            AuthorityStateRecord state = UserRepository.GetAuthorityState()!;
            UserRepository.SetAuthorityState(state.CurrentEpoch, state.AdminUserId,
                state.AdminDeviceId, user.UserId, DateTime.UtcNow.AddSeconds(-1), state.EpochSignature);
            Assert.False(AuthorizationService.IsActingAdmin(supervisor));
            Assert.False(AuthorizationService.Authorize(supervisor, Permissions.DeviceRevoke));
        }

        [Fact]
        public void RevokedSupervisorDevice_LosesAllAdministrativeAccess()
        {
            AppSession admin = CreateAdminSession(out _);
            var user = CreateActiveUser("REV04");
            Assert.True(AdminService.GrantSupervisor(
                admin, user.UserId, user.DeviceId, new[] { Permissions.UserView }).IsSuccess);
            AppSession supervisor = new()
            {
                UserId = user.UserId,
                Username = UserRepository.FindById(user.UserId)!.Username,
                Role = "Supervisor",
                AccountState = AccountStates.Active,
                DeviceId = user.DeviceId
            };
            Assert.True(AuthorizationService.Authorize(supervisor, Permissions.UserView));
            UserRepository.SetDeviceRevoked(user.DeviceId, true);
            Assert.False(AuthorizationService.Authorize(supervisor, Permissions.UserView));
        }
    }
}
