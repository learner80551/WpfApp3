using Xunit;
using WpfApp3.Core.Configuration;

namespace WpfApp3.Tests
{
    public class AppConfigTests
    {
        [Fact]
        public void AppConfig_HasExpectedPorts()
        {
            Assert.Equal(42000, AppConfig.ControlPort);
            Assert.Equal(42001, AppConfig.SecureTransferPort);
            Assert.Equal(42101, AppConfig.DiscoveryPort);
        }

        [Fact]
        public void AppConfig_HasExpectedTimeouts()
        {
            Assert.True(AppConfig.DiscoveryIntervalMs > 0);
            Assert.True(AppConfig.PeerTimeoutSeconds >= 10);
            Assert.True(AppConfig.PeerRemoveSeconds >= AppConfig.PeerTimeoutSeconds);
        }

        [Fact]
        public void AppConfig_AppDataFolder_IsConfigured()
        {
            Assert.False(string.IsNullOrWhiteSpace(AppConfig.AppDataFolder));
            Assert.Contains("LANShare", AppConfig.AppDataFolder);
        }
    }
}
