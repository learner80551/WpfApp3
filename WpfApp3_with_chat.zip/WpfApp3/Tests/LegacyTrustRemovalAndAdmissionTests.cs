using System;
using System.IO;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;
using WpfApp3;
using WpfApp3.Admin;
using WpfApp3.Authentication;
using WpfApp3.Chat;
using WpfApp3.Core.Devices;
using WpfApp3.Core.Security;
using WpfApp3.Database;
using WpfApp3.Identity;

namespace WpfApp3.Tests
{
    public class LegacyTrustRemovalAndAdmissionTests : IDisposable
    {
        private readonly string _testDbFile;

        public LegacyTrustRemovalAndAdmissionTests()
        {
            _testDbFile = Path.Combine(Path.GetTempPath(), $"lanshare_test_{Guid.NewGuid():N}.db");
            AppDatabase.SetCustomDatabasePath(_testDbFile);
            AppDatabase.Initialize();
        }

        public void Dispose()
        {
            AppDatabase.ResetCustomDatabasePath();
            try
            {
                if (File.Exists(_testDbFile))
                    File.Delete(_testDbFile);
            }
            catch { }
        }

        private static (string fingerprint, string publicKey) CreateTestCertAndKey()
        {
            using var rsa = RSA.Create(2048);
            var req = new CertificateRequest("CN=Test", rsa, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            using var cert = req.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(1));
            string fp = cert.GetCertHashString(HashAlgorithmName.SHA256);
            string pk = Convert.ToBase64String(rsa.ExportSubjectPublicKeyInfo());
            return (fp, pk);
        }

        private static long EnsureTestUser()
        {
            var existing = UserRepository.FindByUsername("test-user");
            if (existing != null) return existing.Id;

            var (hash, salt) = PasswordHasher.HashPassword("TestPassword123!");
            return UserRepository.CreateUser("test-user", "User", hash, salt);
        }

        // =========================================================
        // PART 1 — IDENTITY TESTS (1 to 5)
        // =========================================================

        [Fact]
        public void Test1_Hostname_CannotAuthorizeDevice()
        {
            // Hostname is not an authoritative identifier; lookup by hostname must not authorize
            string hostname = "CORP-WORKSTATION-99";
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: hostname);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test2_IpAddress_CannotAuthorizeDevice()
        {
            // IP address cannot grant device authorization
            string ip = "192.168.1.100";
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: ip);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test3_MacAddress_CannotAuthorizeDevice()
        {
            // MAC address cannot grant device authorization
            string mac = "00:1A:2B:3C:4D:5E";
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: mac);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test4_MachineName_CannotAuthorizeDevice()
        {
            // Windows machine name cannot grant device authorization
            string machineName = Environment.MachineName;
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: machineName);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test5_CertificateFingerprintAlone_CannotAuthorizeDevice()
        {
            // Unknown or unapproved certificate fingerprint cannot authorize
            string randomFp = "11223344556677889900AABBCCDDEEFF11223344556677889900AABBCCDDEEFF";
            bool isAuth = UserRepository.IsDeviceAuthorized(fingerprint: randomFp);
            Assert.False(isAuth);
        }

        // =========================================================
        // PART 2 — LEGACY PAIRING OVERRIDE PREVENTION (6 to 10)
        // =========================================================

        [Fact]
        public void Test6_LegacyPairing_CannotOverride_PendingApproval()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-PENDING01";

            // Register device as PENDING_APPROVAL in authoritative DB
            UserRepository.CreateDevice(devId, uid, "PendingPC", fp, pk, DeviceStates.PendingApproval, isAuthorized: false);

            // Legacy pairing store claims it is paired
            string legacyName = $"PendingPC-{Guid.NewGuid():N}";
            var legacyPairing = new PairingManager();
            Assert.True(legacyPairing.AddOrUpdate(legacyName, fp));
            Assert.True(legacyPairing.IsPaired(legacyName, fp));

            // Authoritative zero-trust check must strictly deny
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp, publicKey: pk);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test7_LegacyPairing_CannotOverride_Suspended()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-SUSPEND01";

            // Register device as SUSPENDED
            UserRepository.CreateDevice(devId, uid, "SuspendedPC", fp, pk, DeviceStates.Suspended, isAuthorized: false);

            // Legacy pairing store claims it is paired
            string legacyName = $"SuspendedPC-{Guid.NewGuid():N}";
            var legacyPairing = new PairingManager();
            Assert.True(legacyPairing.AddOrUpdate(legacyName, fp));
            Assert.True(legacyPairing.IsPaired(legacyName, fp));

            // Authoritative zero-trust check must strictly deny
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp, publicKey: pk);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test8_LegacyPairing_CannotOverride_Revoked()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-REVOKED01";

            // Register device as REVOKED
            UserRepository.CreateDevice(devId, uid, "RevokedPC", fp, pk, DeviceStates.Revoked, isAuthorized: false);
            UserRepository.SetDeviceRevoked(devId, true);

            // Legacy pairing store claims it is paired
            string legacyName = $"RevokedPC-{Guid.NewGuid():N}";
            var legacyPairing = new PairingManager();
            Assert.True(legacyPairing.AddOrUpdate(legacyName, fp));
            Assert.True(legacyPairing.IsPaired(legacyName, fp));

            // Authoritative zero-trust check must strictly deny
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp, publicKey: pk);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test9_LegacyTrustedDevices_CannotOverride_DeniedState()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-UNTRUST01";

            // Device is UNTRUSTED in database
            UserRepository.CreateDevice(devId, uid, "UntrustedPC", fp, pk, DeviceStates.Untrusted, isAuthorized: false);

            // Even if TrustedDevices has an entry, zero-trust DB authority denies
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp);
            Assert.False(isAuth);
        }

        [Fact]
        public void Test10_Authorization_DoesNotDependOn_PairingManager()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-AUTHONLY01";

            // Authorize device in SQLite database
            UserRepository.CreateDevice(devId, uid, "AuthorizedPC", fp, pk, DeviceStates.Authorized, isAuthorized: true);

            // Do NOT add to PairingManager
            var legacyPairing = new PairingManager();
            legacyPairing.Remove("AuthorizedPC", fp);

            // Device MUST be authorized despite absence from legacy pairing file
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp, publicKey: pk);
            Assert.True(isAuth);
        }

        // =========================================================
        // PART 3 — AUTHORIZED DEVICE & BOOTSTRAP (11 to 13)
        // =========================================================

        [Fact]
        public void Test11_ProperlyAuthorizedDevice_Succeeds()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-VALID001";

            UserRepository.CreateDevice(devId, uid, "ValidPC", fp, pk, DeviceStates.Authorized, isAuthorized: true);

            var dev = UserRepository.FindDevice(devId);
            Assert.NotNull(dev);
            Assert.Equal(DeviceStates.Authorized, dev.DeviceState);
            Assert.True(dev.IsAuthorized);
            Assert.False(dev.IsRevoked);

            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp, publicKey: pk);
            Assert.True(isAuth);
        }

        [Fact]
        public void Test12_ExistingAdminBootstrap_ContinuesToWork()
        {
            // First run bootstrap creates Admin with AUTHORIZED device
            bool isFirstRun = AuthenticationService.IsFirstRun();
            Assert.True(isFirstRun);

            var (success, err, devId) = AuthenticationService.CreateAdmin("admin", "AdminPassword123!", "Admin-Workstation");
            Assert.True(success);
            Assert.NotEmpty(devId);

            var dev = UserRepository.FindDevice(devId);
            Assert.NotNull(dev);
            Assert.Equal(DeviceStates.Authorized, dev.DeviceState);
            Assert.True(dev.IsAuthorized);
            Assert.False(dev.IsRevoked);

            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: devId);
            Assert.True(isAuth);
        }

        [Fact]
        public void Test13_AuthorizedDevice_CanAccessProtectedCommunicationPath()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-PROT01";

            UserRepository.CreateDevice(devId, uid, "ProtectedNode", fp, pk, DeviceStates.Authorized, isAuthorized: true);

            // Both AuthorizationService and UserRepository confirm access
            Assert.True(AuthorizationService.IsDeviceAuthorized(deviceId: devId, fingerprint: fp));
        }

        // =========================================================
        // PART 4 — SECURITY REGRESSION (14 to 19)
        // =========================================================

        [Fact]
        public void Test14_NoPrivateKeyPersistedInDatabase_OrExposed()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-KEYTEST01";

            UserRepository.CreateDevice(devId, uid, "KeyTestPC", fp, pk, DeviceStates.Authorized, isAuthorized: true);

            var dev = UserRepository.FindDevice(devId);
            Assert.NotNull(dev);
            Assert.NotNull(dev.PublicKey);
            Assert.DoesNotContain("PRIVATE KEY", dev.PublicKey);

            // Verify DeviceIdentity public key does not expose private key
            string? localPk = DeviceIdentity.GetPublicKeyString();
            if (localPk != null)
            {
                Assert.DoesNotContain("PRIVATE KEY", localPk);
            }
        }

        [Fact]
        public void Test15_DeviceState_IsAuthoritativeLifecycle()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-LIFECYCLE01";

            // Lifecycle transitions: PENDING_APPROVAL -> AUTHORIZED -> SUSPENDED -> REVOKED
            UserRepository.CreateDevice(devId, uid, "LifecyclePC", fp, pk, DeviceStates.PendingApproval, isAuthorized: false);
            Assert.False(UserRepository.IsDeviceAuthorized(devId));

            UserRepository.SetDeviceState(devId, DeviceStates.Authorized);
            Assert.True(UserRepository.IsDeviceAuthorized(devId));

            UserRepository.SetDeviceState(devId, DeviceStates.Suspended);
            Assert.False(UserRepository.IsDeviceAuthorized(devId));

            UserRepository.SetDeviceState(devId, DeviceStates.Revoked);
            Assert.False(UserRepository.IsDeviceAuthorized(devId));
        }

        [Fact]
        public void Test16_P2PChat_DirectAuthorization_EnforcesDeviceState()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-CHAT01";

            // Chat service does not authorize pending or revoked devices
            UserRepository.CreateDevice(devId, uid, "ChatPeer", fp, pk, DeviceStates.PendingApproval, isAuthorized: false);
            Assert.False(UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp));

            UserRepository.SetDeviceState(devId, DeviceStates.Authorized);
            Assert.True(UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp));
        }

        [Fact]
        public void Test17_P2PFileTransfer_DirectAuthorization_EnforcesDeviceState()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-FILE01";

            // Unregistered device cannot transfer
            Assert.False(UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp));

            // Suspended device cannot transfer
            UserRepository.CreateDevice(devId, uid, "FilePeer", fp, pk, DeviceStates.Suspended, isAuthorized: false);
            Assert.False(UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp));

            // Authorized device can transfer
            UserRepository.SetDeviceState(devId, DeviceStates.Authorized);
            Assert.True(UserRepository.IsDeviceAuthorized(deviceId: devId, fingerprint: fp));
        }

        [Fact]
        public void Test18_Sha256FileIntegrity_RemainsIntact()
        {
            byte[] testBytes = System.Text.Encoding.UTF8.GetBytes("LANShare P2P Secure Payload");
            byte[] hash = SHA256.HashData(testBytes);
            string hex = Convert.ToHexString(hash);

            Assert.Equal(64, hex.Length);
            Assert.True(Guid.TryParse(Guid.NewGuid().ToString(), out _));
        }

        [Fact]
        public void Test19_PathTraversalSanitization_RemainsIntact()
        {
            string safe = PathTraversalSanitizer.SanitizeRelativePath("document.pdf");
            Assert.Equal("document.pdf", safe);

            string sanitizedTraversal = PathTraversalSanitizer.SanitizeRelativePath("../../../etc/passwd");
            Assert.DoesNotContain("..", sanitizedTraversal);

            string tempDir = Path.GetTempPath();
            Assert.True(PathTraversalSanitizer.IsSafeDestination(tempDir, "safe_file.txt", out _));
        }

        // =========================================================
        // PART 5 — DISCOVERY SANITIZATION TESTS (20 to 26)
        // =========================================================

        [Fact]
        public void Test20_DiscoveryPacket_DoesNotContain_Hostname()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "LANShare Peer",
                IpAddress = "192.168.1.10",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                Hostname = "", // Sanitized
                OperatingSystem = "LANShare Peer",
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            Assert.DoesNotContain(Environment.MachineName, json);
            Assert.Contains("\"Hostname\":\"\"", json);
        }

        [Fact]
        public void Test21_DiscoveryPacket_DoesNotContain_OSInformation()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "LANShare Peer",
                IpAddress = "192.168.1.10",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                Hostname = "",
                OperatingSystem = "LANShare Peer", // Sanitized generic application peer
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            Assert.DoesNotContain("Windows 10", json);
            Assert.DoesNotContain("Windows 11", json);
            Assert.Contains("\"OperatingSystem\":\"LANShare Peer\"", json);
        }

        [Fact]
        public void Test22_DiscoveryPacket_DoesNotContain_Username()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "LANShare Peer",
                IpAddress = "192.168.1.10",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                OperatingSystem = "LANShare Peer",
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            Assert.DoesNotContain(Environment.UserName, json);
        }

        [Fact]
        public void Test23_DiscoveryPacket_DoesNotContain_FilesystemPaths()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "LANShare Peer",
                IpAddress = "192.168.1.10",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                OperatingSystem = "LANShare Peer",
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            Assert.DoesNotContain("C:\\", json);
            Assert.DoesNotContain("Users\\", json);
        }

        [Fact]
        public void Test24_DiscoveryPacket_DoesNotContain_SecretsOrPrivateKeys()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "LANShare Peer",
                IpAddress = "192.168.1.10",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                OperatingSystem = "LANShare Peer",
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            string json = JsonSerializer.Serialize(msg);
            Assert.DoesNotContain("password", json, StringComparison.OrdinalIgnoreCase);
            Assert.DoesNotContain("PRIVATE KEY", json, StringComparison.OrdinalIgnoreCase);
            Assert.DoesNotContain("secret", json, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void Test25_Discovery_ContainsMinimumRequiredIdentifiers()
        {
            var msg = new DiscoveryMessage
            {
                DeviceName = "LANShare Peer",
                IpAddress = "192.168.1.10",
                CertificateFingerprint = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
                TransferPort = 42001,
                DeviceId = "NAV-TEST01",
                ClientVersion = "1.0",
                Status = "ONLINE"
            };

            Assert.Equal("LANSHARE_DISCOVERY", msg.Type);
            Assert.Equal("NAV-TEST01", msg.DeviceId);
            Assert.Equal("192.168.1.10", msg.IpAddress);
            Assert.Equal(42001, msg.TransferPort);
            Assert.Equal(64, msg.CertificateFingerprint.Length);
        }

        [Fact]
        public void Test26_Rediscovery_DoesNotAutomaticallyAuthorize_RevokedOrPendingDevice()
        {
            var (fp, pk) = CreateTestCertAndKey();
            long uid = EnsureTestUser();
            string devId = "NAV-REDISCOVER01";

            // Device is REVOKED
            UserRepository.CreateDevice(devId, uid, "RevokedPeer", fp, pk, DeviceStates.Revoked, isAuthorized: false);
            UserRepository.SetDeviceRevoked(devId, true);

            // Peer discovery observed packet
            var peer = new PeerInfo
            {
                DeviceId = devId,
                CertificateFingerprint = fp,
                IpAddress = "192.168.1.55",
                Name = "LANShare Peer",
                IsOnline = true
            };

            // Rediscovery alone MUST NOT authorize the device
            bool isAuth = UserRepository.IsDeviceAuthorized(deviceId: peer.DeviceId, fingerprint: peer.CertificateFingerprint);
            Assert.False(isAuth);

            // Device in DB must remain REVOKED
            var dev = UserRepository.FindDevice(devId);
            Assert.NotNull(dev);
            Assert.Equal(DeviceStates.Revoked, dev.DeviceState);
            Assert.False(dev.IsAuthorized);
            Assert.True(dev.IsRevoked);
        }

        [Fact]
        public void Test27_FakeAdminAuthorizationEvent_IsRejected()
        {
            var (success, error, _) = AuthenticationService.CreateAdmin(
                "root", "AdminPassword123!", "Root");
            Assert.True(success, error);

            UserRecord admin = UserRepository.FindAdmin()!;
            AuthorityStateRecord authority = UserRepository.GetAuthorityState()!;
            using var fakeKey = RSA.Create(2048);
            var request = new CertificateRequest(
                "CN=FakeAdmin", fakeKey, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            using X509Certificate2 fakeCert = request.CreateSelfSigned(
                DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(1));

            string payload = JsonSerializer.Serialize(new CryptographicAuthority.RegistrationEventPayload
            {
                TargetUserId = 999,
                TargetDeviceId = "NAV-FAKE-TARGET",
                TargetPublicKey = "fake-public-key"
            });
            const int sequence = 2;
            string hash = CryptographicAuthority.ComputeSha256(
                $"USER_APPROVED:{authority.CurrentEpoch}:{sequence}:{admin.Id}:{payload}");
            string signature = Convert.ToBase64String(fakeKey.SignData(
                System.Text.Encoding.UTF8.GetBytes(hash),
                HashAlgorithmName.SHA256,
                RSASignaturePadding.Pkcs1));

            var evt = new AuthorizationEventRecord
            {
                EventId = Guid.NewGuid().ToString(),
                EventType = "USER_APPROVED",
                UserId = 999,
                DeviceId = "NAV-FAKE-TARGET",
                AuthorityUserId = admin.Id,
                AuthorityRole = "Admin",
                Epoch = authority.CurrentEpoch,
                SequenceNumber = sequence,
                PayloadJson = payload,
                PayloadHash = hash,
                Signature = signature
            };

            var result = CryptographicAuthority.ProcessAuthorizationEvent(evt, fakeCert);
            Assert.False(result.Success);
            Assert.Contains("administrator public key", result.Reason, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void Test28_AdminApprovalRequiresExactRegistrationIdentity()
        {
            var (success, error, adminDeviceId) = AuthenticationService.CreateAdmin(
                "root", "AdminPassword123!", "Root");
            Assert.True(success, error);
            UserRecord admin = UserRepository.FindAdmin()!;
            var session = SessionManager.CreateSession(
                admin.Id, admin.Username, admin.Role, adminDeviceId, admin.AccountState, admin.DisplayName);

            var (fp, pk) = CreateTestCertAndKey();
            var (hash, salt) = PasswordHasher.HashPassword("PendingPassword123!");
            long userId = UserRepository.CreateUser("pending", "User", hash, salt, AccountStates.Pending);
            string deviceId = "NAV-PENDING-EXACT";
            UserRepository.CreateDevice(deviceId, userId, "LANShare Peer", fp, pk,
                DeviceStates.PendingApproval, isAuthorized: false);

            var result = AdminService.ApproveRegistration(session, userId, deviceId, pk + "tampered");
            Assert.False(result.IsSuccess);
            Assert.Equal(DeviceStates.PendingApproval, UserRepository.FindDevice(deviceId)!.DeviceState);
            Assert.Equal(AccountStates.Pending, UserRepository.FindById(userId)!.AccountState);

            result = AdminService.ApproveRegistration(session, userId, deviceId, pk);
            Assert.True(result.IsSuccess, result.Message);
            Assert.True(UserRepository.IsDeviceAuthorized(deviceId, fp, pk));
            Assert.Equal(AccountStates.Active, UserRepository.FindById(userId)!.AccountState);
        }
    }
}
