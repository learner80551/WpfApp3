using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using WpfApp3.Authentication;
using WpfApp3.Core.Groups;
using WpfApp3.Database;

namespace WpfApp3.Core.Messaging
{
    /// <summary>
    /// Sends and receives direct (1-to-1) and group chat messages using the
    /// existing authenticated TLS transfer channel (port 42001), reusing the
    /// same connect / mTLS / fingerprint-pin pattern as BroadcastChatService.
    ///
    /// Persistence, dedup and in-memory conversation history are delegated to
    /// MessageManager (per-message) and GroupManager (membership resolution),
    /// so this class is transport-only.
    /// </summary>
    public class MessagingTransportService
    {
        private readonly MessageManager _messageManager;
        private readonly GroupManager _groupManager;
        private readonly int _transferPort;

        public MessagingTransportService(
            MessageManager messageManager,
            GroupManager groupManager,
            int transferPort = 42001)
        {
            _messageManager = messageManager;
            _groupManager   = groupManager;
            _transferPort   = transferPort;
        }

        // ──────────────────────────────────────────────────
        // SEND
        // ──────────────────────────────────────────────────

        /// <summary>
        /// Sends a direct message to a single peer. The message is saved
        /// locally regardless of whether the peer is currently reachable.
        /// </summary>
        public async Task<AdvancedChatMessage> SendDirectMessageAsync(
            PeerInfo recipient,
            string text,
            CancellationToken cancellationToken = default)
        {
            if (SessionManager.CurrentSession == null)
                throw new InvalidOperationException("No active session.");

            AdvancedChatMessage msg =
                _messageManager.CreateDirectMessage(recipient.DeviceId, text);

            await DeliverAsync(msg, new[] { recipient }, cancellationToken);
            return msg;
        }

        /// <summary>
        /// Sends a group message to every currently-online member of the
        /// group (other than the sender). Offline members simply pick the
        /// message up from local history the next time they sync/reconnect
        /// with an online member — there is no store-and-forward relay yet.
        /// </summary>
        public async Task<AdvancedChatMessage> SendGroupMessageAsync(
            string groupId,
            string text,
            IEnumerable<PeerInfo> onlinePeers,
            CancellationToken cancellationToken = default)
        {
            AppSession? session = SessionManager.CurrentSession;
            if (session == null)
                throw new InvalidOperationException("No active session.");

            GroupRecord? group = _groupManager.GetGroup(groupId);
            if (group == null)
                throw new InvalidOperationException("Unknown group.");

            AdvancedChatMessage msg =
                _messageManager.CreateGroupMessage(groupId, text);

            var memberIds = new HashSet<string>(
                group.MemberDeviceIds, StringComparer.OrdinalIgnoreCase);

            IEnumerable<PeerInfo> targets = onlinePeers.Where(p =>
                memberIds.Contains(p.DeviceId) &&
                !string.Equals(p.DeviceId, session.DeviceId, StringComparison.OrdinalIgnoreCase));

            await DeliverAsync(msg, targets, cancellationToken);
            return msg;
        }

        private async Task DeliverAsync(
            AdvancedChatMessage msg,
            IEnumerable<PeerInfo> targets,
            CancellationToken cancellationToken)
        {
            X509Certificate2 localCert;
            try { localCert = DeviceCertificate.GetOrCreateCertificate(); }
            catch { return; }

            var envelope = new AdvancedMessagePacket { Message = msg };
            string packetJson = JsonSerializer.Serialize(envelope);

            foreach (PeerInfo peer in targets)
            {
                if (!peer.IsOnline) continue;
                if (string.IsNullOrWhiteSpace(peer.CertificateFingerprint)) continue;

                // Zero-Trust check: only actually-authorized devices receive
                // messages, mirroring BroadcastChatService's admission rule.
                if (!UserRepository.IsDeviceAuthorized(
                        deviceId: peer.DeviceId,
                        fingerprint: peer.CertificateFingerprint))
                {
                    continue;
                }

                string peerIp         = peer.IpAddress;
                string expectedFp     = peer.CertificateFingerprint;
                X509Certificate2 cert = localCert;

                _ = Task.Run(async () =>
                {
                    try
                    {
                        await SendPacketAsync(
                            peerIp, expectedFp, cert,
                            packetJson, cancellationToken);
                    }
                    catch { /* Offline / unreachable peers are silently skipped */ }
                }, CancellationToken.None);
            }

            await Task.CompletedTask;
        }

        private async Task SendPacketAsync(
            string peerIp, string expectedFingerprint,
            X509Certificate2 localCert,
            string packetJson,
            CancellationToken cancellationToken)
        {
            using TcpClient client = new();
            client.NoDelay = true;

            using CancellationTokenSource cts =
                CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(5));

            await client.ConnectAsync(peerIp, _transferPort, cts.Token);

            using SslStream ssl = new(
                client.GetStream(), false,
                (_, cert2, _, _) =>
                {
                    if (cert2 == null) return false;
                    try
                    {
                        using X509Certificate2 x =
                            new X509Certificate2(cert2.Export(X509ContentType.Cert));
                        string fp = x.GetCertHashString(
                            System.Security.Cryptography.HashAlgorithmName.SHA256);
                        return string.Equals(fp, expectedFingerprint,
                            StringComparison.OrdinalIgnoreCase);
                    }
                    catch { return false; }
                });

            await ssl.AuthenticateAsClientAsync(
                new SslClientAuthenticationOptions
                {
                    TargetHost          = "LANShare",
                    EnabledSslProtocols = SslProtocols.Tls13 | SslProtocols.Tls12,
                    ClientCertificates  = new X509CertificateCollection { localCert }
                }, cts.Token);

            using System.IO.StreamWriter writer = new(ssl, Encoding.UTF8, 4096, true);
            writer.AutoFlush = false;

            await writer.WriteAsync(packetJson.AsMemory(), cts.Token);
            await writer.WriteAsync("\n".AsMemory(), cts.Token);
            await writer.FlushAsync(cts.Token);
        }

        // ──────────────────────────────────────────────────
        // RECEIVE  (called by TransferServer.AdvancedMessageReceived)
        // ──────────────────────────────────────────────────

        public void HandleIncomingPacket(AdvancedChatMessage msg, string clientFingerprint)
        {
            if (string.IsNullOrWhiteSpace(msg.MessageId))      return;
            if (string.IsNullOrWhiteSpace(msg.SenderDeviceId)) return;

            // Bind the claimed sender to the authenticated TLS client
            // certificate: the certificate must belong to a known, authorized
            // device. A bare SenderDeviceId is a spoofable claim otherwise.
            DeviceRecord? certDevice =
                UserRepository.FindDeviceByFingerprint(clientFingerprint);

            if (certDevice == null ||
                !UserRepository.IsDeviceAuthorized(deviceId: certDevice.DeviceId))
            {
                return;
            }

            DeviceRecord? claimedDevice =
                UserRepository.FindDevice(msg.SenderDeviceId);

            if (claimedDevice != null)
            {
                if (!FingerprintsMatch(claimedDevice.CertificateFingerprint, clientFingerprint) ||
                    !UserRepository.IsDeviceAuthorized(deviceId: claimedDevice.DeviceId))
                {
                    return;
                }
            }

            msg.SenderDeviceId = claimedDevice?.DeviceId ?? certDevice.DeviceId;
            if (!string.IsNullOrWhiteSpace(certDevice.Username))
                msg.SenderUsername = certDevice.Username;

            string? localDeviceId = SessionManager.CurrentSession?.DeviceId;

            if (msg.IsGroupMessage)
            {
                // Only accept the message if this device is actually a member
                // of the target group — discovery/authorization does not by
                // itself grant group membership.
                GroupRecord? group = _groupManager.GetGroup(msg.GroupId!);
                if (group == null) return;

                if (localDeviceId == null ||
                    !group.MemberDeviceIds.Contains(localDeviceId, StringComparer.OrdinalIgnoreCase))
                {
                    return;
                }
            }
            else if (msg.IsDirectMessage)
            {
                // A direct message must be addressed to this device.
                if (localDeviceId == null ||
                    !string.Equals(msg.ReceiverDeviceId, localDeviceId, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            _messageManager.HandleIncomingMessage(msg);
        }

        private static bool FingerprintsMatch(string? a, string? b)
        {
            static string Norm(string? s) =>
                (s ?? "")
                    .Replace(":", "")
                    .Replace("-", "")
                    .Replace(" ", "")
                    .Trim()
                    .ToUpperInvariant();

            return !string.IsNullOrWhiteSpace(a) &&
                   !string.IsNullOrWhiteSpace(b) &&
                   string.Equals(Norm(a), Norm(b), StringComparison.Ordinal);
        }
    }
}
