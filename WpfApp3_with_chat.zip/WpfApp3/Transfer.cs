using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Security;

namespace WpfApp3
{
    public class TransferServer
    {
        private const int ControlPort = 42000;
        private const int SecureTransferPort = 42001;

        private const int MaxLineLength = 64 * 1024;
        private const int MaxRequestSize = 64 * 1024;

        private static readonly TimeSpan ClientAuthenticationTimeout =
            TimeSpan.FromSeconds(30);

        private static readonly TimeSpan RequestReadTimeout =
            TimeSpan.FromSeconds(30);

        private static readonly TimeSpan RejectionWriteTimeout =
            TimeSpan.FromSeconds(10);

        private readonly TcpListener controlListener;
        private readonly TcpListener secureTransferListener;

        private readonly X509Certificate2 serverCertificate;
        [Obsolete("Legacy pairing store retained for backward compatibility; not used for authorization decisions.")]
        private readonly PairingManager pairingManager;

        private readonly ConcurrentDictionary<string, DateTime> processedRequests =
            new ConcurrentDictionary<string, DateTime>();

        private readonly object serverLock = new object();

        private CancellationTokenSource? serverCts;
        private bool started;

        public event Action<SslStream, TcpClient, TransferRequest>? TransferRequested;

        public event Action<SslStream, TcpClient, PairingRequest>? PairRequested;

        /// <summary>
        /// Raised when a CHAT_MESSAGE packet arrives on an authenticated TLS connection.
        /// </summary>
        public event Action<Chat.ChatMessagePacket, string>? ChatMessageReceived;

        /// <summary>
        /// Raised when a direct (1-to-1) or group chat message (ADV_MESSAGE) arrives
        /// on an authenticated TLS connection.
        /// </summary>
        public event Action<Core.Messaging.AdvancedChatMessage, string>? AdvancedMessageReceived;

        public TransferServer()
        {
            serverCertificate = DeviceCertificate.GetOrCreateCertificate();
            pairingManager = new PairingManager();

            controlListener = new TcpListener(
                IPAddress.Any,
                ControlPort);

            secureTransferListener = new TcpListener(
                IPAddress.Any,
                SecureTransferPort);
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            lock (serverLock)
            {
                if (started)
                {
                    return Task.CompletedTask;
                }

                serverCts = CancellationTokenSource.CreateLinkedTokenSource(
                    cancellationToken);

                try
                {
                    controlListener.Start();
                    secureTransferListener.Start();
                }
                catch
                {
                    // Port bind failed (e.g. another instance is running):
                    // roll back so we don't report "started" with dead
                    // listeners, and surface the error to the caller.
                    try { controlListener.Stop(); } catch { }
                    try { secureTransferListener.Stop(); } catch { }

                    serverCts.Dispose();
                    serverCts = null;

                    throw;
                }

                started = true;
            }

            _ = Task.Run(
                () => ControlListenerLoopAsync(serverCts!.Token),
                CancellationToken.None);

            _ = Task.Run(
                () => SecureTransferListenerLoopAsync(serverCts!.Token),
                CancellationToken.None);

            return Task.CompletedTask;
        }

        public void Stop()
        {
            lock (serverLock)
            {
                if (!started)
                {
                    return;
                }

                started = false;

                try
                {
                    serverCts?.Cancel();
                }
                catch
                {
                }

                try
                {
                    controlListener.Stop();
                }
                catch
                {
                }

                try
                {
                    secureTransferListener.Stop();
                }
                catch
                {
                }

                try
                {
                    serverCts?.Dispose();
                }
                catch
                {
                }

                serverCts = null;
            }
        }

        private async Task ControlListenerLoopAsync(
            CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                TcpClient? client = null;

                try
                {
                    client = await controlListener.AcceptTcpClientAsync(
                        cancellationToken);

                    _ = Task.Run(
                        () => HandleControlClientAsync(
                            client,
                            cancellationToken),
                        CancellationToken.None);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch
                {
                    try
                    {
                        client?.Close();
                    }
                    catch
                    {
                    }

                    if (!cancellationToken.IsCancellationRequested)
                    {
                        await Task.Delay(
                            250,
                            CancellationToken.None);
                    }
                }
            }
        }

        private async Task SecureTransferListenerLoopAsync(
            CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                TcpClient? client = null;

                try
                {
                    client = await secureTransferListener.AcceptTcpClientAsync(
                        cancellationToken);

                    _ = Task.Run(
                        () => HandleSecureTransferClientAsync(
                            client,
                            cancellationToken),
                        CancellationToken.None);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch
                {
                    try
                    {
                        client?.Close();
                    }
                    catch
                    {
                    }

                    if (!cancellationToken.IsCancellationRequested)
                    {
                        await Task.Delay(
                            250,
                            CancellationToken.None);
                    }
                }
            }
        }

        private async Task HandleControlClientAsync(
            TcpClient client,
            CancellationToken cancellationToken)
        {
            NetworkStream? networkStream = null;
            SslStream? sslStream = null;

            bool connectionTransferred = false;

            try
            {
                networkStream = client.GetStream();

                sslStream = new SslStream(
                    networkStream,
                    leaveInnerStreamOpen: false,
                    UserCertificateValidationCallback);

                using CancellationTokenSource authCts =
                    CancellationTokenSource.CreateLinkedTokenSource(
                        cancellationToken);

                authCts.CancelAfter(ClientAuthenticationTimeout);

                await sslStream.AuthenticateAsServerAsync(
                    new SslServerAuthenticationOptions
                    {
                        ServerCertificate = serverCertificate,
                        EnabledSslProtocols =
                            SslProtocols.Tls12 |
                            SslProtocols.Tls13,
                        ClientCertificateRequired = false,
                        CertificateRevocationCheckMode =
                            X509RevocationMode.NoCheck
                    },
                    authCts.Token);

                string? line = await ReadLineWithTimeoutAsync(
                    sslStream,
                    cancellationToken,
                    RequestReadTimeout);

                if (string.IsNullOrWhiteSpace(line))
                {
                    return;
                }

                if (line.Length > MaxLineLength)
                {
                    return;
                }

                PairingRequest? pairingRequest =
                    Deserialize<PairingRequest>(line);

                if (pairingRequest == null)
                {
                    return;
                }

                if (!ValidatePairingRequest(pairingRequest))
                {
                    return;
                }

                Action<SslStream, TcpClient, PairingRequest>? handler =
                    PairRequested;

                if (handler == null)
                {
                    return;
                }

                connectionTransferred = true;

                handler(
                    sslStream,
                    client,
                    pairingRequest);

                sslStream = null;
                networkStream = null;
            }
            catch
            {
                // Connection is closed by finally.
            }
            finally
            {
                if (!connectionTransferred)
                {
                    try
                    {
                        sslStream?.Dispose();
                    }
                    catch
                    {
                    }

                    try
                    {
                        networkStream?.Dispose();
                    }
                    catch
                    {
                    }

                    try
                    {
                        client.Close();
                    }
                    catch
                    {
                    }
                }
            }
        }

        private async Task HandleSecureTransferClientAsync(
            TcpClient client,
            CancellationToken cancellationToken)
        {
            NetworkStream? networkStream = null;
            SslStream? sslStream = null;

            bool connectionTransferred = false;

            try
            {
                networkStream = client.GetStream();

                sslStream = new SslStream(
                    networkStream,
                    leaveInnerStreamOpen: false,
                    UserCertificateValidationCallback);

                using CancellationTokenSource authCts =
                    CancellationTokenSource.CreateLinkedTokenSource(
                        cancellationToken);

                authCts.CancelAfter(ClientAuthenticationTimeout);

                await sslStream.AuthenticateAsServerAsync(
                    new SslServerAuthenticationOptions
                    {
                        ServerCertificate = serverCertificate,
                        EnabledSslProtocols =
                            SslProtocols.Tls12 |
                            SslProtocols.Tls13,
                        ClientCertificateRequired = true,
                        CertificateRevocationCheckMode =
                            X509RevocationMode.NoCheck
                    },
                    authCts.Token);

                X509Certificate2? clientCertificate =
                    sslStream.RemoteCertificate == null
                        ? null
                        : new X509Certificate2(
                            sslStream.RemoteCertificate.Export(
                                X509ContentType.Cert));

                if (clientCertificate == null)
                {
                    await SendRejectionAsync(
                        sslStream,
                        "Client certificate required.",
                        cancellationToken);

                    return;
                }

                string clientFingerprint =
                    GetCertificateFingerprint(clientCertificate);

                string? clientPublicKey = null;
                try
                {
                    using RSA? rsa = clientCertificate.GetRSAPublicKey();
                    if (rsa != null)
                    {
                        byte[] spki = rsa.ExportSubjectPublicKeyInfo();
                        clientPublicKey = Convert.ToBase64String(spki);
                    }
                }
                catch { }

                // Authoritative Zero-Trust Admission Check:
                // Peer must have DeviceState == AUTHORIZED in SQLite device registry.
                // Legacy paired-devices.json or hostnames cannot grant authorization.
                bool isAuthorized = Database.UserRepository.IsDeviceAuthorized(
                    fingerprint: clientFingerprint,
                    publicKey: clientPublicKey);

                if (!isAuthorized)
                {
                    Database.AuditRepository.Log(
                        "SecurityAlert",
                        "System",
                        clientFingerprint,
                        "UnauthorizedConnectionAttempt",
                        "Rejected: Connecting device is not authorized.");

                    await SendRejectionAsync(
                        sslStream,
                        "Device is not authorized.",
                        cancellationToken);

                    return;
                }

                string? line = await ReadLineWithTimeoutAsync(
                    sslStream,
                    cancellationToken,
                    RequestReadTimeout);

                if (string.IsNullOrWhiteSpace(line))
                {
                    return;
                }

                if (line.Length > MaxRequestSize)
                {
                    await SendRejectionAsync(
                        sslStream,
                        "Transfer request is too large.",
                        cancellationToken);

                    return;
                }

                // Peek at the JSON to determine message type
                JsonDocument? peekedDoc = null;
                string? messageType = null;
                try
                {
                    peekedDoc = JsonDocument.Parse(line);
                    if (peekedDoc.RootElement.TryGetProperty("Type", out var typeProp))
                        messageType = typeProp.GetString();
                }
                catch { }

                // Route CHAT_MESSAGE without going through the transfer pipeline
                if (string.Equals(messageType, "CHAT_MESSAGE",
                    StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        Chat.ChatMessagePacket? chatPacket =
                            JsonSerializer.Deserialize<Chat.ChatMessagePacket>(line);
                        if (chatPacket != null)
                            ChatMessageReceived?.Invoke(chatPacket, clientFingerprint);
                    }
                    catch { }
                    return;
                }

                // Route direct/group messages (ADV_MESSAGE) without going through the
                // transfer pipeline.
                if (string.Equals(messageType, "ADV_MESSAGE",
                    StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        Core.Messaging.AdvancedMessagePacket? envelope =
                            JsonSerializer.Deserialize<Core.Messaging.AdvancedMessagePacket>(line);
                        if (envelope?.Message != null)
                            AdvancedMessageReceived?.Invoke(envelope.Message, clientFingerprint);
                    }
                    catch { }
                    return;
                }

                // Route unified protocol sync messages (Audit, Metadata, AuthEvents, Heartbeat)
                if (peekedDoc != null &&
                    peekedDoc.RootElement.TryGetProperty("MessageType", out var protoTypeProp) &&
                    !string.IsNullOrWhiteSpace(protoTypeProp.GetString()))
                {
                    if (Core.Network.PeerSyncService.HandleIncomingSyncMessage(
                        line, clientFingerprint, clientCertificate))
                    {
                        return;
                    }
                }

                TransferRequest? request =
                    Deserialize<TransferRequest>(line);

                if (request == null)
                {
                    await SendRejectionAsync(
                        sslStream,
                        "Invalid transfer request.",
                        cancellationToken);

                    return;
                }

                if (!ValidateTransferRequest(request))
                {
                    await SendRejectionAsync(
                        sslStream,
                        "Invalid transfer request.",
                        cancellationToken);

                    return;
                }
                // The connection is already cryptographically authenticated and authorized.
                // Request sender name (hostname) is never used as an authoritative trust decision.

                if (!TryRegisterRequest(request.RequestId))
                {
                    await SendRejectionAsync(
                        sslStream,
                        "Duplicate transfer request.",
                        cancellationToken);

                    return;
                }

                Action<SslStream, TcpClient, TransferRequest>? handler =
                    TransferRequested;

                if (handler == null)
                {
                    await SendRejectionAsync(
                        sslStream,
                        "Transfer service unavailable.",
                        cancellationToken);

                    return;
                }

                connectionTransferred = true;

                handler(
                    sslStream,
                    client,
                    request);

                sslStream = null;
                networkStream = null;
            }
            catch
            {
                // Connection is closed by finally.
            }
            finally
            {
                if (!connectionTransferred)
                {
                    try
                    {
                        sslStream?.Dispose();
                    }
                    catch
                    {
                    }

                    try
                    {
                        networkStream?.Dispose();
                    }
                    catch
                    {
                    }

                    try
                    {
                        client.Close();
                    }
                    catch
                    {
                    }
                }
            }
        }

        private bool ValidatePairingRequest(
            PairingRequest request)
        {
            if (request == null)
            {
                return false;
            }

            if (!string.Equals(
                    request.Type,
                    "PAIRING_REQUEST",
                    StringComparison.Ordinal))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(request.DeviceName))
            {
                return false;
            }

            if (request.DeviceName.Length > 100)
            {
                return false;
            }

            if (request.DeviceId != null &&
                request.DeviceId.Length > 100)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(
                    request.CertificateBase64))
            {
                return false;
            }

            if (request.CertificateBase64.Length > 100_000)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(request.RequestId))
            {
                return false;
            }

            if (request.RequestId.Length > 100)
            {
                return false;
            }

            return true;
        }

        private bool ValidateTransferRequest(
            TransferRequest request)
        {
            if (request == null)
            {
                return false;
            }

            if (!string.Equals(
                    request.Type,
                    "TRANSFER_REQUEST",
                    StringComparison.Ordinal))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(request.RequestId))
            {
                return false;
            }

            if (request.RequestId.Length > 100)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(request.FileName))
            {
                return false;
            }

            if (request.FileName.Length > 255)
            {
                return false;
            }

            if (Path.GetFileName(request.FileName) != request.FileName)
            {
                return false;
            }

            if (request.FileName.Contains(
                    Path.DirectorySeparatorChar) ||
                request.FileName.Contains(
                    Path.AltDirectorySeparatorChar))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(request.SenderName))
            {
                return false;
            }

            if (request.SenderName.Length > 100)
            {
                return false;
            }

            if (request.FileSize < 0)
            {
                return false;
            }

            const long MaxFileSize =
                100L * 1024L * 1024L * 1024L;

            if (request.FileSize > MaxFileSize)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(request.Sha256))
            {
                return false;
            }

            if (request.Sha256.Length != 64)
            {
                return false;
            }

            foreach (char c in request.Sha256)
            {
                if (!Uri.IsHexDigit(c))
                {
                    return false;
                }
            }

            return true;
        }

        private bool TryRegisterRequest(
            string requestId)
        {
            DateTime now = DateTime.UtcNow;

            foreach (var item in processedRequests)
            {
                if ((now - item.Value) >
                    TimeSpan.FromMinutes(30))
                {
                    processedRequests.TryRemove(
                        item.Key,
                        out _);
                }
            }

            return processedRequests.TryAdd(
                requestId,
                now);
        }

        private static async Task SendRejectionAsync(
            SslStream sslStream,
            string message,
            CancellationToken cancellationToken)
        {
            try
            {
                var response = new TransferResponse
                {
                    Type = "TRANSFER_RESPONSE",
                    RequestId = "",
                    Accepted = false
                };

                string json =
                    JsonSerializer.Serialize(response);

                using CancellationTokenSource timeoutCts =
                    CancellationTokenSource.CreateLinkedTokenSource(
                        cancellationToken);

                timeoutCts.CancelAfter(
                    RejectionWriteTimeout);

                await WriteLineAsync(
                    sslStream,
                    json,
                    timeoutCts.Token);
            }
            catch
            {
            }
        }

        private static async Task<string?> ReadLineWithTimeoutAsync(
            Stream stream,
            CancellationToken cancellationToken,
            TimeSpan timeout)
        {
            using CancellationTokenSource timeoutCts =
                CancellationTokenSource.CreateLinkedTokenSource(
                    cancellationToken);

            timeoutCts.CancelAfter(timeout);

            try
            {
                var builder = new StringBuilder();

                byte[] buffer = new byte[1];

                while (builder.Length <= MaxLineLength)
                {
                    int read = await stream.ReadAsync(
                        buffer.AsMemory(0, 1),
                        timeoutCts.Token);

                    if (read == 0)
                    {
                        break;
                    }

                    char c = (char)buffer[0];

                    if (c == '\n')
                    {
                        return builder.ToString().TrimEnd('\r');
                    }

                    builder.Append(c);
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        private static async Task WriteLineAsync(
            Stream stream,
            string text,
            CancellationToken cancellationToken)
        {
            byte[] data =
                Encoding.UTF8.GetBytes(text + "\n");

            await stream.WriteAsync(
                data.AsMemory(0, data.Length),
                cancellationToken);

            await stream.FlushAsync(
                cancellationToken);
        }

        private static T? Deserialize<T>(
            string json)
            where T : class
        {
            try
            {
                return JsonSerializer.Deserialize<T>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
            }
            catch
            {
                return null;
            }
        }

        private static bool UserCertificateValidationCallback(
            object sender,
            X509Certificate? certificate,
            X509Chain? chain,
            SslPolicyErrors sslPolicyErrors)
        {
            /*
             * Certificate pinning is performed after TLS authentication
             * using the actual certificate fingerprint.
             *
             * We do not rely on the normal Windows CA trust chain because
             * LANShare uses per-device self-signed certificates.
             */

            return certificate != null;
        }

        private static string GetCertificateFingerprint(
            X509Certificate2 certificate)
        {
            byte[] hash = SHA256.HashData(
                certificate.RawData);

            return Convert.ToHexString(hash);
        }
    }

    public class PairingRequest
    {
        public string Type { get; set; } =
            "PAIRING_REQUEST";

        public string RequestId { get; set; } =
            Guid.NewGuid().ToString();

        public string DeviceName { get; set; } = "";

        /// <summary>
        /// The sender's stable device id (as advertised during discovery).
        /// Optional for backward compatibility — older peers omit it.
        /// </summary>
        public string DeviceId { get; set; } = "";

        public string CertificateBase64 { get; set; } = "";
    }

    public class PairingChallenge
    {
        public string Type { get; set; } =
            "PAIRING_CHALLENGE";

        public string RequestId { get; set; } = "";

        public string ChallengeBase64 { get; set; } = "";
    }

    public class PairingProof
    {
        public string Type { get; set; } =
            "PAIRING_PROOF";

        public string RequestId { get; set; } = "";

        public string SignatureBase64 { get; set; } = "";
    }

    public class PairingResponse
    {
        public string Type { get; set; } =
            "PAIRING_RESPONSE";

        public string RequestId { get; set; } = "";

        public bool Accepted { get; set; }

        public string CertificateFingerprint { get; set; } = "";

        public string Message { get; set; } = "";
    }
}