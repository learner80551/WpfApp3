using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using WpfApp3.Database;

namespace WpfApp3.Core.Messaging
{
    public class MessageManager
    {
        private readonly ConcurrentDictionary<string, bool> _seenMessageIds = new();
        private readonly string _localDeviceId;
        private readonly string _localUsername;

        public event Action<AdvancedChatMessage>? MessageReceived;
        public event Action<ChatDeliveryAck>? DeliveryAckReceived;

        public MessageManager(string localDeviceId, string localUsername)
        {
            _localDeviceId = localDeviceId;
            _localUsername = localUsername;
        }

        public AdvancedChatMessage CreateDirectMessage(string receiverDeviceId, string text, string? replyToId = null)
        {
            var msg = new AdvancedChatMessage
            {
                MessageId = Guid.NewGuid().ToString(),
                SenderDeviceId = _localDeviceId,
                SenderUsername = _localUsername,
                ReceiverDeviceId = receiverDeviceId,
                Text = text,
                Timestamp = DateTime.UtcNow,
                Status = MessageDeliveryStatus.SENT,
                Type = MessageType.TEXT,
                ReplyToMessageId = replyToId
            };

            MessageRepository.Save(msg);
            _seenMessageIds.TryAdd(msg.MessageId, true);
            return msg;
        }

        public AdvancedChatMessage CreateGroupMessage(string groupId, string text, string? replyToId = null)
        {
            var msg = new AdvancedChatMessage
            {
                MessageId = Guid.NewGuid().ToString(),
                SenderDeviceId = _localDeviceId,
                SenderUsername = _localUsername,
                GroupId = groupId,
                Text = text,
                Timestamp = DateTime.UtcNow,
                Status = MessageDeliveryStatus.SENT,
                Type = MessageType.TEXT,
                ReplyToMessageId = replyToId
            };

            MessageRepository.Save(msg);
            _seenMessageIds.TryAdd(msg.MessageId, true);
            return msg;
        }

        public AdvancedChatMessage CreateBroadcastMessage(string text)
        {
            var msg = new AdvancedChatMessage
            {
                MessageId = Guid.NewGuid().ToString(),
                SenderDeviceId = _localDeviceId,
                SenderUsername = _localUsername,
                Text = text,
                Timestamp = DateTime.UtcNow,
                Status = MessageDeliveryStatus.SENT,
                Type = MessageType.TEXT
            };

            MessageRepository.Save(msg);
            _seenMessageIds.TryAdd(msg.MessageId, true);
            return msg;
        }

        public bool HandleIncomingMessage(AdvancedChatMessage msg)
        {
            if (string.IsNullOrWhiteSpace(msg.MessageId)) return false;
            if (!_seenMessageIds.TryAdd(msg.MessageId, true)) return false;

            msg.Status = MessageDeliveryStatus.DELIVERED;
            MessageRepository.Save(msg);

            MessageReceived?.Invoke(msg);
            return true;
        }

        public void HandleDeliveryAck(ChatDeliveryAck ack)
        {
            MessageRepository.UpdateStatus(ack.MessageId, ack.Status);
            DeliveryAckReceived?.Invoke(ack);
        }

        public List<AdvancedChatMessage> GetDirectConversation(string peerDeviceId, int limit = 100)
        {
            return MessageRepository.LoadDirectConversation(_localDeviceId, peerDeviceId, limit);
        }

        public List<AdvancedChatMessage> GetGroupConversation(string groupId, int limit = 100)
        {
            return MessageRepository.LoadGroupMessages(groupId, limit);
        }

        public List<AdvancedChatMessage> GetBroadcastMessages(int limit = 100)
        {
            return MessageRepository.LoadBroadcastMessages(limit);
        }

        public List<AdvancedChatMessage> Search(string query)
        {
            return MessageRepository.Search(query);
        }

        public bool DeleteLocalMessage(string messageId)
        {
            return MessageRepository.DeleteMessage(messageId);
        }
    }
}
