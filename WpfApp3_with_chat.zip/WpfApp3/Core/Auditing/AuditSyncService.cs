using System;
using System.Collections.Generic;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using WpfApp3.Database;

namespace WpfApp3.Core.Auditing
{
    public class AuditSyncQueueItem
    {
        public long Id { get; set; }
        public string EventId { get; set; } = "";
        public string PayloadJson { get; set; } = "";
        public string? TargetAdminDeviceId { get; set; }
        public string Status { get; set; } = "Pending";
        public int Attempts { get; set; }
        public DateTime? LastAttemptAt { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public static class AuditSyncService
    {
        public static void LogAndEnqueue(AuditEvent ev, string? adminDeviceId = null)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();

                // 1. Insert into AuditLogs table
                cmd.CommandText = @"
INSERT INTO AuditLogs (Timestamp, ActorUsername, ActorDeviceId, Action, Target, Result)
VALUES (@ts, @au, @ad, @ac, @tg, @re);";
                cmd.Parameters.AddWithValue("@ts", ev.Timestamp.ToString("O"));
                cmd.Parameters.AddWithValue("@au", ev.Actor);
                cmd.Parameters.AddWithValue("@ad", ev.SourceDeviceId);
                cmd.Parameters.AddWithValue("@ac", ev.EventType);
                cmd.Parameters.AddWithValue("@tg", (object?)ev.TargetDeviceId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@re", $"{ev.Severity}: {ev.Description}");
                cmd.ExecuteNonQuery();

                // 2. If target admin device is specified, enqueue for sync
                if (!string.IsNullOrWhiteSpace(adminDeviceId) &&
                    !string.Equals(adminDeviceId, ev.SourceDeviceId, StringComparison.OrdinalIgnoreCase))
                {
                    using var qCmd = conn.CreateCommand();
                    qCmd.CommandText = @"
INSERT OR IGNORE INTO AuditSyncQueue (EventId, PayloadJson, TargetAdminDeviceId, Status, Attempts, CreatedAt)
VALUES (@eid, @pl, @adm, 'Pending', 0, @ca);";
                    qCmd.Parameters.AddWithValue("@eid", ev.EventId);
                    qCmd.Parameters.AddWithValue("@pl", JsonSerializer.Serialize(ev));
                    qCmd.Parameters.AddWithValue("@adm", adminDeviceId);
                    qCmd.Parameters.AddWithValue("@ca", DateTime.UtcNow.ToString("O"));
                    qCmd.ExecuteNonQuery();
                }
            }
            catch
            {
                // Audit logging must never crash the host
            }
        }

        public static List<AuditSyncQueueItem> GetPendingSyncItems(int limit = 50)
        {
            var list = new List<AuditSyncQueueItem>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT Id, EventId, PayloadJson, TargetAdminDeviceId, Status, Attempts, LastAttemptAt, CreatedAt
FROM AuditSyncQueue
WHERE Status = 'Pending'
ORDER BY CreatedAt ASC LIMIT @lim;";
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read())
                {
                    list.Add(new AuditSyncQueueItem
                    {
                        Id = r.GetInt64(0),
                        EventId = r.GetString(1),
                        PayloadJson = r.GetString(2),
                        TargetAdminDeviceId = r.IsDBNull(3) ? null : r.GetString(3),
                        Status = r.GetString(4),
                        Attempts = r.GetInt32(5),
                        LastAttemptAt = r.IsDBNull(6) ? null : DateTime.Parse(r.GetString(6)),
                        CreatedAt = DateTime.Parse(r.GetString(7))
                    });
                }
            }
            catch { }
            return list;
        }

        public static bool MarkSynchronized(string eventId)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE AuditSyncQueue SET Status = 'Synced' WHERE EventId = @eid;";
                cmd.Parameters.AddWithValue("@eid", eventId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static bool RecordFailedAttempt(string eventId)
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
UPDATE AuditSyncQueue 
SET Attempts = Attempts + 1, LastAttemptAt = @now
WHERE EventId = @eid;";
                cmd.Parameters.AddWithValue("@now", DateTime.UtcNow.ToString("O"));
                cmd.Parameters.AddWithValue("@eid", eventId);
                return cmd.ExecuteNonQuery() > 0;
            }
            catch { return false; }
        }

        public static List<AuditEvent> GetRecentAuditEvents(int limit = 100, string? filterType = null)
        {
            var list = new List<AuditEvent>();
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                if (string.IsNullOrWhiteSpace(filterType))
                {
                    cmd.CommandText = @"
SELECT Id, Timestamp, ActorUsername, ActorDeviceId, Action, Target, Result
FROM AuditLogs
ORDER BY Timestamp DESC LIMIT @lim;";
                }
                else
                {
                    cmd.CommandText = @"
SELECT Id, Timestamp, ActorUsername, ActorDeviceId, Action, Target, Result
FROM AuditLogs
WHERE Action = @ft
ORDER BY Timestamp DESC LIMIT @lim;";
                    cmd.Parameters.AddWithValue("@ft", filterType);
                }
                cmd.Parameters.AddWithValue("@lim", limit);

                using var r = cmd.ExecuteReader();
                while (r.Read())
                {
                    list.Add(new AuditEvent
                    {
                        EventId = r.GetInt64(0).ToString(),
                        Timestamp = DateTime.Parse(r.GetString(1)),
                        Actor = r.IsDBNull(2) ? "" : r.GetString(2),
                        SourceDeviceId = r.IsDBNull(3) ? "" : r.GetString(3),
                        EventType = r.GetString(4),
                        TargetDeviceId = r.IsDBNull(5) ? null : r.GetString(5),
                        Description = r.IsDBNull(6) ? "" : r.GetString(6)
                    });
                }
            }
            catch { }
            return list;
        }
    }
}
