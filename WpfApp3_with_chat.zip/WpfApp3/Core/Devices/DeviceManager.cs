using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using WpfApp3.Database;

namespace WpfApp3.Core.Devices
{
    /// <summary>
    /// Central manager for device registry, presence tracking, authorization, and lifecycle.
    /// Thread-safe and unifies UDP discovery, database records, and trust stores.
    /// </summary>
    public class DeviceManager
    {
        private readonly object _lock = new();
        private readonly ConcurrentDictionary<string, DeviceInfo> _devicesByFingerprint = new(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, string> _deviceIdToFingerprint = new(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, bool> _blockedDevices = new(StringComparer.OrdinalIgnoreCase);

        public event Action<DeviceInfo>? DeviceDiscovered;
        public event Action<DeviceInfo>? DeviceOnline;
        public event Action<DeviceInfo>? DeviceOffline;
        public event Action<DeviceInfo>? DeviceUpdated;
        public event Action<DeviceInfo>? DeviceBlocked;
        public event Action<DeviceInfo>? DeviceUnblocked;

        public DeviceManager()
        {
            LoadFromDatabase();
        }

        public void LoadFromDatabase()
        {
            try
            {
                using var conn = AppDatabase.OpenConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
SELECT DeviceId, DisplayName, Hostname, IpAddress, OperatingSystem, ClientVersion, 
       Status, TrustStatus, CertificateFingerprint, IsAuthorized, IsRevoked, LastSeenAt, UserId,
       DeviceState, PublicKey
FROM Devices;";
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string deviceId = reader.GetString(0);
                    string displayName = reader.GetString(1);
                    string hostname = reader.IsDBNull(2) ? "" : reader.GetString(2);
                    string ipAddress = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    string os = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    string clientVer = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    string statusStr = reader.IsDBNull(6) ? "UNKNOWN" : reader.GetString(6);
                    string trustStr = reader.IsDBNull(7) ? "UNKNOWN" : reader.GetString(7);
                    string? fingerprint = reader.IsDBNull(8) ? null : reader.GetString(8);
                    bool isAuth = reader.GetInt32(9) == 1;
                    bool isRevoked = reader.GetInt32(10) == 1;
                    DateTime? lastSeen = reader.IsDBNull(11) ? null : DateTime.TryParse(reader.GetString(11), out var dt) ? dt : null;
                    long? userId = reader.IsDBNull(12) ? null : reader.GetInt64(12);
                    string stateStr = reader.FieldCount > 13 && !reader.IsDBNull(13) ? reader.GetString(13) : DeviceStates.PendingApproval;
                    string? publicKey = reader.FieldCount > 14 && !reader.IsDBNull(14) ? reader.GetString(14) : null;

                    _ = Enum.TryParse<DeviceStatus>(statusStr, true, out var status);
                    _ = Enum.TryParse<DeviceTrustStatus>(trustStr, true, out var trustStatus);
                    _ = Enum.TryParse<DeviceState>(stateStr, true, out var deviceState);

                    if (isRevoked)
                    {
                        status = DeviceStatus.BLOCKED;
                        trustStatus = DeviceTrustStatus.REVOKED;
                        deviceState = DeviceState.REVOKED;
                        _blockedDevices[deviceId] = true;
                    }

                    var dev = new DeviceInfo
                    {
                        DeviceId = deviceId,
                        DisplayName = displayName,
                        Hostname = hostname,
                        IpAddress = ipAddress,
                        OperatingSystem = os,
                        ClientVersion = clientVer,
                        Status = isRevoked ? DeviceStatus.BLOCKED : (status == DeviceStatus.ONLINE ? DeviceStatus.OFFLINE : status),
                        TrustStatus = trustStatus,
                        State = deviceState,
                        PublicKey = publicKey,
                        CertificateFingerprint = fingerprint ?? "",
                        IsAuthorized = isAuth,
                        IsRevoked = isRevoked,
                        LastSeenUtc = lastSeen ?? DateTime.UtcNow,
                        UserId = userId
                    };

                    if (!string.IsNullOrWhiteSpace(fingerprint))
                    {
                        string normFp = NormalizeFingerprint(fingerprint);
                        _devicesByFingerprint[normFp] = dev;
                        _deviceIdToFingerprint[deviceId] = normFp;
                    }
                }
            }
            catch
            {
                // Non-blocking if database is uninitialized
            }
        }

        public DeviceInfo RegisterOrUpdatePresence(
            string fingerprint,
            string deviceName,
            string ipAddress,
            string hostname = "",
            string operatingSystem = "",
            string clientVersion = "",
            string? deviceId = null,
            bool isPaired = false)
        {
            if (string.IsNullOrWhiteSpace(fingerprint))
                throw new ArgumentException("Certificate fingerprint cannot be empty.", nameof(fingerprint));

            string normFp = NormalizeFingerprint(fingerprint);
            DateTime now = DateTime.UtcNow;
            DeviceInfo? toNotify = null;
            bool isNew = false;
            bool cameOnline = false;

            lock (_lock)
            {
                if (_devicesByFingerprint.TryGetValue(normFp, out var existing))
                {
                    bool wasOffline = existing.Status != DeviceStatus.ONLINE;

                    if (!string.IsNullOrWhiteSpace(deviceName)) existing.DisplayName = deviceName.Trim();
                    if (!string.IsNullOrWhiteSpace(ipAddress)) existing.IpAddress = ipAddress.Trim();
                    if (!string.IsNullOrWhiteSpace(hostname)) existing.Hostname = hostname.Trim();
                    if (!string.IsNullOrWhiteSpace(operatingSystem)) existing.OperatingSystem = operatingSystem.Trim();
                    if (!string.IsNullOrWhiteSpace(clientVersion)) existing.ClientVersion = clientVersion.Trim();
                    if (!string.IsNullOrWhiteSpace(deviceId) && string.IsNullOrWhiteSpace(existing.DeviceId)) existing.DeviceId = deviceId;

                    existing.LastSeenUtc = now;

                    if (existing.IsRevoked || _blockedDevices.ContainsKey(existing.DeviceId) || _blockedDevices.ContainsKey(normFp))
                    {
                        existing.Status = DeviceStatus.BLOCKED;
                    }
                    else
                    {
                        existing.Status = DeviceStatus.ONLINE;
                        if (wasOffline) cameOnline = true;
                    }

                    toNotify = existing.Clone();
                }
                else
                {
                    string assignedDeviceId = !string.IsNullOrWhiteSpace(deviceId) ? deviceId : $"DEV-{normFp[..Math.Min(8, normFp.Length)]}";
                    bool isBlocked = _blockedDevices.ContainsKey(assignedDeviceId) || _blockedDevices.ContainsKey(normFp);

                    var newDev = new DeviceInfo
                    {
                        DeviceId = assignedDeviceId,
                        DisplayName = !string.IsNullOrWhiteSpace(deviceName) ? deviceName.Trim() : assignedDeviceId,
                        Hostname = hostname.Trim(),
                        IpAddress = ipAddress.Trim(),
                        OperatingSystem = operatingSystem.Trim(),
                        ClientVersion = clientVersion.Trim(),
                        Status = isBlocked ? DeviceStatus.BLOCKED : DeviceStatus.ONLINE,
                        TrustStatus = DeviceTrustStatus.UNKNOWN,
                        State = isBlocked ? DeviceState.REVOKED : DeviceState.DISCOVERED,
                        CertificateFingerprint = normFp,
                        LastSeenUtc = now
                    };

                    _devicesByFingerprint[normFp] = newDev;
                    _deviceIdToFingerprint[assignedDeviceId] = normFp;
                    isNew = true;
                    cameOnline = !isBlocked;
                    toNotify = newDev.Clone();
                }
            }

            if (toNotify != null)
            {
                if (isNew) DeviceDiscovered?.Invoke(toNotify);
                if (cameOnline) DeviceOnline?.Invoke(toNotify);
                DeviceUpdated?.Invoke(toNotify);
            }

            return toNotify ?? new DeviceInfo();
        }

        public void MarkOffline(string fingerprint)
        {
            if (string.IsNullOrWhiteSpace(fingerprint)) return;
            string normFp = NormalizeFingerprint(fingerprint);

            DeviceInfo? toNotify = null;
            lock (_lock)
            {
                if (_devicesByFingerprint.TryGetValue(normFp, out var dev))
                {
                    if (dev.Status == DeviceStatus.ONLINE)
                    {
                        dev.Status = DeviceStatus.OFFLINE;
                        toNotify = dev.Clone();
                    }
                }
            }

            if (toNotify != null)
            {
                DeviceOffline?.Invoke(toNotify);
                DeviceUpdated?.Invoke(toNotify);
            }
        }

        public bool BlockDevice(string identifier, string reason = "")
        {
            DeviceInfo? toNotify = null;
            lock (_lock)
            {
                DeviceInfo? dev = FindDeviceInternal(identifier);
                if (dev != null)
                {
                    dev.Status = DeviceStatus.BLOCKED;
                    dev.IsAuthorized = false;
                    _blockedDevices[dev.DeviceId] = true;
                    if (!string.IsNullOrWhiteSpace(dev.CertificateFingerprint))
                        _blockedDevices[dev.CertificateFingerprint] = true;
                    toNotify = dev.Clone();
                }
                else
                {
                    _blockedDevices[identifier] = true;
                }
            }

            if (toNotify != null)
            {
                DeviceBlocked?.Invoke(toNotify);
                DeviceUpdated?.Invoke(toNotify);
                return true;
            }

            return false;
        }

        public bool UnblockDevice(string identifier)
        {
            DeviceInfo? toNotify = null;
            lock (_lock)
            {
                _blockedDevices.TryRemove(identifier, out _);
                DeviceInfo? dev = FindDeviceInternal(identifier);
                if (dev != null)
                {
                    _blockedDevices.TryRemove(dev.DeviceId, out _);
                    if (!string.IsNullOrWhiteSpace(dev.CertificateFingerprint))
                        _blockedDevices.TryRemove(dev.CertificateFingerprint, out _);

                    dev.Status = (DateTime.UtcNow - dev.LastSeenUtc).TotalSeconds <= 15 ? DeviceStatus.ONLINE : DeviceStatus.OFFLINE;
                    dev.IsAuthorized = true;
                    toNotify = dev.Clone();
                }
            }

            if (toNotify != null)
            {
                DeviceUnblocked?.Invoke(toNotify);
                DeviceUpdated?.Invoke(toNotify);
                return true;
            }

            return false;
        }

        public bool IsDeviceBlocked(string identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier)) return false;
            if (_blockedDevices.ContainsKey(identifier)) return true;

            DeviceInfo? dev = GetDevice(identifier);
            if (dev != null)
            {
                return dev.Status == DeviceStatus.BLOCKED || dev.IsRevoked ||
                       _blockedDevices.ContainsKey(dev.DeviceId) ||
                       (!string.IsNullOrWhiteSpace(dev.CertificateFingerprint) && _blockedDevices.ContainsKey(dev.CertificateFingerprint));
            }

            return false;
        }

        public DeviceInfo? GetDevice(string identifier)
        {
            lock (_lock)
            {
                return FindDeviceInternal(identifier)?.Clone();
            }
        }

        public IReadOnlyList<DeviceInfo> GetAllDevices()
        {
            lock (_lock)
            {
                return _devicesByFingerprint.Values.Select(d => d.Clone()).ToList();
            }
        }

        public IReadOnlyList<DeviceInfo> GetOnlineDevices()
        {
            lock (_lock)
            {
                return _devicesByFingerprint.Values
                    .Where(d => d.Status == DeviceStatus.ONLINE)
                    .Select(d => d.Clone())
                    .ToList();
            }
        }

        public IReadOnlyList<DeviceInfo> Search(string query)
        {
            if (string.IsNullOrWhiteSpace(query)) return GetAllDevices();
            string q = query.Trim();

            lock (_lock)
            {
                return _devicesByFingerprint.Values
                    .Where(d => d.DisplayName.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                                d.DeviceId.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                                d.Hostname.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                                d.IpAddress.Contains(q, StringComparison.OrdinalIgnoreCase))
                    .Select(d => d.Clone())
                    .ToList();
            }
        }

        public IReadOnlyList<DeviceInfo> Filter(DeviceStatus? status = null, DeviceTrustStatus? trustStatus = null)
        {
            lock (_lock)
            {
                return _devicesByFingerprint.Values
                    .Where(d => (!status.HasValue || d.Status == status.Value) &&
                                (!trustStatus.HasValue || d.TrustStatus == trustStatus.Value))
                    .Select(d => d.Clone())
                    .ToList();
            }
        }

        private DeviceInfo? FindDeviceInternal(string identifier)
        {
            string norm = NormalizeFingerprint(identifier);
            if (_devicesByFingerprint.TryGetValue(norm, out var devByFp))
                return devByFp;

            if (_deviceIdToFingerprint.TryGetValue(identifier, out var fp) && _devicesByFingerprint.TryGetValue(fp, out var devById))
                return devById;

            return _devicesByFingerprint.Values.FirstOrDefault(d =>
                string.Equals(d.DeviceId, identifier, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(d.DisplayName, identifier, StringComparison.OrdinalIgnoreCase));
        }

        private static string NormalizeFingerprint(string fingerprint)
        {
            return fingerprint
                .Replace(":", "")
                .Replace(" ", "")
                .Trim()
                .ToUpperInvariant();
        }
    }
}
