using System;
using System.Linq;
using Xunit;
using WpfApp3.Core.Devices;

namespace WpfApp3.Tests
{
    public class DeviceManagerTests
    {
        private const string TestFp1 = "11223344556677889900AABBCCDDEEFF11223344556677889900AABBCCDDEEFF";
        private const string TestFp2 = "AABBCCDDEEFF11223344556677889900AABBCCDDEEFF11223344556677889900";

        [Fact]
        public void RegisterOrUpdatePresence_AddsNewDevice()
        {
            var manager = new DeviceManager();
            var dev = manager.RegisterOrUpdatePresence(
                fingerprint: TestFp1,
                deviceName: "Office-PC-1",
                ipAddress: "192.168.1.50",
                hostname: "WORKSTATION-1",
                operatingSystem: "Microsoft Windows 11",
                clientVersion: "2.0.0",
                deviceId: "NAV-12345678",
                isPaired: true);

            Assert.NotNull(dev);
            Assert.Equal("Office-PC-1", dev.DisplayName);
            Assert.Equal("192.168.1.50", dev.IpAddress);
            Assert.Equal(DeviceStatus.ONLINE, dev.Status);
            Assert.Equal(DeviceState.DISCOVERED, dev.State);
            Assert.False(dev.IsAuthorized);
            Assert.True(dev.IsOnline);
        }

        [Fact]
        public void MarkOffline_TransitionsDeviceToOffline()
        {
            var manager = new DeviceManager();
            manager.RegisterOrUpdatePresence(
                fingerprint: TestFp1,
                deviceName: "Laptop-1",
                ipAddress: "192.168.1.51");

            manager.MarkOffline(TestFp1);

            var dev = manager.GetDevice(TestFp1);
            Assert.NotNull(dev);
            Assert.Equal(DeviceStatus.OFFLINE, dev.Status);
            Assert.False(dev.IsOnline);
        }

        [Fact]
        public void BlockDevice_PreventsOnlineStatus()
        {
            var manager = new DeviceManager();
            manager.RegisterOrUpdatePresence(
                fingerprint: TestFp2,
                deviceName: "Rogue-PC",
                ipAddress: "192.168.1.99",
                deviceId: "NAV-ROGUE99");

            bool blocked = manager.BlockDevice("NAV-ROGUE99", "Security risk");
            Assert.True(blocked);
            Assert.True(manager.IsDeviceBlocked("NAV-ROGUE99"));

            // Heartbeat updates while blocked should remain BLOCKED
            var updated = manager.RegisterOrUpdatePresence(
                fingerprint: TestFp2,
                deviceName: "Rogue-PC",
                ipAddress: "192.168.1.99",
                deviceId: "NAV-ROGUE99");

            Assert.Equal(DeviceStatus.BLOCKED, updated.Status);
            Assert.False(updated.IsOnline);
        }

        [Fact]
        public void Search_FindsMatchingDevices()
        {
            var manager = new DeviceManager();
            manager.RegisterOrUpdatePresence(TestFp1, "Marketing-Print-PC", "192.168.1.10");
            manager.RegisterOrUpdatePresence(TestFp2, "Finance-PC", "192.168.1.20");

            var results = manager.Search("Marketing");
            Assert.Single(results);
            Assert.Equal("Marketing-Print-PC", results[0].DisplayName);
        }

        [Fact]
        public void Filter_ReturnsMatchingStatus()
        {
            var manager = new DeviceManager();
            manager.RegisterOrUpdatePresence(TestFp1, "Online-Device", "192.168.1.11");
            manager.RegisterOrUpdatePresence(TestFp2, "Offline-Device", "192.168.1.12");
            manager.MarkOffline(TestFp2);

            var onlineOnly = manager.Filter(status: DeviceStatus.ONLINE);
            Assert.Contains(onlineOnly, d => d.DisplayName == "Online-Device");
            Assert.DoesNotContain(onlineOnly, d => d.DisplayName == "Offline-Device");
        }
    }
}
