using System;
using System.Collections.Generic;
using System.Text.Json;
using Microsoft.Data.Sqlite;
using WpfApp3.Database;

namespace WpfApp3.Database
{
    public static class AccountStates
    {
        public const string Pending   = "PENDING";
        public const string Active    = "ACTIVE";
        public const string Suspended = "SUSPENDED";
        public const string Revoked   = "REVOKED";
        public const string Locked    = "LOCKED";
        public const string Expired   = "EXPIRED";
    }

    public class UserRecord
    {
        public long Id { get; set; }
        public string Username { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string Email { get; set; } = "";
        public string Role { get; set; } = "User"; // Admin, Supervisor, User
        public string AccountState { get; set; } = AccountStates.Active;
        public string PasswordHash { get; set; } = "";
        public string PasswordSalt { get; set; } = "";
        public bool ForcePasswordReset { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public DateTime? LastLoginAt { get; set; }
    }

    public static class DeviceStates
    {
        public const string Discovered      = "DISCOVERED";
        public const string Untrusted       = "UNTRUSTED";
        public const string PendingApproval = "PENDING_APPROVAL";
        public const string Authorized      = "AUTHORIZED";
        public const string Suspended       = "SUSPENDED";
        public const string Revoked         = "REVOKED";
    }

    public class DeviceRecord
    {
        public long Id { get; set; }
        public string DeviceId { get; set; } = "";
        public long UserId { get; set; }
        public string DisplayName { get; set; } = "";
        public string? CertificateFingerprint { get; set; }
        public string? PublicKey { get; set; }
        public string DeviceState { get; set; } = DeviceStates.PendingApproval;
        public bool IsAuthorized { get; set; }
        public bool IsRevoked { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastSeenAt { get; set; }
        // Navigation
        public string Username { get; set; } = "";
        public string Role { get; set; } = "User";
        public bool UserIsActive { get; set; }
        public string AccountState { get; set; } = AccountStates.Active;

        public Core.Devices.DeviceState State =>
            Enum.TryParse<Core.Devices.DeviceState>(DeviceState, true, out var s)
                ? s
                : Core.Devices.DeviceState.PENDING_APPROVAL;
    }

    public class AuthorityStateRecord
    {
        public int CurrentEpoch { get; set; } = 1;
        public long AdminUserId { get; set; }
        public string AdminDeviceId { get; set; } = "";
        public long? ActingAdminUserId { get; set; }
        public DateTime? ActingAdminLeaseExpiry { get; set; }
        public DateTime EpochStartedAt { get; set; } = DateTime.UtcNow;
        public string? EpochSignature { get; set; }
    }

    public class AuthorizationEventRecord
    {
        public long Id { get; set; }
        public string EventId { get; set; } = Guid.NewGuid().ToString();
        public string EventType { get; set; } = "";
        public long? UserId { get; set; }
        public string? DeviceId { get; set; }
        public long AuthorityUserId { get; set; }
        public string AuthorityRole { get; set; } = "";
        public int Epoch { get; set; } = 1;
        public int SequenceNumber { get; set; } = 1;
        public string PayloadJson { get; set; } = "{}";
        public string PayloadHash { get; set; } = "";
        public string Signature { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public DateTime ProcessedAt { get; set; } = DateTime.UtcNow;
    }

    public static class UserRepository
    {
        private const string UserColumns =
            "Id,Username,Role,PasswordHash,PasswordSalt," +
            "ForcePasswordReset,IsActive,CreatedAt,UpdatedAt,LastLoginAt,AccountState,DisplayName,Email";

        // ──────────────────────────────────────────────────
        // QUERIES
        // ──────────────────────────────────────────────────

        public static bool AdminExists()
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM Users WHERE Role='Admin';";
            long count = (long)(cmd.ExecuteScalar() ?? 0L);
            return count > 0;
        }

        public static UserRecord? FindAdmin()
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {UserColumns} FROM Users WHERE Role='Admin' LIMIT 1;";
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadUser(r) : null;
        }

        public static UserRecord? FindByUsername(string username)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {UserColumns} FROM Users WHERE Username=@u LIMIT 1;";
            cmd.Parameters.AddWithValue("@u", username);
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadUser(r) : null;
        }

        public static UserRecord? FindById(long id)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {UserColumns} FROM Users WHERE Id=@id LIMIT 1;";
            cmd.Parameters.AddWithValue("@id", id);
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadUser(r) : null;
        }

        public static List<UserRecord> GetAllUsers()
        {
            var list = new List<UserRecord>();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {UserColumns} FROM Users ORDER BY Role DESC, Username;";
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read()) list.Add(ReadUser(r));
            return list;
        }

        public static List<UserRecord> GetPendingUsers()
        {
            var list = new List<UserRecord>();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {UserColumns} FROM Users WHERE AccountState='{AccountStates.Pending}' ORDER BY CreatedAt ASC;";
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read()) list.Add(ReadUser(r));
            return list;
        }

        public static List<UserRecord> GetSupervisors()
        {
            var list = new List<UserRecord>();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = $"SELECT {UserColumns} FROM Users WHERE Role='Supervisor' ORDER BY Username;";
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read()) list.Add(ReadUser(r));
            return list;
        }

        // ──────────────────────────────────────────────────
        // MUTATIONS
        // ──────────────────────────────────────────────────

        public static long CreateUser(
            string username, string role,
            string passwordHash, string passwordSalt,
            string accountState = AccountStates.Active,
            string displayName = "",
            string email = "")
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                using SqliteCommand cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                string now = DateTime.UtcNow.ToString("O");
                bool isActive = string.Equals(accountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase);

                cmd.CommandText =
                    "INSERT INTO Users " +
                    "(Username,Role,PasswordHash,PasswordSalt,ForcePasswordReset,IsActive,CreatedAt,UpdatedAt,AccountState,DisplayName,Email) " +
                    "VALUES (@u,@r,@ph,@ps,0,@ia,@ca,@ua,@as,@dn,@em); " +
                    "SELECT last_insert_rowid();";
                cmd.Parameters.AddWithValue("@u",  username);
                cmd.Parameters.AddWithValue("@r",  role);
                cmd.Parameters.AddWithValue("@ph", passwordHash);
                cmd.Parameters.AddWithValue("@ps", passwordSalt);
                cmd.Parameters.AddWithValue("@ia", isActive ? 1 : 0);
                cmd.Parameters.AddWithValue("@ca", now);
                cmd.Parameters.AddWithValue("@ua", now);
                cmd.Parameters.AddWithValue("@as", accountState);
                cmd.Parameters.AddWithValue("@dn", string.IsNullOrWhiteSpace(displayName) ? username : displayName);
                cmd.Parameters.AddWithValue("@em", email ?? "");

                long id = (long)(cmd.ExecuteScalar() ?? 0L);
                tx.Commit();
                return id;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        public static bool UpdatePassword(
            long userId, string newHash, string newSalt,
            bool forceReset = false)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "UPDATE Users SET PasswordHash=@ph, PasswordSalt=@ps, " +
                "ForcePasswordReset=@fr, UpdatedAt=@ua WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@ph", newHash);
            cmd.Parameters.AddWithValue("@ps", newSalt);
            cmd.Parameters.AddWithValue("@fr", forceReset ? 1 : 0);
            cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@id", userId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool SetActive(long userId, bool active)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            string state = active ? AccountStates.Active : AccountStates.Suspended;
            cmd.CommandText =
                "UPDATE Users SET IsActive=@a, AccountState=@as, UpdatedAt=@ua WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@a",  active ? 1 : 0);
            cmd.Parameters.AddWithValue("@as", state);
            cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@id", userId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool SetAccountState(long userId, string state)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            bool active = string.Equals(state, AccountStates.Active, StringComparison.OrdinalIgnoreCase);
            cmd.CommandText =
                "UPDATE Users SET AccountState=@as, IsActive=@a, UpdatedAt=@ua WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@as", state);
            cmd.Parameters.AddWithValue("@a",  active ? 1 : 0);
            cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@id", userId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool ApproveUser(long userId)
        {
            return SetAccountState(userId, AccountStates.Active);
        }

        public static bool RejectUser(long userId)
        {
            return SetAccountState(userId, AccountStates.Revoked);
        }

        public static bool SetUserRole(long userId, string role)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "UPDATE Users SET Role=@r, UpdatedAt=@ua WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@r", role);
            cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@id", userId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool RecordLogin(long userId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "UPDATE Users SET LastLoginAt=@ll, UpdatedAt=@ua WHERE Id=@id;";
            cmd.Parameters.AddWithValue("@ll", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@ua", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@id", userId);
            return cmd.ExecuteNonQuery() > 0;
        }

        // ──────────────────────────────────────────────────
        // SUPERVISOR PERMISSIONS
        // ──────────────────────────────────────────────────

        public static HashSet<string> GetSupervisorPermissions(long userId)
        {
            var perms = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Permission FROM SupervisorPermissions WHERE UserId=@uid;";
            cmd.Parameters.AddWithValue("@uid", userId);
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read()) perms.Add(r.GetString(0));
            return perms;
        }

        public static void SetSupervisorPermissions(
            long userId, IEnumerable<string> permissions, long? grantedByUserId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                using (var delCmd = conn.CreateCommand())
                {
                    delCmd.Transaction = tx;
                    delCmd.CommandText = "DELETE FROM SupervisorPermissions WHERE UserId=@uid;";
                    delCmd.Parameters.AddWithValue("@uid", userId);
                    delCmd.ExecuteNonQuery();
                }

                string now = DateTime.UtcNow.ToString("O");
                foreach (var perm in permissions)
                {
                    using var insCmd = conn.CreateCommand();
                    insCmd.Transaction = tx;
                    insCmd.CommandText =
                        "INSERT OR IGNORE INTO SupervisorPermissions (UserId, Permission, GrantedBy, GrantedAt) " +
                        "VALUES (@uid, @p, @gb, @ga);";
                    insCmd.Parameters.AddWithValue("@uid", userId);
                    insCmd.Parameters.AddWithValue("@p",   perm);
                    insCmd.Parameters.AddWithValue("@gb",  (object?)grantedByUserId ?? DBNull.Value);
                    insCmd.Parameters.AddWithValue("@ga",  now);
                    insCmd.ExecuteNonQuery();
                }

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        public static bool HasSupervisorPermission(long userId, string permission)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM SupervisorPermissions WHERE UserId=@uid AND Permission=@p;";
            cmd.Parameters.AddWithValue("@uid", userId);
            cmd.Parameters.AddWithValue("@p", permission);
            long count = Convert.ToInt64(cmd.ExecuteScalar() ?? 0L);
            return count > 0;
        }

        // ──────────────────────────────────────────────────
        // AUTHORITY STATE
        // ──────────────────────────────────────────────────

        public static AuthorityStateRecord? GetAuthorityState()
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT CurrentEpoch, AdminUserId, AdminDeviceId, ActingAdminUserId, " +
                "ActingAdminLeaseExpiry, EpochStartedAt, EpochSignature FROM AuthorityState WHERE Id=1 LIMIT 1;";
            using SqliteDataReader r = cmd.ExecuteReader();
            if (!r.Read()) return null;

            return new AuthorityStateRecord
            {
                CurrentEpoch           = r.GetInt32(0),
                AdminUserId            = r.GetInt64(1),
                AdminDeviceId          = r.GetString(2),
                ActingAdminUserId      = r.IsDBNull(3) ? null : r.GetInt64(3),
                ActingAdminLeaseExpiry = r.IsDBNull(4) ? null : DateTime.Parse(r.GetString(4)),
                EpochStartedAt         = DateTime.Parse(r.GetString(5)),
                EpochSignature         = r.IsDBNull(6) ? null : r.GetString(6)
            };
        }

        public static void SetAuthorityState(
            int currentEpoch, long adminUserId, string adminDeviceId,
            long? actingAdminUserId, DateTime? actingAdminLeaseExpiry, string? epochSignature)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "INSERT INTO AuthorityState " +
                "(Id, CurrentEpoch, AdminUserId, AdminDeviceId, ActingAdminUserId, ActingAdminLeaseExpiry, EpochStartedAt, EpochSignature) " +
                "VALUES (1, @ce, @au, @ad, @aau, @ale, @esa, @es) " +
                "ON CONFLICT(Id) DO UPDATE SET " +
                "CurrentEpoch=excluded.CurrentEpoch, " +
                "AdminUserId=excluded.AdminUserId, " +
                "AdminDeviceId=excluded.AdminDeviceId, " +
                "ActingAdminUserId=excluded.ActingAdminUserId, " +
                "ActingAdminLeaseExpiry=excluded.ActingAdminLeaseExpiry, " +
                "EpochStartedAt=excluded.EpochStartedAt, " +
                "EpochSignature=excluded.EpochSignature;";
            cmd.Parameters.AddWithValue("@ce",  currentEpoch);
            cmd.Parameters.AddWithValue("@au",  adminUserId);
            cmd.Parameters.AddWithValue("@ad",  adminDeviceId);
            cmd.Parameters.AddWithValue("@aau", (object?)actingAdminUserId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@ale", actingAdminLeaseExpiry?.ToString("O") ?? (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@esa", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@es",  (object?)epochSignature ?? DBNull.Value);
            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Creates a user, its device record and (optionally) the initial
        /// authority epoch in a SINGLE transaction. Any failure rolls the
        /// whole thing back, so a partial failure can never leave an orphaned
        /// user row behind (which would permanently block first-run setup or
        /// reserve a username forever).
        /// </summary>
        public static long CreateUserWithDevice(
            string username, string role,
            string passwordHash, string passwordSalt,
            string accountState, string displayName, string email,
            string deviceId, string deviceDisplayName,
            string? certFingerprint, string? publicKey,
            string deviceState, bool isAuthorized,
            bool initializeAuthority = false)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                string now = DateTime.UtcNow.ToString("O");
                bool isActive = string.Equals(accountState, AccountStates.Active, StringComparison.OrdinalIgnoreCase);
                long userId;

                using (SqliteCommand cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText =
                        "INSERT INTO Users " +
                        "(Username,Role,PasswordHash,PasswordSalt,ForcePasswordReset,IsActive,CreatedAt,UpdatedAt,AccountState,DisplayName,Email) " +
                        "VALUES (@u,@r,@ph,@ps,0,@ia,@ca,@ua,@as,@dn,@em); " +
                        "SELECT last_insert_rowid();";
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@r", role);
                    cmd.Parameters.AddWithValue("@ph", passwordHash);
                    cmd.Parameters.AddWithValue("@ps", passwordSalt);
                    cmd.Parameters.AddWithValue("@ia", isActive ? 1 : 0);
                    cmd.Parameters.AddWithValue("@ca", now);
                    cmd.Parameters.AddWithValue("@ua", now);
                    cmd.Parameters.AddWithValue("@as", accountState);
                    cmd.Parameters.AddWithValue("@dn", string.IsNullOrWhiteSpace(displayName) ? username : displayName);
                    cmd.Parameters.AddWithValue("@em", email ?? "");
                    userId = (long)(cmd.ExecuteScalar() ?? 0L);
                }

                using (SqliteCommand cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText =
                        "INSERT INTO Devices " +
                        "(DeviceId,UserId,DisplayName,CertificateFingerprint,PublicKey,DeviceState,IsAuthorized,IsRevoked,CreatedAt) " +
                        "VALUES (@di,@ui,@dn,@cf,@pk,@ds,@ia,0,@ca);";
                    cmd.Parameters.AddWithValue("@di", deviceId);
                    cmd.Parameters.AddWithValue("@ui", userId);
                    cmd.Parameters.AddWithValue("@dn", string.IsNullOrWhiteSpace(deviceDisplayName) ? "LANShare Peer" : deviceDisplayName);
                    cmd.Parameters.AddWithValue("@cf", (object?)certFingerprint ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@pk", (object?)publicKey ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@ds", deviceState);
                    cmd.Parameters.AddWithValue("@ia", isAuthorized ? 1 : 0);
                    cmd.Parameters.AddWithValue("@ca", now);
                    cmd.ExecuteNonQuery();
                }

                if (initializeAuthority)
                {
                    using (SqliteCommand cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText =
                            "INSERT INTO AuthorityState " +
                            "(Id, CurrentEpoch, AdminUserId, AdminDeviceId, ActingAdminUserId, ActingAdminLeaseExpiry, EpochStartedAt, EpochSignature) " +
                            "VALUES (1, 1, @au, @ad, NULL, NULL, @esa, NULL) " +
                            "ON CONFLICT(Id) DO UPDATE SET " +
                            "AdminUserId=excluded.AdminUserId, " +
                            "AdminDeviceId=excluded.AdminDeviceId;";
                        cmd.Parameters.AddWithValue("@au", userId);
                        cmd.Parameters.AddWithValue("@ad", deviceId);
                        cmd.Parameters.AddWithValue("@esa", now);
                        cmd.ExecuteNonQuery();
                    }
                }

                tx.Commit();
                return userId;
            }
            catch
            {
                try { tx.Rollback(); } catch { }
                throw;
            }
        }

        // ──────────────────────────────────────────────────
        // AUTHORIZATION EVENTS & REPLAY PROTECTION
        // ──────────────────────────────────────────────────

        public static bool IsEventProcessed(string eventId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM ProcessedEvents WHERE EventId=@eid;";
            cmd.Parameters.AddWithValue("@eid", eventId);
            long count = Convert.ToInt64(cmd.ExecuteScalar() ?? 0L);
            return count > 0;
        }

        public static bool IsAuthorizationSequenceProcessed(long authorityUserId, int epoch, int sequenceNumber)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT COUNT(*) FROM AuthorizationEvents " +
                "WHERE AuthorityUserId=@au AND Epoch=@ep AND SequenceNumber=@seq;";
            cmd.Parameters.AddWithValue("@au", authorityUserId);
            cmd.Parameters.AddWithValue("@ep", epoch);
            cmd.Parameters.AddWithValue("@seq", sequenceNumber);
            return Convert.ToInt64(cmd.ExecuteScalar() ?? 0L) > 0;
        }

        public static void MarkEventProcessed(string eventId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT OR IGNORE INTO ProcessedEvents (EventId, ProcessedAt) VALUES (@eid, @pa);";
            cmd.Parameters.AddWithValue("@eid", eventId);
            cmd.Parameters.AddWithValue("@pa",  DateTime.UtcNow.ToString("O"));
            cmd.ExecuteNonQuery();
        }

        public static void RecordAuthorizationEvent(AuthorizationEventRecord record)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText =
                        "INSERT INTO AuthorizationEvents " +
                        "(EventId, EventType, UserId, DeviceId, AuthorityUserId, AuthorityRole, Epoch, SequenceNumber, " +
                        "PayloadJson, PayloadHash, Signature, Timestamp, ProcessedAt) " +
                        "VALUES (@eid, @et, @uid, @did, @auid, @ar, @ep, @seq, @pj, @ph, @sig, @ts, @pa);";
                    cmd.Parameters.AddWithValue("@eid",  record.EventId);
                    cmd.Parameters.AddWithValue("@et",   record.EventType);
                    cmd.Parameters.AddWithValue("@uid",  (object?)record.UserId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@did",  (object?)record.DeviceId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@auid", record.AuthorityUserId);
                    cmd.Parameters.AddWithValue("@ar",   record.AuthorityRole);
                    cmd.Parameters.AddWithValue("@ep",   record.Epoch);
                    cmd.Parameters.AddWithValue("@seq",  record.SequenceNumber);
                    cmd.Parameters.AddWithValue("@pj",   record.PayloadJson);
                    cmd.Parameters.AddWithValue("@ph",   record.PayloadHash);
                    cmd.Parameters.AddWithValue("@sig",  record.Signature);
                    cmd.Parameters.AddWithValue("@ts",   record.Timestamp.ToString("O"));
                    cmd.Parameters.AddWithValue("@pa",   record.ProcessedAt.ToString("O"));
                    cmd.ExecuteNonQuery();
                }

                using (var markCmd = conn.CreateCommand())
                {
                    markCmd.Transaction = tx;
                    markCmd.CommandText = "INSERT OR IGNORE INTO ProcessedEvents (EventId, ProcessedAt) VALUES (@eid, @pa);";
                    markCmd.Parameters.AddWithValue("@eid", record.EventId);
                    markCmd.Parameters.AddWithValue("@pa",  DateTime.UtcNow.ToString("O"));
                    markCmd.ExecuteNonQuery();
                }

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        public static List<AuthorizationEventRecord> GetAuthorizationEvents(int limit = 100)
        {
            var list = new List<AuthorizationEventRecord>();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT Id, EventId, EventType, UserId, DeviceId, AuthorityUserId, AuthorityRole, " +
                "Epoch, SequenceNumber, PayloadJson, PayloadHash, Signature, Timestamp, ProcessedAt " +
                "FROM AuthorizationEvents ORDER BY Id DESC LIMIT @lim;";
            cmd.Parameters.AddWithValue("@lim", limit);
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new AuthorizationEventRecord
                {
                    Id              = r.GetInt64(0),
                    EventId         = r.GetString(1),
                    EventType       = r.GetString(2),
                    UserId          = r.IsDBNull(3) ? null : r.GetInt64(3),
                    DeviceId        = r.IsDBNull(4) ? null : r.GetString(4),
                    AuthorityUserId = r.GetInt64(5),
                    AuthorityRole   = r.GetString(6),
                    Epoch           = r.GetInt32(7),
                    SequenceNumber  = r.GetInt32(8),
                    PayloadJson     = r.GetString(9),
                    PayloadHash     = r.GetString(10),
                    Signature       = r.GetString(11),
                    Timestamp       = DateTime.Parse(r.GetString(12)),
                    ProcessedAt     = DateTime.Parse(r.GetString(13))
                });
            }
            return list;
        }

        // ──────────────────────────────────────────────────
        // DEVICE RECORDS
        // ──────────────────────────────────────────────────

        public static string CreateDevice(
            string deviceId, long userId, string displayName,
            string? certFingerprint,
            string? publicKey = null,
            string deviceState = DeviceStates.PendingApproval,
            bool isAuthorized = false)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            string now = DateTime.UtcNow.ToString("O");
            cmd.CommandText =
                "INSERT INTO Devices " +
                "(DeviceId,UserId,DisplayName,CertificateFingerprint,PublicKey,DeviceState,IsAuthorized,IsRevoked,CreatedAt) " +
                "VALUES (@di,@ui,@dn,@cf,@pk,@ds,@ia,0,@ca) " +
                "ON CONFLICT(DeviceId) DO UPDATE SET " +
                "UserId=excluded.UserId, " +
                "DisplayName=excluded.DisplayName, " +
                "CertificateFingerprint=COALESCE(excluded.CertificateFingerprint, Devices.CertificateFingerprint), " +
                "PublicKey=COALESCE(excluded.PublicKey, Devices.PublicKey), " +
                "DeviceState=excluded.DeviceState, " +
                "IsAuthorized=excluded.IsAuthorized, " +
                "IsRevoked=excluded.IsRevoked;";
            cmd.Parameters.AddWithValue("@di", deviceId);
            cmd.Parameters.AddWithValue("@ui", userId);
            cmd.Parameters.AddWithValue("@dn", displayName);
            cmd.Parameters.AddWithValue("@cf", (object?)certFingerprint ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@pk", (object?)publicKey ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@ds", deviceState);
            cmd.Parameters.AddWithValue("@ia", isAuthorized ? 1 : 0);
            cmd.Parameters.AddWithValue("@ca", now);
            cmd.ExecuteNonQuery();
            return deviceId;
        }

        public static string UpsertDevice(
            string deviceId, long userId, string displayName,
            string? certFingerprint,
            string? publicKey = null,
            string deviceState = DeviceStates.PendingApproval,
            bool isAuthorized = false)
        {
            return CreateDevice(deviceId, userId, displayName, certFingerprint, publicKey, deviceState, isAuthorized);
        }

        public static DeviceRecord? FindDevice(string deviceId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT d.Id,d.DeviceId,d.UserId,d.DisplayName,d.CertificateFingerprint," +
                "d.IsAuthorized,d.IsRevoked,d.CreatedAt,d.LastSeenAt," +
                "u.Username,u.Role,u.IsActive,u.AccountState,d.DeviceState,d.PublicKey " +
                "FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                "WHERE d.DeviceId=@di LIMIT 1;";
            cmd.Parameters.AddWithValue("@di", deviceId);
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadDevice(r) : null;
        }

        public static DeviceRecord? FindDeviceByUserId(long userId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT d.Id,d.DeviceId,d.UserId,d.DisplayName,d.CertificateFingerprint," +
                "d.IsAuthorized,d.IsRevoked,d.CreatedAt,d.LastSeenAt," +
                "u.Username,u.Role,u.IsActive,u.AccountState,d.DeviceState,d.PublicKey " +
                "FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                "WHERE d.UserId=@uid ORDER BY d.Id LIMIT 1;";
            cmd.Parameters.AddWithValue("@uid", userId);
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadDevice(r) : null;
        }

        public static List<DeviceRecord> GetAllDevices()
        {
            var list = new List<DeviceRecord>();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT d.Id,d.DeviceId,d.UserId,d.DisplayName,d.CertificateFingerprint," +
                "d.IsAuthorized,d.IsRevoked,d.CreatedAt,d.LastSeenAt," +
                "u.Username,u.Role,u.IsActive,u.AccountState,d.DeviceState,d.PublicKey " +
                "FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                "ORDER BY u.Role DESC, u.Username;";
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read()) list.Add(ReadDevice(r));
            return list;
        }

        public static List<DeviceRecord> GetPendingRegistrations()
        {
            var list = new List<DeviceRecord>();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT d.Id,d.DeviceId,d.UserId,d.DisplayName,d.CertificateFingerprint," +
                "d.IsAuthorized,d.IsRevoked,d.CreatedAt,d.LastSeenAt," +
                "u.Username,u.Role,u.IsActive,u.AccountState,d.DeviceState,d.PublicKey " +
                "FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                "WHERE u.AccountState=@uas AND d.DeviceState=@ds ORDER BY d.CreatedAt ASC;";
            cmd.Parameters.AddWithValue("@uas", AccountStates.Pending);
            cmd.Parameters.AddWithValue("@ds", DeviceStates.PendingApproval);
            using SqliteDataReader r = cmd.ExecuteReader();
            while (r.Read()) list.Add(ReadDevice(r));
            return list;
        }

        public static bool ApplyRegistrationDecision(
            long userId, string deviceId, string publicKey, bool approve)
        {
            if (userId <= 0 || string.IsNullOrWhiteSpace(deviceId) || string.IsNullOrWhiteSpace(publicKey))
                return false;

            using SqliteConnection conn = AppDatabase.OpenConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                using var check = conn.CreateCommand();
                check.Transaction = tx;
                check.CommandText =
                    "SELECT d.PublicKey FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                    "WHERE u.Id=@uid AND d.DeviceId=@did AND u.AccountState=@uas " +
                    "AND d.DeviceState=@ds AND d.IsAuthorized=0 AND d.IsRevoked=0 LIMIT 1;";
                check.Parameters.AddWithValue("@uid", userId);
                check.Parameters.AddWithValue("@did", deviceId.Trim());
                check.Parameters.AddWithValue("@uas", AccountStates.Pending);
                check.Parameters.AddWithValue("@ds", DeviceStates.PendingApproval);
                object? storedKey = check.ExecuteScalar();
                if (storedKey is not string key || !string.Equals(key, publicKey.Trim(), StringComparison.Ordinal))
                {
                    tx.Rollback();
                    return false;
                }

                string userState = approve ? AccountStates.Active : AccountStates.Revoked;
                string deviceState = approve ? DeviceStates.Authorized : DeviceStates.Revoked;
                using var userUpdate = conn.CreateCommand();
                userUpdate.Transaction = tx;
                userUpdate.CommandText =
                    "UPDATE Users SET AccountState=@state, IsActive=@active, UpdatedAt=@updated " +
                    "WHERE Id=@uid AND AccountState=@pending;";
                userUpdate.Parameters.AddWithValue("@state", userState);
                userUpdate.Parameters.AddWithValue("@active", approve ? 1 : 0);
                userUpdate.Parameters.AddWithValue("@updated", DateTime.UtcNow.ToString("O"));
                userUpdate.Parameters.AddWithValue("@uid", userId);
                userUpdate.Parameters.AddWithValue("@pending", AccountStates.Pending);
                if (userUpdate.ExecuteNonQuery() != 1)
                {
                    tx.Rollback();
                    return false;
                }

                using var deviceUpdate = conn.CreateCommand();
                deviceUpdate.Transaction = tx;
                deviceUpdate.CommandText =
                    "UPDATE Devices SET DeviceState=@state, IsAuthorized=@authorized, IsRevoked=@revoked " +
                    "WHERE DeviceId=@did AND UserId=@uid AND PublicKey=@pk AND DeviceState=@pending " +
                    "AND IsAuthorized=0 AND IsRevoked=0;";
                deviceUpdate.Parameters.AddWithValue("@state", deviceState);
                deviceUpdate.Parameters.AddWithValue("@authorized", approve ? 1 : 0);
                deviceUpdate.Parameters.AddWithValue("@revoked", approve ? 0 : 1);
                deviceUpdate.Parameters.AddWithValue("@did", deviceId.Trim());
                deviceUpdate.Parameters.AddWithValue("@uid", userId);
                deviceUpdate.Parameters.AddWithValue("@pk", publicKey.Trim());
                deviceUpdate.Parameters.AddWithValue("@pending", DeviceStates.PendingApproval);
                if (deviceUpdate.ExecuteNonQuery() != 1)
                {
                    tx.Rollback();
                    return false;
                }

                tx.Commit();
                return true;
            }
            catch
            {
                tx.Rollback();
                return false;
            }
        }

        public static bool SetDeviceRevoked(string deviceId, bool revoked)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            string state = revoked ? DeviceStates.Revoked : DeviceStates.Authorized;
            cmd.CommandText =
                "UPDATE Devices SET IsRevoked=@r, IsAuthorized=@a, DeviceState=@ds " +
                "WHERE DeviceId=@di;";
            cmd.Parameters.AddWithValue("@r",  revoked ? 1 : 0);
            cmd.Parameters.AddWithValue("@a",  revoked ? 0 : 1);
            cmd.Parameters.AddWithValue("@ds", state);
            cmd.Parameters.AddWithValue("@di", deviceId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool SetDeviceState(string deviceId, string state)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            bool isAuthorized = string.Equals(state, DeviceStates.Authorized, StringComparison.OrdinalIgnoreCase);
            bool isRevoked = string.Equals(state, DeviceStates.Revoked, StringComparison.OrdinalIgnoreCase);
            cmd.CommandText =
                "UPDATE Devices SET DeviceState=@ds, IsAuthorized=@ia, IsRevoked=@ir WHERE DeviceId=@di;";
            cmd.Parameters.AddWithValue("@ds", state);
            cmd.Parameters.AddWithValue("@ia", isAuthorized ? 1 : 0);
            cmd.Parameters.AddWithValue("@ir", isRevoked ? 1 : 0);
            cmd.Parameters.AddWithValue("@di", deviceId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool UpdateDevicePublicKey(string deviceId, string publicKey)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "UPDATE Devices SET PublicKey=@pk WHERE DeviceId=@di;";
            cmd.Parameters.AddWithValue("@pk", publicKey);
            cmd.Parameters.AddWithValue("@di", deviceId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool UpdateDeviceCertFingerprint(
            string deviceId, string fingerprint)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "UPDATE Devices SET CertificateFingerprint=@cf, LastSeenAt=@ls " +
                "WHERE DeviceId=@di;";
            cmd.Parameters.AddWithValue("@cf", fingerprint);
            cmd.Parameters.AddWithValue("@ls", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@di", deviceId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public static bool IsFingerprintRevoked(string fingerprint)
        {
            if (string.IsNullOrWhiteSpace(fingerprint)) return false;
            try
            {
                using SqliteConnection conn = AppDatabase.OpenConnection();
                using SqliteCommand cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT COUNT(*) FROM Devices WHERE CertificateFingerprint=@fp AND (IsRevoked=1 OR IsAuthorized=0);";
                cmd.Parameters.AddWithValue("@fp", fingerprint);
                long count = Convert.ToInt64(cmd.ExecuteScalar() ?? 0L);
                return count > 0;
            }
            catch { return false; }
        }

        public static DeviceRecord? FindDeviceByFingerprint(string fingerprint)
        {
            if (string.IsNullOrWhiteSpace(fingerprint)) return null;
            string norm = fingerprint.Replace(":", "").Replace("-", "").Replace(" ", "").Trim().ToUpperInvariant();
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT d.Id,d.DeviceId,d.UserId,d.DisplayName,d.CertificateFingerprint," +
                "d.IsAuthorized,d.IsRevoked,d.CreatedAt,d.LastSeenAt," +
                "u.Username,u.Role,u.IsActive,u.AccountState,d.DeviceState,d.PublicKey " +
                "FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                "WHERE UPPER(REPLACE(REPLACE(REPLACE(d.CertificateFingerprint, ':', ''), '-', ''), ' ', '')) = @fp LIMIT 1;";
            cmd.Parameters.AddWithValue("@fp", norm);
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadDevice(r) : null;
        }

        public static DeviceRecord? FindDeviceByPublicKey(string publicKey)
        {
            if (string.IsNullOrWhiteSpace(publicKey)) return null;
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "SELECT d.Id,d.DeviceId,d.UserId,d.DisplayName,d.CertificateFingerprint," +
                "d.IsAuthorized,d.IsRevoked,d.CreatedAt,d.LastSeenAt," +
                "u.Username,u.Role,u.IsActive,u.AccountState,d.DeviceState,d.PublicKey " +
                "FROM Devices d JOIN Users u ON u.Id=d.UserId " +
                "WHERE d.PublicKey=@pk LIMIT 1;";
            cmd.Parameters.AddWithValue("@pk", publicKey.Trim());
            using SqliteDataReader r = cmd.ExecuteReader();
            return r.Read() ? ReadDevice(r) : null;
        }

        /// <summary>
        /// Authoritative Zero-Trust Device Authorization check.
        /// Evaluates DeviceState == AUTHORIZED, IsAuthorized == 1, IsRevoked == 0.
        /// Rejects lookup attempts using non-authoritative identifiers (hostname, IP, MAC).
        /// </summary>
        public static bool IsDeviceAuthorized(string? deviceId = null, string? fingerprint = null, string? publicKey = null)
        {
            DeviceRecord? dev = null;

            if (!string.IsNullOrWhiteSpace(deviceId))
            {
                dev = FindDevice(deviceId.Trim());
            }

            if (dev == null && !string.IsNullOrWhiteSpace(publicKey))
            {
                dev = FindDeviceByPublicKey(publicKey.Trim());
            }

            if (dev == null && !string.IsNullOrWhiteSpace(fingerprint))
            {
                dev = FindDeviceByFingerprint(fingerprint.Trim());
            }

            if (dev == null)
            {
                // Default deny (zero trust)
                return false;
            }

            // Must strictly be AUTHORIZED state
            if (!string.Equals(dev.DeviceState, DeviceStates.Authorized, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            // Secondary flags must align with state
            if (!dev.IsAuthorized || dev.IsRevoked)
            {
                return false;
            }

            // Also ensure associated user account is active
            if (!dev.UserIsActive || string.Equals(dev.AccountState, AccountStates.Suspended, StringComparison.OrdinalIgnoreCase)
                                  || string.Equals(dev.AccountState, AccountStates.Revoked, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            return true;
        }

        public static bool UpdateDeviceLastSeen(string deviceId)
        {
            using SqliteConnection conn = AppDatabase.OpenConnection();
            using SqliteCommand cmd = conn.CreateCommand();
            cmd.CommandText =
                "UPDATE Devices SET LastSeenAt=@ls WHERE DeviceId=@di;";
            cmd.Parameters.AddWithValue("@ls", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("@di", deviceId);
            return cmd.ExecuteNonQuery() > 0;
        }

        // ──────────────────────────────────────────────────
        // HELPERS
        // ──────────────────────────────────────────────────

        private static UserRecord ReadUser(SqliteDataReader r) => new()
        {
            Id                = r.GetInt64(0),
            Username          = r.GetString(1),
            Role              = r.GetString(2),
            PasswordHash      = r.GetString(3),
            PasswordSalt      = r.GetString(4),
            ForcePasswordReset= r.GetInt64(5) != 0,
            IsActive          = r.GetInt64(6) != 0,
            CreatedAt         = DateTime.Parse(r.GetString(7)),
            UpdatedAt         = DateTime.Parse(r.GetString(8)),
            LastLoginAt       = r.IsDBNull(9) ? null : DateTime.Parse(r.GetString(9)),
            AccountState      = r.FieldCount > 10 && !r.IsDBNull(10) ? r.GetString(10) : AccountStates.Active,
            DisplayName       = r.FieldCount > 11 && !r.IsDBNull(11) ? r.GetString(11) : "",
            Email             = r.FieldCount > 12 && !r.IsDBNull(12) ? r.GetString(12) : ""
        };

        private static DeviceRecord ReadDevice(SqliteDataReader r) => new()
        {
            Id                    = r.GetInt64(0),
            DeviceId              = r.GetString(1),
            UserId                = r.GetInt64(2),
            DisplayName           = r.GetString(3),
            CertificateFingerprint= r.IsDBNull(4) ? null : r.GetString(4),
            IsAuthorized          = r.GetInt64(5) != 0,
            IsRevoked             = r.GetInt64(6) != 0,
            CreatedAt             = DateTime.Parse(r.GetString(7)),
            LastSeenAt            = r.IsDBNull(8) ? null : DateTime.Parse(r.GetString(8)),
            Username              = r.GetString(9),
            Role                  = r.GetString(10),
            UserIsActive          = r.GetInt64(11) != 0,
            AccountState          = r.FieldCount > 12 && !r.IsDBNull(12) ? r.GetString(12) : AccountStates.Active,
            DeviceState           = r.FieldCount > 13 && !r.IsDBNull(13) ? r.GetString(13) : DeviceStates.PendingApproval,
            PublicKey             = r.FieldCount > 14 && !r.IsDBNull(14) ? r.GetString(14) : null
        };
    }
}
